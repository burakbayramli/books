function [Nv, VX, VY, K, EToV] = CatmullClarkSubdivision(VX,VY,EToV)
% Catmull-Clark subdivision for converting triangulation into a quad mesh.
%
% By Allan P. Engsig-Karup, apek@imm.dtu.dk.

Nfaces = size(EToV,2);
K      = size(EToV,1);
Nnodes = length(VX);
VNUM   = zeros(Nfaces,2);
VNUM(:,1) = 1:Nfaces; VNUM(:,2) = [2:Nfaces 1];

% Compute new face mid points for every face of triangle in original mesh.
xfc = 0.5*( VX(EToV(:,VNUM(:,1))) + VX(EToV(:,VNUM(:,2))) );
yfc = 0.5*( VY(EToV(:,VNUM(:,1))) + VY(EToV(:,VNUM(:,2))) );

% For each element compute centroid
if K==1
    xc = mean(VX(EToV));
    yc = mean(VY(EToV));
else
    xc = mean(VX(EToV),2);
    yc = mean(VY(EToV),2);
end

% Add K centroids
VX = [VX; xc(:)];
VY = [VY; yc(:)];

% Add 3*K face centers (will be duplicate)
VX = [VX; xfc(:)];
VY = [VY; yfc(:)];

% Create quad mesh
EToVQuad = [];
for k = 1 : K
    % triangle vertices
    v1 = EToV(k,1); v2 = EToV(k,2); v3 = EToV(k,3);
    % triangle centroid
    vc = Nnodes + k; % global index in new VX, VY list
    % triangle face mid points
    f1 = Nnodes +   K + k; 
    f2 = Nnodes + 2*K + k;
    f3 = Nnodes + 3*K + k;    
    % Split each triangle in 3 quads and add to list
    NewQuads = [ v1 f1 vc f3 ;
                 f1 v2 f2 vc ;
                 f2 v3 f3 vc];
    EToVQuad = [EToVQuad; NewQuads];
end

% Remove duplicate nodes (cf. Persson)
p = [VX VY]; t = EToVQuad;
snap=max(max(p,[],1)-min(p,[],1),[],2)*1024*eps;
[foo,ix,jx]=unique(round(p/snap)*snap,'rows');
p=p(ix,:); t=jx(t);

% Discard duplicate nodes (cf. Persson)
[pix,ix,jx]=unique(t); t=reshape(jx,size(t));
p=p(pix,:);

%disp(sprintf('%d vertices discarded.',length(VX)-length(pix)))

EToV = t;
VX   = p(:,1);
VY   = p(:,2);
K    = size(EToV,1);
Nv   = length(VX);
return

