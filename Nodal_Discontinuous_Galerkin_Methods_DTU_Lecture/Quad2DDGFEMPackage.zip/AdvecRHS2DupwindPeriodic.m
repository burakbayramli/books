function [rhsu] = AdvecRHS2DupwindPeriodic(u, timelocal, cx, cy, alpha)

% function [rhsu] = AdvecRHS2D(u, timelocal, a, alpha)
% Purpose  : Evaluate RHS flux in 2D advection equation 
%
% upwinding
Globals2D;

% Define flux differences at faces
df = zeros(Nfp*Nfaces,K); 

% phase speed in normal directions
cn = cx*nx(:) + cy*ny(:);

% upwinding according to characteristics
ustar = 0.5*(cn+abs(cn)).*u(vmapM) + 0.5*(cn-abs(cn)).*u(vmapP);
df(:) = cn.*u(vmapM) - ustar;

% local derivatives of fields
[ux,uy] = Grad2D(u); 

% compute right hand sides of the PDE's
rhsu  = -(cx.*ux + cy.*uy) + LIFT*(Fscale.*df);
return
