function [u,time] = Advec2DPeriodic(u, FinalTime, cx, cy, alpha)

% function [u,time] = Advec2D(u, FinalTime, cx, cy, alpha)
% Purpose : Integrate 2D advection equation until FinalTime starting with
%           initial cocndition u

Globals2D;
time = 0;

% Runge-Kutta residual storage  
resu = zeros(Np,K); 

% compute time step size
rLGL = JacobiGQ(0,0,N); rmin = abs(rLGL(1)-rLGL(2));
dtscale = dtscale2Dquad; dt = min(dtscale)*rmin*1/3;

% outer time step loop 
tstep = 0;
while (time<FinalTime)
  tstep= tstep+1;
  if(time+dt>FinalTime), dt = FinalTime-time; end

   for INTRK = 1:5    
       timelocal = time + rk4c(INTRK)*dt;
       [rhsu] = AdvecRHS2DupwindPeriodic(u, timelocal, cx, cy, alpha);
       resu   = rk4a(INTRK)*resu + dt*rhsu;  
       u = u+rk4b(INTRK)*resu;
   end
   % Increment time
   time = time+dt;
   if mod(tstep,10)==0
      PlotField2Dquad(N+1, x, y, u); 
      axis([-1 1 -1 1 -1 1]*1.5)
      xlabel('x'), ylabel('y'), zlabel('u(x,y,t)')
      title(sprintf('time = %.2f',time))
      drawnow
   end
end
return
