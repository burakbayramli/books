% Purpose : Setup script, building operators, grid, metric, and connectivity tables.
% Definition of constants
Nfp = N+1; Np = (N+1)*(N+1); Nfaces=4; NODETOL = 1e-12;

% Compute nodal set
[r,s] = Nodes2Dquad(N);
r = r(:); s = s(:);

% Build reference element matrices
V = Vandermonde2Dquad(N,r,s); invV = inv(V);
MassMatrix = invV'*invV;
[Dr,Ds] = Dmatrices2Dquad(N, r, s, V);

% build coordinates of all the nodes
va = EToV(:,1)'; vb = EToV(:,2)'; vc = EToV(:,3)'; vd = EToV(:,4)';
x = zeros(length(r),K); y = zeros(length(r),K);
for k = 1 : K
    xc = VX(EToV(k,:)); yc = VY(EToV(k,:));
    [x(:,k),y(:,k)] = QuadMap(xc,yc,r(:),s(:));
end

% find all the nodes that lie on each edge
fmask1 = find( abs(s+1) < NODETOL)'; % south
fmask2 = find( abs(r-1) < NODETOL)'; % east
fmask3 = find( abs(s-1) < NODETOL)'; % north
fmask4 = find( abs(r+1) < NODETOL)'; % west
Fmask  = [fmask1;fmask2;fmask3;fmask4]';
Fx = x(Fmask(:), :); Fy = y(Fmask(:), :); % coordinates for evaluating flux-contributions at each interface for each element

% Create surface integral terms
LIFT = Lift2Dquad();

% calculate geometric factors
[rx,sx,ry,sy,J] = GeometricFactors2D(x,y,Dr,Ds);

% calculate geometric factors
[nx, ny, sJ] = Normals2Dquad();
Fscale = sJ./(J(Fmask,:));

% Build connectivity matrix
%warning('tiConnect2Dquad not verified.')
[EToE, EToF] = tiConnect2Dquad(EToV);

% Build connectivity maps
BuildMaps2D;

% Compute weak operators (could be done in preprocessing to save time)
[Vr, Vs] = GradVandermonde2Dquad(N, r, s);
Drw = (V*Vr')/(V*V'); Dsw = (V*Vs')/(V*V');
