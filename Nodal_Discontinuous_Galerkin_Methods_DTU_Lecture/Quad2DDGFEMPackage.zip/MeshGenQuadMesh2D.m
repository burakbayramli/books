function [Nv, VX, VY, K, EToV] = MeshGenQuadMesh2D(varargin)

% function [Nv, VX, VY, K, EToV] = MeshGenQuadMesh2D(hx,hy,Bbox)
% Purpose  : Generate 2D square mesh based on quadrilaterals;   
% By Allan P. Engsig-Karup

% Parameters to set/define
%    hx     Characteristic length of elements in x-direction
%    hy     Characteristic length of elements in y-direction
%    Bbox   Bounding box for mesh [xmin ymin; xmax ymax]

hx   = varargin{1};
hy   = varargin{2};
Bbox = varargin{3}; % [xmin ymin; xmax ymax]
xmin = Bbox(1,1); xmax = Bbox(2,1);
ymin = Bbox(1,2); ymax = Bbox(2,2);
LX = xmax-xmin; LY = ymax-ymin;

% Determine grid resoluion
Nx = round(LX/hx); Ny = round(LY/hy);

% create vertices
x = linspace(xmin,xmax,Nx);
y = linspace(ymin,ymax,Ny);
[VX,VY] = meshgrid(x,y);
VX = VX(:); VY = VY(:);
count = 0;
EToV = zeros((Nx-1)*(Ny-1),1);
for i = 1 : Nx - 1
    for j = 1 : Ny - 1;
        count = count + 1;
        Gidx = j + (i-1)*Ny;
        EToV(count,[1 2 3 4]) = [Gidx Gidx+Ny Gidx+1+Ny Gidx+1];
    end
end
K  = size(EToV,1);
Nv = length(VX);
quadplot(EToV,VX,VY,'k')
return
