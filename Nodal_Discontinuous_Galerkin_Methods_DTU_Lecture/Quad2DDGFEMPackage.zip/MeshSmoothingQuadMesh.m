function [VX,VY] = MeshSmoothingQuadMesh(EToV,VX,VY,noiter)
iAllNodes = 1 : length(VX);
Nfaces = size(EToV,2);
[EToE,EToF] = tiConnect2DQuad(EToV);
iBoundary = [];
K = size(EToV,1);
VNUM = zeros(Nfaces,2);
VNUM(:,1) = 1:Nfaces; VNUM(:,2) = [2:Nfaces 1];
for k = 1 : K
    mask = (EToE(k,:) == k);
    if sum(mask)
        idx = find(mask==1);
        newnodes = EToV(k,VNUM(idx,:));
        iBoundary = [iBoundary; newnodes(:) ];
    end
end
iBoundary = unique(iBoundary);
iInterior = setdiff(iAllNodes,iBoundary);
% Smooth interior nodes only
for iter = 1:noiter
    for i = 1 : length(iInterior)
        node = iInterior(i);
        [m,n] = find(EToV==node);
        connectingnodes = EToV(m(:),:);
        connectingnodes = connectingnodes(:);
        % smoothing by averaging
        VX(node) = mean(VX(connectingnodes));
        VY(node) = mean(VY(connectingnodes));
    end
end
return