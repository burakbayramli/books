function [Nv, VX, VY, K, EToV] = SubdivideQuadElement(VX,VY,EToV,elmL)
for elm = elmL
    x = VX(EToV(elm,:));
    y = VX(EToV(elm,:));
    fac = 0.45;
    newnodes = [ x(1)+fac*(x(3)-x(1))     y(1) + fac*(y(3)-y(1)) ;
        x(2)+fac*(x(4)-x(2))     y(2) + (1-fac)*(y(4)-y(2))  ;
        x(1)+(1-fac)*(x(3)-x(1)) y(1) + (1-fac)*(y(3)-y(1)) ;
        x(2)+(1-fac)*(x(4)-x(2)) y(2) + fac*(y(4)-y(2)) ];
    Nnodes = length(VX);
    VX = [VX; newnodes(:,1)];
    VY = [VY; newnodes(:,2)];
    CurrentElement = EToV(elm,:);
    NewElements = [ CurrentElement(1) CurrentElement(2) Nnodes+2 Nnodes+1 ;
        CurrentElement(2) CurrentElement(3) Nnodes+3 Nnodes+2  ;
        CurrentElement(3) CurrentElement(4) Nnodes+4 Nnodes+3 ;
        CurrentElement(4) CurrentElement(1) Nnodes+1 Nnodes+4 ;
        Nnodes+1 Nnodes+2 Nnodes+3 Nnodes+4];
    EToV(elm,:) = [];
    EToV = [EToV; NewElements];
end
K = size(EToV,1);
Nv = length(VX);
return

