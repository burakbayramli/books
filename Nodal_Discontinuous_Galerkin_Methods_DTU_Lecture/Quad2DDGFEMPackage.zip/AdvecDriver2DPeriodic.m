close all, clear all, clc
warning off
% Driver script for solving the 2D advection equation
Globals2D;

% Polynomial order used for approximation
N  = 3;
cx = 1; cy = 0.3;
FinalTime = 2;

% Create Mesh
[Nv, VX, VY, K, EToV] = MeshGenQuadMesh2D(0.25,0.25,[-1 -1; 1 1]);
close all

disp('Initializing solver and constructing grid and metrics...')
% Initialize solver and construct grid and metric
StartUp2Dquad;

disp('Setting up a boundary condition type table...')
% prepare for periodic setup
% Make BC table and define special maps for BCs
BCType = int16(not(EToE));

fdW = @(p) drectangle(p,-1,2,-2,2);
fdE = @(p) drectangle(p,-2,1,-2,2);
BCcodeW = 1; BCcodeE = 2;
BCType = CorrectBCTable_v2quad(EToV,VX,VY,BCType,fdW,BCcodeW);
BCType = CorrectBCTable_v2quad(EToV,VX,VY,BCType,fdE,BCcodeE);
fdS = @(p) drectangle(p,-2,2,-1,2);
fdN = @(p) drectangle(p,-2,2,-2,1);
BCcodeS = 3; BCcodeN = 4;
BCType = CorrectBCTable_v2quad(EToV,VX,VY,BCType,fdS,BCcodeS);
BCType = CorrectBCTable_v2quad(EToV,VX,VY,BCType,fdN,BCcodeN);

fd = @(p) drectangle(p,-1,1,-1,1);
[mapW,mapE] = ConstructPeriodicMap_quad(EToV,VX,VY,BCType,BCcodeW,BCcodeE,fd);
[mapS,mapN] = ConstructPeriodicMap_quad(EToV,VX,VY,BCType,BCcodeS,BCcodeN,fd);

% modify exterior vmapP to be periodic with vmapM
vmapP(mapW) = vmapM(mapE);
vmapP(mapE) = vmapM(mapW);
vmapP(mapS) = vmapM(mapN);
vmapP(mapN) = vmapM(mapS);

% Set initial conditions
Lx = 2; Ly = 2;
u = sin(2*pi/Lx*x).*sin(2*pi/Ly*y);
alpha = 0; % PARAMETER - NOT USED

PlotField2Dquad(N+1, x, y, u);

% Solve Problem
disp('  Solving...')
[u,time] = Advec2DPeriodic(u, FinalTime, cx, cy, alpha);

PlotField2Dquad(N+1, x, y, u);
axis([-1 1 -1 1 -1 1]*1.5)
xlabel('x'), ylabel('y'), zlabel('u(x,y,t)')
title(sprintf('time = %.2f',time))
drawnow
