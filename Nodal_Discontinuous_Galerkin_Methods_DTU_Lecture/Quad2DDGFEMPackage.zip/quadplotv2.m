function quadplotv2(EToV,VX,VY,str)
% function quadplot(EToV,VX,VY,str)
%
% plot quadrilaterals
%
% By Allan P. Engsig-Karup, apek@imm.dtu.dk.
%
plot(VX(EToV(:,[1 2 3 4 1]))',VY(EToV(:,[1 2 3 4 1]))',str)
return
