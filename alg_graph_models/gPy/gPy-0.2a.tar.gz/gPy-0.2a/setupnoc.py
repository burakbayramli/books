#!/usr/bin/env python

from distutils.core import setup

setup(name='gPy',
      version='0.2a',
      description='Modules for graphical modules (no C functions)',
      author='James Cussens',
      author_email='jc@cs.york.ac.uk',
      url='http://www-users.cs.york.ac.uk/~jc/teaching/agm/gPy/',
      packages=['gPy']
      )
