from gPy.Examples import minibn
from gPy.Demos import div_gui

div_gui(minibn['Bronchitis'] * minibn['Smoking'],minibn['Smoking'])
div_gui(minibn['Cancer'] * minibn['Smoking'],minibn['Smoking'])

