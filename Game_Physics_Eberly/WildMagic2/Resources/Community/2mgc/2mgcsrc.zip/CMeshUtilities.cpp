// Anthony Matarazzo
// amatarazzo000007@netzero.net
// Copyright (c) 2000-2002.  All Rights Reserved
//
// Source code from Anthony Matarazzo is supplied under the terms of the GNU
// Public Software license and may not be copied or disclosed except in accordance 
// with the terms of that agreement.  The various license agreements may 
// be found at the Magic Software web site.  This file is subject to the license
//

#pragma warning( disable : 4786 4788 )
#include "CMeshUtilities.h"

using namespace Mgc;

/************************************************************************************
	Function: 

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CMeshUtilities::CMeshUtilities()
{
	m_dwCurrentFace = 0;
	m_lpMesh=NULL;
}

/************************************************************************************
	Function: 

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CMeshUtilities::~CMeshUtilities()
{

}


/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
bool CMeshUtilities::CorrectFaceWinding(Lib3dsMesh *lpMesh)
{
TriangleMeshArray			kNewMeshes;
TriangleMeshArray::iterator pMeshPtr;
ConnectionSet				iConnections;
ConnectionSet::iterator		iSetPtr;
DWORD						dwFace = 0;
DWORD						dwFaceCount = 0;
bool						bRet = false;
Lib3dsFace					*lpNewFaces;

	m_lpMesh = lpMesh;
	if(lpMesh->faces <= 0)
		return true;

	AddConnectionPoints(lpMesh);

	Print("TestTris");
	dwFace=0;
	dwFaceCount=0;
	if(bRet = GetConsistentComponents(kNewMeshes)) {
		lpNewFaces = new Lib3dsFace[lpMesh->faces];

		for(pMeshPtr= kNewMeshes.begin(); pMeshPtr!= kNewMeshes.end();pMeshPtr++) {

			(*pMeshPtr)->GetTriangles(iConnections);
			for(iSetPtr = iConnections.begin(); iSetPtr!= iConnections.end();iSetPtr++) {
				
				// calculate the index of the face based on the position of the pointer. 
				dwFace = (DWORD) GetData(*iSetPtr);
				assert(dwFace <=lpMesh->faces);
				
				// copy orginal face and material
				memcpy(&lpNewFaces[dwFaceCount], &lpMesh->faceL[dwFace], sizeof(Lib3dsFace));
				
				// move over the new connection winding
				lpNewFaces[dwFaceCount].points[0] = iSetPtr->m_aiV[0];
				lpNewFaces[dwFaceCount].points[1] = iSetPtr->m_aiV[1];
				lpNewFaces[dwFaceCount].points[2] = iSetPtr->m_aiV[2];
				dwFaceCount++;
				
			}

			// after the sub mesh is processed. Release the memory associated with it. 
			(*pMeshPtr)->RemoveAllTriangles();
			delete (*pMeshPtr);
		}
	}

	// some faces may have been removed due to the model consistency.
	// see AddConnectionPoints.
	delete []lpMesh->faceL;
	lpMesh->faceL = lpNewFaces;
	lpMesh->faces = dwFaceCount;

	// clean up.
	RemoveAllTriangles();

	return bRet;
}

/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
bool CMeshUtilities::ReverseFaceWinding(Lib3dsMesh *lpMesh)
{
bool						bRet = false;

	// inital prolog 
	m_lpMesh = lpMesh;
	if(lpMesh->faces <= 0)
		return true;

	for(m_dwCurrentFace=0;m_dwCurrentFace<lpMesh->faces; m_dwCurrentFace++) {
		
		// move over the new connection winding
		//lpMesh->faceL[dwFaceCount].points[0] = iSetPtr->m_aiV[0];
		DWORD dwTmp = lpMesh->faceL[m_dwCurrentFace].points[0];
		lpMesh->faceL[m_dwCurrentFace].points[0] = lpMesh->faceL[m_dwCurrentFace].points[2];
		lpMesh->faceL[m_dwCurrentFace].points[2] = dwTmp;
		
	}

	bRet = true;

	return bRet;

}

/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/

void CMeshUtilities::AddConnectionPoints(Lib3dsMesh *lpMesh, bool bFilterTris)
{
DWORD									dwLoop2 = 0;
DWORD									dwLoop3= 0;
const SmallSet<TriangleMesh::Triangle>	*pTriangles = NULL;
	
	if(bFilterTris) {
		AddConnectionPoints(lpMesh);
		return;
	}

	// filter items that do not make the mesh manifold
	for(m_dwCurrentFace=0;m_dwCurrentFace<lpMesh->faces; m_dwCurrentFace++) {
		InsertTriangle(lpMesh->faceL[m_dwCurrentFace].points[0], 
						 lpMesh->faceL[m_dwCurrentFace].points[1], 
						 lpMesh->faceL[m_dwCurrentFace].points[2]);
	}

}

void CMeshUtilities::AddConnectionPoints(Lib3dsMesh *lpMesh)
{
DWORD									dwLoop2 = 0;
DWORD									dwLoop3= 0;
bool									bAdd = false;
const SmallSet<TriangleMesh::Triangle>	*pTriangles = NULL;

	// filter items that do not make the mesh manifold
	for(m_dwCurrentFace=0;m_dwCurrentFace<lpMesh->faces; m_dwCurrentFace++) {

		// assume this face is going to be added. 		
		bAdd = true;
		
		// triangles that the vertex exists twice in
		for(dwLoop2=0;dwLoop2<3 && bAdd;dwLoop2++) {
			for(dwLoop3=0;dwLoop3<3 && bAdd;dwLoop3++) {
				if(dwLoop2!=dwLoop3 && 
					lpMesh->faceL[m_dwCurrentFace].points[dwLoop2] == 
					lpMesh->faceL[m_dwCurrentFace].points[dwLoop3]) {
					bAdd=false;
					break;
				}
			}
		}

		// make sure by adding this triangle the model
		// the vertrcies will be shared twice.
		if(bAdd) {
			for(dwLoop2=0;dwLoop2<3 && bAdd;dwLoop2++) {
				for(dwLoop3=0;dwLoop3<3 && bAdd;dwLoop3++) {					
					pTriangles = GetTriangles(lpMesh->faceL[m_dwCurrentFace].points[dwLoop2], 
													 lpMesh->faceL[m_dwCurrentFace].points[dwLoop3]);
					if(pTriangles) {
						if(pTriangles->GetSize()>1) {
							bAdd = false;
							break;

						} 
						
						else {
							DWORD dwMatch=0;
							DWORD dwLoop4=0;
							DWORD dwLoop5=0;
							DWORD dwLoop6=0;

							const TriangleMesh::Triangle& pTri = (*pTriangles)[dwLoop4];
							//
							// ensure we are only adding one triangle with the specified verticies 
							for(dwLoop4=0;dwLoop4<(*pTriangles).GetSize() && bAdd;dwLoop4++) {
								

								for(dwLoop5=0;dwLoop5<3;dwLoop5++) {
									for(dwLoop6=0;dwLoop6<3;dwLoop6++) {
										if( pTri.m_aiV[dwLoop5] == 
												lpMesh->faceL[m_dwCurrentFace].points[dwLoop6]) {
											dwMatch++;
										}
									}
								}
								
								// should not be an existing triangle.
								if(dwMatch>=3) {							
									bAdd = false;
									break;
								}
							}
						}

					}
				}
			}			
		}
		
		
		// add the triangle if appropiate.
		if(bAdd) 
			InsertTriangle(lpMesh->faceL[m_dwCurrentFace].points[0], 
							 lpMesh->faceL[m_dwCurrentFace].points[1], 
							 lpMesh->faceL[m_dwCurrentFace].points[2]);
	}
}



/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CMeshUtilities::OnTriangleInsert (const Triangle& rkT, bool bCreate, void*& rpvData)
{
	// set reference to  the face array, so after the triangle mesh has been rewound,
	// we can perserve the material states.
	if(bCreate)
		rpvData =(LPVOID) m_dwCurrentFace;

}

void CMeshUtilities::OnTriangleRemove (const Triangle&, bool bDestroy, void* pvData)
{
    if ( bDestroy )
        m_dwCurrentFace = (DWORD) pvData;
}


