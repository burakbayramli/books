#ifndef CPOLY2TRI_H
#define CPOLY2TRI_H

#include <windows.h>
#include <vector>

#include <math.h>

using namespace std ;

#define M_PI 3.142857f
#define BIG 1.0e30	/* A number bigger than we expect to find here */
#define COUNTER_CLOCKWISE 0
#define CLOCKWISE 1

typedef struct {
	DWORD dwVertexIndex;
	bool bHole;
    float x, y, z;
} Vertex, *LPVertex;

typedef vector<LPVertex, allocator<LPVertex> > VertexArray;

class  CPoly2Tri
{

public:
	CPoly2Tri();
	~CPoly2Tri();

	long AddVertex(DWORD dwVertexIndex, bool bHole,float x,float y,float z);
	void ClearVerticies(void);
	long BuildTriangles();
	LPVertex getTriangle(int iTriangle);
	DWORD getTriangleIndex(DWORD ldIndex);
	DWORD ComputeTriangulatedVerticies(DWORD dwVerticies);

private:
	bool OutputTriangle(VertexArray lpTriangle);
	void ClearTriangleList(void);
	float vect_angle (Vertex *v1, Vertex *v2);
	void cross_prod (Vertex *v1, Vertex *v2, Vertex *v3);
	float dot_prod (Vertex *v1, Vertex *v2);
	float vect_mag (Vertex *v);
	void vect_scale (Vertex *v, float  k);
	void vect_sub (Vertex *v1, Vertex *v2, Vertex *v3);
	void vect_add (Vertex *v1, Vertex *v2, Vertex *v3);
	void vect_copy (Vertex *v1, Vertex *v2);
	void vect_init (Vertex *v, float  x, float  y, float  z);
	int poly_inside (VertexArray poly, int polysize, Vertex *v);

protected:
	VertexArray m_Triangles;
	VertexArray m_lpVertex;

};

#endif




