//#include <stdafx.h>
#include <windows.h>

#include "BTDefines.h"
#include "CBTCDecoderJPG.h"

CBTCDecoderJPG::CBTCDecoderJPG()
{
	mb_Init = false;
	if( ijlInit( &m_jpg_image ) == IJL_OK )
		mb_Init = true;

	mby_Buffer = NULL;
}

CBTCDecoderJPG::~CBTCDecoderJPG()
{
	if(m_jpg_image.DIBBytes) {
		delete []m_jpg_image.DIBBytes;
		m_jpg_image.DIBBytes=NULL;
	}
	delete []mby_Buffer;

	ijlFree(&m_jpg_image);
}

/////////////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////////////

const char *CBTCDecoderJPG::GetFormat()      { return "JPG"; }
const char *CBTCDecoderJPG::GetDescription() { return "Jpeg Decompression"; }
const char *CBTCDecoderJPG::GetExtension()   { return "jpg"; }

/////////////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////////////

long CBTCDecoderJPG::IsValidType(BTCIStream* pIStream)
{
	long lResult = BTFILETYPE_UNKNOWN;

	if(!mb_Init)
		return lResult;

	if(!pIStream)
		return lResult;

	if( pIStream->Seek( 0L, BTCIOStream::Begin) == -1)
		return lResult;
	
	//pIStream->
	long lSize = pIStream->GetSize();

	if( -1 == lSize)
		return lResult;

	// read the stream in.
	mby_Buffer = new BYTE[lSize];
	pIStream->Read(mby_Buffer, lSize);

	// read the header
	m_jpg_image.JPGBytes = mby_Buffer;
	m_jpg_image.JPGSizeBytes = lSize;

	if( ijlRead(&m_jpg_image, IJL_JBUFF_READHEADER)== IJL_OK )
		lResult = BTFILETYPE_INTEL_JPG;

	return lResult;
}


/////////////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////////////

bool CBTCDecoderJPG::Load(	BTCIStream*              pIStream,
							BTCImageData*            pImageData,
							BTIProgressNotification* pProgressNotification /* = NULL */,
							BTCDecoderOptions*       pOptions /* = NULL */)
{
	if(!pIStream || !pImageData)
		return false;

	long lSize = pIStream->GetSize();

	if( -1 == lSize)
		return false;

	// read the header
	m_jpg_image.JPGBytes = mby_Buffer;
	m_jpg_image.JPGSizeBytes = lSize;

	if( ijlRead(&m_jpg_image, IJL_JBUFF_READPARAMS)!= IJL_OK )
		return false;

	if(!pImageData->Create( m_jpg_image.JPGWidth, m_jpg_image.JPGHeight, 24))
		return false;

	// set up the buffers to read the image into the DIB format
    switch(m_jpg_image.JPGChannels) {
		case 1:
			m_jpg_image.JPGColor    = IJL_G;
		    m_jpg_image.DIBChannels = 3;
			m_jpg_image.DIBColor    = IJL_BGR;
			break;

		case 3:
			m_jpg_image.JPGColor    = IJL_YCBCR;
			m_jpg_image.DIBChannels = 3;
			m_jpg_image.DIBColor    = IJL_BGR;
			break;

		case 4:
			m_jpg_image.JPGColor    = IJL_YCBCRA_FPX;
			m_jpg_image.DIBChannels = 4;
			m_jpg_image.DIBColor    = IJL_RGBA_FPX;
			break;

		default:
			// This catches everything else, but no
			// color twist will be performed by the IJL.
			m_jpg_image.DIBColor = (IJL_COLOR)IJL_OTHER;
			m_jpg_image.JPGColor = (IJL_COLOR)IJL_OTHER;
			m_jpg_image.DIBChannels = m_jpg_image.JPGChannels;
			break;
    }

	// set the size aspects of the image. 
    m_jpg_image.DIBWidth    = m_jpg_image.JPGWidth;
    m_jpg_image.DIBHeight   = m_jpg_image.JPGHeight;
	m_jpg_image.DIBPadBytes = 0;

	// calcualte the total number of bytes rquired for storage.
    int imageSize = (m_jpg_image.DIBWidth * m_jpg_image.DIBChannels + m_jpg_image.DIBPadBytes) *
				      m_jpg_image.DIBHeight;

    LPBYTE lpImageData = new BYTE[imageSize];
    if( lpImageData == NULL ) {
		return false;
    }

	if(m_jpg_image.DIBBytes) {
		delete []m_jpg_image.DIBBytes;
		m_jpg_image.DIBBytes=NULL;
	}

	m_jpg_image.DIBBytes = lpImageData;

	// decompress in image into the DIB
	if( ijlRead(&m_jpg_image, IJL_JBUFF_READWHOLEIMAGE)!= IJL_OK )
		return false;
	
	int		xx=0;
	int		yy=0;
	long	lCount=0;

	for(lCount=0;lCount<imageSize;lCount+=m_jpg_image.DIBChannels) {
		// if has alpha component, convert
		if(m_jpg_image.DIBColor==IJL_RGBA_FPX) {
			DWORD dwAplha = lpImageData[lCount+3];

			pImageData->SetColorForPixel( xx++, yy, BTRGB(	(lpImageData[lCount+2] * dwAplha +1) >> 8, 
															(lpImageData[lCount+1] * dwAplha +1) >> 8, 
															(lpImageData[lCount  ] * dwAplha +1) >> 8 ));
		} else {
			pImageData->SetColorForPixel( xx++, yy, BTRGB(	lpImageData[lCount+2], 
															lpImageData[lCount+1], 
															lpImageData[lCount  ]));
		}

		if(xx>=m_jpg_image.DIBWidth) {
			yy++;
			xx=0;

			// Step progress.
			if( pProgressNotification) 
				pProgressNotification->OnProgress( (int)((100.0 / m_jpg_image.DIBHeight) * yy) + 1);

		}
	}

	return true;
}
