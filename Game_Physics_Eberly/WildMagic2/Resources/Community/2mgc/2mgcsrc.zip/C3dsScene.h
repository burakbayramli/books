
#ifndef C3DSSCENE_H
#define C3DSSCENE_H

#include <windows.h>
#include <iostream.h>
#include <objbase.h>
#include <lib3ds/file.h>
#include <lib3ds/chunk.h>

#include "CConverter.h"
#include "CImageConverter.h"
#include "ErrorCodes.h"
#include "CIndirectindex.h"
#include "CMeshUtilities.h"

#include <set>

using namespace Mgc;
using namespace std;

typedef struct {
	DWORD	dwBegin;
	DWORD	dwFaceCount;
	char	*lpMaterialName;
} MeshMaterialList, *LPMeshMaterialList;

typedef struct {
	char		szName[255];
	TexturePtr	pkTexture;
} SharedTexture, *LPSharedTexture;


typedef vector<char *, allocator<char *> > StringArray;
typedef vector<MeshMaterialList, allocator<MeshMaterialList> > MeshMaterialListArray;
typedef vector<SharedTexture, allocator<SharedTexture> > SharedTextureArray;

class C3DSScene : public CConverter
{
public:
	C3DSScene();
	~C3DSScene();
	long Convert(void);
	
private:
	long				LoadScene(char *szFilename);
	Lib3dsMaterial		*FindMaterial(char *szCurrentMaterial);
	void				BuildMgcModel(Node *pParent, Lib3dsMesh *lpMesh);
	void				AddFacetoMgcModelData(Lib3dsMesh *lpMesh, long lFace, CIndirectIndex *lpIndirect, bool bTwoSided);
	long				LoadTransformMatrix(Node *pParent, Lib3dsMatrix matrix);
	bool				LoadMaterial(TriMesh	*pMesh, LPMeshMaterialList lpMaterialItem);
	void				ClearNames();
	void				SaveNames(char *szFilename);
	long				Dump3DSData(char cData);
	void				AddTexture(char *szName, TexturePtr pkTexture);
	TexturePtr			GetTexture(char *szName);

private:	
    NodePtr				m_spkScene;
	NodePtr				m_Trans;

	int					*m_aiConnect;
	Vector3				*m_akVertex;
	Vector3				*m_akNormal;
	ColorRGB			*m_akColor;
	Vector2				*m_akTexture;

	DWORD				m_dwVertexCount;
	DWORD				m_dwConnectionCount;

	DWORD				m_dwVertexAllocatedSize;
	DWORD				m_dwConnectionAllocatedSize;
	DWORD				m_dwTotalTriangles;
	StringArray			m_ObjNames;
	Lib3dsFile			*m_3DSReader;
	SharedTextureArray  m_SharedTextures;

};

#endif
