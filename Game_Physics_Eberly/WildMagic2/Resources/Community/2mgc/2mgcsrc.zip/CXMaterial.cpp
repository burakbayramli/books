#include "CXMaterial.h"
#include "CImageConverter.h"

CXMaterial::CXMaterial()
{
	m_pkTexture = NULL;
    m_pkImage = NULL;
	szTextureFilename=NULL;
	szTextureDirectories=NULL;
	m_szName=NULL;
}

CXMaterial::~CXMaterial()
{

	if(szTextureFilename) {
		delete []szTextureFilename;
		szTextureFilename = NULL;
	}
	
	if(szTextureDirectories) {
		delete []szTextureDirectories;
		szTextureDirectories = NULL;
	}

	if(m_szName) {
		delete []m_szName;
		m_szName=NULL;
	}

}

Texture* CXMaterial::getMgcTexture()
{
// convert bmp file to mif format
CImageConverter		*lpImageConverter;

	if(!szTextureFilename) {
		return NULL;
	}
		//void CImageConverter::SetResize(int iWidth, int iHeight, BTResizeFilter lResFilter)
		
	// get the image from disk.
	lpImageConverter = new CImageConverter();
	lpImageConverter->setInputFile(szTextureFilename);		
	lpImageConverter->setTextureDirectories(szTextureDirectories);
	m_pkImage = lpImageConverter->ConvertToMgcImage();
	if(m_pkImage) {
		
		if(!m_pkImage)
			return NULL;

		// new texture
		if(m_pkTexture) {
			delete m_pkTexture;
			m_pkTexture = NULL;
		}

		m_pkTexture = new Texture;	
		if ( !m_pkTexture ) 
			return NULL;

		m_pkTexture->SetImage(m_pkImage);
		m_pkTexture->Filter() = Texture::FM_LINEAR;
		m_pkTexture->Mipmap() = Texture::MM_LINEAR;
		m_pkTexture->Wrap() = Texture::WM_CLAMP_S_CLAMP_T;
		
		// return the creation
		return m_pkTexture;
	}

	delete lpImageConverter;			
	lpImageConverter=NULL;

	return NULL;

}

