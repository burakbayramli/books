#ifndef CXMESHDATA
#define CXMESHDATA

#include <windows.h>
#include <vector>

#include "D3d8types.h"
#include "dxfile.h"
#include "rmxfguid.h"

#include <MgcAnimation.pkg>
#include "ErrorCodes.h"
#include "CPoly2tri.h"

using namespace Mgc;
using namespace std;

typedef struct {
	vector<DWORD, allocator<DWORD> > Faces;
} FaceArray, *LPFaceArray;

typedef struct {
	DWORD		dwVertexIndex;
	ColorRGB	vColor;
} VertexIndexColor, *LPVertexIndexColor;

typedef vector<Vector3, allocator<Vector3> > VerticiesArray;
typedef vector<Vector3, allocator<Vector3> > NormalArray;
typedef vector<FaceArray, allocator<FaceArray> > FaceConnectorArray;
typedef vector<Vector2, allocator<Vector2> > TextureCordinateArray;
typedef vector<DWORD, allocator<DWORD> > MaterialListArray;
typedef vector<VertexIndexColor, allocator<VertexIndexColor> >	VertexColorArray;

class CXMeshData
{
	
public:
	CXMeshData();
	CXMeshData(bool bVal);
	~CXMeshData();

	long		GetMeshData(LPDIRECTXFILEDATA pFileData);

	
	DWORD		MaterialListCount(void);
	DWORD		MaterialList(DWORD dwFace);

	DWORD		FaceCount(void);

	DWORD		VertexCount(void);
	DWORD		VertexCount(DWORD dwFace);
	DWORD		VertexIndex(DWORD dwFace, DWORD dwVertex);	

	Vector3		Vertex(DWORD dwVertexIndex);
	Vector3		LightingNormal(DWORD dwVertexIndex);
	Vector2		TextureCordinates(DWORD dwVertexIndex);
	DWORD		NumTriangles();
	long		NormalsCount(void);

	long		TextureCordinateCount();

	DWORD		NumMaterialSeq(DWORD dwBegin);
	DWORD		NumMaterialSeqConnections(DWORD dwBegin);
	ColorRGB	VertexColor(DWORD	dwVertex);
	long		VertexColorCount(void);

private:
	long GetMeshVerticies(LPBYTE *pData);
	long GetMeshFaceIndicies(LPBYTE *pData);
	long GetMeshMaterialList(LPDIRECTXFILEDATA pFileData);
	long GetMeshLightingNormals(LPDIRECTXFILEDATA pFileData);
	long GetMeshTextureCordinates(LPDIRECTXFILEDATA pFileData);
	long GetMeshVertexColors(LPDIRECTXFILEDATA pFileData);

	void Clean(void);
	void Init(void);

private:
	VerticiesArray			m_Vertex;
	FaceConnectorArray		m_Connect;
	MaterialListArray		m_MaterialList;
	NormalArray				m_Normals;
	TextureCordinateArray	m_Texture;
	VertexColorArray		m_VertexColors;

	bool					m_bCalcNormals;

};
#endif
