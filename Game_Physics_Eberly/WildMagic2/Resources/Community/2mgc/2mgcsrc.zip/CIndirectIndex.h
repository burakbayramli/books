#ifndef CINDIRECTINDEX
#define CINDIRECTINDEX

#include <windows.h>

class CIndirectIndex
{
public:
	CIndirectIndex();
	CIndirectIndex(DWORD dwMaxSize);
	~CIndirectIndex();

	void Clear(void);
	DWORD getVertexStorageIndex(DWORD dwVertexIndex);
	void setVertexStorageIndex(DWORD dwStorageIndex, DWORD dwVertexIndex);
	bool AlreadyStoredVertex(DWORD dwVertexIndex);
	

private:	
	DWORD					*m_IndexArray;
	DWORD					m_IndexArraySize;

};

#endif
