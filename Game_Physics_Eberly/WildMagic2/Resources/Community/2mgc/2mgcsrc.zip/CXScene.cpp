#pragma warning( disable : 4786 4788 )
#define INITGUID

#include "rmxftmpl.h"
#include "CXScene.h"
#include <MgcAnimation.pkg>
#include <d3d8.h>
#include <d3dx8math.h>
#include <d3dx8tex.h>

#include "ErrorCodes.h"
#include "CPoly2tri.h"

CXScene::CXScene()
{
    m_spkScene=NULL;
	m_Trans=NULL;

	m_aiConnect=NULL;
	m_akVertex=NULL;
	m_akNormal=NULL;
	m_akTexture=NULL;
	m_akColor=NULL;
	m_dwVertexCount=0;
	m_dwConnectionCount=0;
	m_dwTotalTriangles=0;

}

CXScene::~CXScene() 
{

}

/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXScene::Convert(void)
{
	long lRet;

	// create the initial node 
	m_spkScene = new Node;
	assert(m_spkScene!=NULL);

	// set the rotation matrix so that it converts LHC to RHC
	Matrix3 kRot, kIncr;

	kRot = Matrix3 (1.0f, 0.0f, 0.0f,
					0.0f, 1.0f, 0.0f,
					0.0f, 0.0f, -1.0f);

	kIncr.FromAxisAngle(Vector3::UNIT_Y, 3.141592654f);

	m_spkScene->Rotate() = kIncr*kRot;
		

	// build the translation vector. this is the last row of the 4x4 ded matrix.
	// and move to the current MGC node.
//	pParent->Translate() =Vector3(1.0f, 1.0f, -1.0f);

	// add light optiong
	if(m_AddLight) {
		// add lights 
		LightStatePtr lpLightState;
		lpLightState = new LightState();

		DirectionalLight	*lpLight;
		lpLight = new DirectionalLight();
		lpLight->Ambient() = ColorRGB(0.5f,0.5f,0.5f);
		lpLight->Diffuse() = ColorRGB(0.7f,0.7f,0.7f);
		lpLight->Specular() = ColorRGB(0.2f,0.2f,0.2f);

		lpLightState->Attach(lpLight);
		m_spkScene->SetRenderState(lpLightState);
	}

	
	cout << m_szInputFile << flush;

	lRet = LoadScene(m_szInputFile);

	if(lRet==C_SUCCESS) {
		// save out the MGC file using the 
		// expertly crafted stream system!
		cout << "\b" << "\x01" << flush; // smile it is done.
		Stream m_Stream;
		m_Stream.Insert(m_spkScene);	
		m_Stream.Save(m_szOutputFile);
		cout << "\bmgc - (" << m_dwTotalTriangles << " tris)\n" << flush;
	} else {

		cout << "\nConversion error : ";
		switch(lRet) {
			case C_ERR_CANNOT_CREATE_XOFAPI:
				cout << "Cannot create xofapi.\nPlease make sure direct x is install on this computer.\n\n" << flush;
				break;

			case C_ERR_CANNOT_REGISTER_XTEMPLATES:
				cout << "Cannot Register xTemplates.\nPlease make sure direct x is install on this computer.\n\n" << flush;
				break;

			case C_ERR_CANNOT_CREATE_XENUM:
				cout << "X File format error. Cannot create enumeration object.\n\n" << flush;
				break;

			case C_ERR_CANNOT_GET_XTYPE:
				cout << "X File format error. Could not get chunk type.\n\n" << flush;
				break;

			case C_ERR_CANNOT_GET_XMATRIX:
				cout << "X File format error. Could not get the rotation and translation matrix.\n\n" << flush;
				break;

			case C_ERR_CANNOT_GET_XDATA:
				cout << "X File format error. Could not get the byte data.\n\n" << flush;
				break;
		}
	}
	
	// clean up
	delete m_spkScene;

	return lRet;

}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXScene::LoadScene(char *szFilename)
{
HRESULT					hr;
LPDIRECTXFILE			pxofapi = NULL;
LPDIRECTXFILEENUMOBJECT pxofenum = NULL;
LPDIRECTXFILEDATA		pxofobj	= NULL;
long					lRet = C_SUCCESS;

	hr = S_OK;

    // Using a do/while(FALSE) loop instead of goto for errors...
    do {
        // Create xofapi object.
        hr = DirectXFileCreate(&pxofapi);
        if (FAILED(hr)) {
			lRet = C_ERR_CANNOT_CREATE_XOFAPI;
            break;
		}

        // Registe templates for d3drm.
        hr = pxofapi->RegisterTemplates((LPVOID)D3DRM_XTEMPLATES,
                                        D3DRM_XTEMPLATE_BYTES);
        if (FAILED(hr)) {
			lRet = C_ERR_CANNOT_REGISTER_XTEMPLATES;
            break;
		}

        // Create enum object.
        hr = pxofapi->CreateEnumObject(szFilename,
                                       DXFILELOAD_FROMFILE,
                                       &pxofenum);
        if (FAILED(hr)) {
			lRet = C_ERR_CANNOT_CREATE_XENUM;
            break;
		}

		CXMaterialArray lpBaseMaterial;

        // iterate the objects in the list
        while (SUCCEEDED(pxofenum->GetNextDataObject(&pxofobj))) {
			lRet = LoadFrame(pxofobj, m_spkScene, &lpBaseMaterial);
			pxofobj->Release();
		}

		if(!lpBaseMaterial.empty()) {
			for(int i=0;i<lpBaseMaterial.size();i++)
				delete lpBaseMaterial[i];

			lpBaseMaterial.clear();
		}
		
		if(m_bSaveNames)
			SaveNames(szFilename);

		ClearNames();
		pxofenum->Release();
		pxofenum=NULL;

    } while (FALSE);

    // Clean up any interfaces we still have
    if (pxofenum)
        pxofenum->Release();

    if (pxofapi)
        pxofapi->Release();

	return lRet;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXScene::LoadFrame(LPDIRECTXFILEDATA pFileData, Node *pParent, CXMaterialArray	*lpMaterial)
{
	
    LPDIRECTXFILEDATA		pChildData = NULL;
    LPDIRECTXFILEOBJECT		pChildObj = NULL;
    const GUID*				pGUID;
    HRESULT					hr;
	Node					*lpTrans;	
	Node					*lpCurrent;
	long					lRet;

    // iterate the objects in the list
	// Get the type of the object
	if( FAILED( hr = pFileData->GetType( &pGUID ) ) )
		return C_ERR_CANNOT_GET_XTYPE;

	//char *szAni="\x01\x02";
	//cout << "." << flush;
	
	// set the head of the tree to the parent for this recursive instance
	lpCurrent = pParent;


	if( *pGUID == TID_D3DRMMesh )    {
		// Load the mesh object 
		if( (lRet=LoadMesh( pFileData, lpCurrent, *lpMaterial)) != C_SUCCESS)
			return lRet;

	} else if( *pGUID == TID_D3DRMFrameTransformMatrix ) {		
		SetObjectName(pFileData, pParent );
		if( (lRet=LoadTransformMatrix(pFileData, lpCurrent)) != C_SUCCESS)
			return lRet;

	} else if( *pGUID == TID_D3DRMMaterial ) {
		// Load the material
		if( (lRet=LoadMaterial(pFileData, lpMaterial)) != C_SUCCESS)
			return lRet;

	} else if( *pGUID == TID_D3DRMFrame )  {

		CXMaterialArray			lpSubMaterial;

		// Frames are containers so enumerate child objects
		while( SUCCEEDED( pFileData->GetNextObject(&pChildObj))) {

			// Query the child for it's FileData
			hr = pChildObj->QueryInterface( IID_IDirectXFileData, (VOID**)&pChildData );

			if( SUCCEEDED(hr) ) {
				// recursively call this routine with 
				// the new node. 
				lpTrans = new Node;
				assert(lpTrans!=NULL);
				lpCurrent->AttachChild(lpTrans);
				lpCurrent = lpTrans;
				hr = LoadFrame( pChildData, lpTrans, &lpSubMaterial);
				pChildData->Release();

			}

			pChildObj->Release();

			if( FAILED(hr) )
				return hr;
		}

		lpCurrent = pParent;

		if(!lpSubMaterial.empty()) {
			for(int i=0;i<lpSubMaterial.size();i++)
				delete lpSubMaterial[i];

			lpSubMaterial.clear();
		}

		

	}
	
    return C_SUCCESS;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CXScene::SaveNames(char *szFilename)
{
FILE	*f1;
char	*lpPos;
char	szTmpFileName[MAX_PATH];
char	szHeaderTemplateName[255];
char	szUpperName[255];
char	*ptr;

	strcpy(szTmpFileName, szFilename);
	
	// chop off the other extension
	lpPos = strstr(szTmpFileName,".");
	if(lpPos)
		szTmpFileName[lpPos - szTmpFileName] = 0x00;

	lpPos=strrchr(szTmpFileName, '\\');
	
	if(lpPos) {
		strcpy(szHeaderTemplateName,lpPos +1);

		for (ptr = szHeaderTemplateName; *ptr; ptr++)
			*ptr = toupper( *ptr );

	} else {
		strcpy(szHeaderTemplateName,"XMODEL");
	}

	strcat(szTmpFileName, ".h");


	f1= fopen(szTmpFileName, "w+");
	if(f1) {

		fprintf(f1,"#ifndef %s_MODEL_H\n", szHeaderTemplateName);
		fprintf(f1,"#define %s_MODEL_H\n\n\n", szHeaderTemplateName);

		if(m_ObjNames.empty()) {
			fprintf(f1,"// No names were found.\n");
	
		} else {
			for(int i=0;i<m_ObjNames.size();i++) {
				// convert the defined name ot upper
				strcpy(szUpperName, m_ObjNames[i]);
				for (ptr = szUpperName; *ptr; ptr++) {
					*ptr = toupper( *ptr );
					if(*ptr=='-') *ptr='_';
				}

				fprintf(f1,"#define C_%s_%s \"%s\"\n", szHeaderTemplateName, szUpperName, m_ObjNames[i]);

			}
		}

		fprintf(f1,"\n#endif\n\n");

		fclose(f1);
	}
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CXScene::SetObjectName( LPDIRECTXFILEDATA pFileData, Node *pParent )
{
DWORD				dwNameLength;
LPSTR				lpName;

    pFileData->GetName( NULL, &dwNameLength );
	if(dwNameLength) {
		lpName = new char[dwNameLength+1];		
	    pFileData->GetName( lpName, &dwNameLength );

		pParent->SetName(lpName);
		m_ObjNames.push_back(lpName);
	}
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CXScene::ClearNames()
{
	if(!m_ObjNames.empty()) {
		for(int i=0;i<m_ObjNames.size();i++)
			delete []m_ObjNames[i];

		m_ObjNames.clear();
	}
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXScene::LoadMesh(LPDIRECTXFILEDATA pFileData, Node *pParent, CXMaterialArray	lpMaterial)
{
TriMeshPtr			pkMesh=NULL;
CXMeshData			*pMeshModelData=NULL;
long				lRet;
CIndirectIndex		*lpIndirect=NULL;
DWORD				dwCurrentMaterial=0xFFFF;
DWORD				dwFace=0;
DWORD				dwConnections;
DWORD				dwVertex;
DWORD				dwNameLength = 0;
LPSTR				lpName = NULL;

	cout << "\b" << "\xA8" << flush; // Reading

	// get the name for this object 
    pFileData->GetName( NULL, &dwNameLength );
	if(dwNameLength) {
		lpName = new char[dwNameLength+1];		
	    pFileData->GetName( lpName, &dwNameLength );
		m_ObjNames.push_back(lpName);
	}

	// this class loads all the information for a single mesh
	// the single X mesh will break down into several MGC meshes due to the 
	// material count.
	pMeshModelData = new CXMeshData(m_bForceNormalCalculation);
	if ( (lRet = pMeshModelData->GetMeshData(pFileData)) !=C_SUCCESS)
		return lRet;		

	// this class simply holds the storage index of the 
	// vertex, texture and normal data
	lpIndirect = new CIndirectIndex(pMeshModelData->VertexCount());
	
	if(pMeshModelData->FaceCount() > pMeshModelData->MaterialListCount()) {
		
		// allocate storage for the model
		dwConnections = pMeshModelData->NumTriangles();
		m_aiConnect= new int[dwConnections];
		m_dwConnectionAllocatedSize=dwConnections;

		// calculate the number of verticies in the next one
		dwVertex = pMeshModelData->VertexCount();
		m_dwVertexAllocatedSize=dwVertex;

		m_akVertex = new Vector3[dwVertex];

		if(pMeshModelData->TextureCordinateCount()!=-1)
			m_akTexture= new Vector2[dwVertex];
		else
			m_akTexture=NULL;

		if(!m_bForceNormalCalculation && pMeshModelData->NormalsCount()!=-1 ) {
			m_akNormal= new Vector3[dwVertex];
		} else {
			m_akNormal= NULL;
		}

		// place all the data into the MGC model arrays.
		for(dwFace=0;dwFace<pMeshModelData->FaceCount(); dwFace++)
			AddFacetoMgcModelData(pMeshModelData, dwFace, lpIndirect);
		

	} else {
 		dwCurrentMaterial=0xFFFF; // first time control break;;;

		dwFace=0;
		do {		
			
			// if the face material is the same
			// add the corresponding vertex, texture cordinates, 
			// and connection indicies to the MGC model
			// the MGC Model consists of m_akVertex, m_akNormals, m_akTexture, m_aiConnect
			if(dwCurrentMaterial== pMeshModelData->MaterialList(dwFace)) {
				AddFacetoMgcModelData(pMeshModelData, dwFace, lpIndirect);
				dwFace++;

			} else {		

				// build a model only if verticies exists. IE is this the first time through?
				if(m_dwVertexCount) {
					// build the MGC model with the currrent material
					CXMaterial *curMaterial = NULL;
					if(!lpMaterial.empty()) {
						assert(dwCurrentMaterial<=lpMaterial.size());
						curMaterial= lpMaterial[dwCurrentMaterial];
					}

					BuildMgcModel(pParent, curMaterial, lpName);
				}
				
				// reset the data for this sub mesh
				lpIndirect->Clear();
				m_dwConnectionCount=0;
				m_dwVertexCount=0;
				
				// calculate the number of triangulated faces on the next set of materailized faces.
				dwConnections = pMeshModelData->NumMaterialSeqConnections(dwFace);
				m_aiConnect= new int[dwConnections];
				m_dwConnectionAllocatedSize=dwConnections;

				// calculate the number of verticies in the next one
				dwVertex = pMeshModelData->NumMaterialSeq(dwFace);
				m_dwVertexAllocatedSize=dwConnections;

				m_akVertex = new Vector3[dwConnections];

				if(pMeshModelData->TextureCordinateCount()!=-1)
					m_akTexture= new Vector2[dwConnections];
				else
					m_akTexture=NULL;

				if(!m_bForceNormalCalculation && pMeshModelData->NormalsCount()!=-1 ) {
					m_akNormal= new Vector3[dwConnections];
				} else {
					m_akNormal= NULL;
				}

				if(pMeshModelData->VertexColorCount()!=-1 ) {
					m_akColor = new ColorRGB[pMeshModelData->VertexCount()];
				} else  {
					m_akColor = NULL;
				}

				// set the control break 
				dwCurrentMaterial= pMeshModelData->MaterialList(dwFace);

			}
		} while (dwFace<pMeshModelData->MaterialListCount());
	}

	// build a model only if verticies exists.
	if(m_dwVertexCount) {
		// build the MGC model with the currrent material
		CXMaterial *curMaterial = NULL;
		if(!lpMaterial.empty()) {
			assert(dwCurrentMaterial<=lpMaterial.size());
			curMaterial= lpMaterial[dwCurrentMaterial];
		}

		BuildMgcModel(pParent, curMaterial, lpName);
	}

	m_dwConnectionCount=0;
	m_dwVertexCount=0;

	delete lpIndirect;
	delete pMeshModelData;

    return C_SUCCESS;
}

/************************************************************************************
	Function

	Parameters

	Returns
	    
	Description
		Update the parents matrix with the new one        

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXScene::LoadTransformMatrix(LPDIRECTXFILEDATA pFileData, Node *pParent)
{
D3DMATRIX	*pD3DMatrix;
HRESULT		hr;
Matrix3		matTrans;
Vector3		vecTrans;
DWORD		cbSize;


	// get the transform from the x file 
    hr = pFileData->GetData( NULL, &cbSize, (VOID**)&pD3DMatrix );
    if( FAILED(hr) )
        return C_ERR_CANNOT_GET_XMATRIX;
	
	// move the contents from the d3d format to the MGC format
	// notice the rows and columns are reversed. 	
	matTrans = Matrix3 (pD3DMatrix->_11, pD3DMatrix->_21, pD3DMatrix->_31,
						pD3DMatrix->_12, pD3DMatrix->_22, pD3DMatrix->_32,
						pD3DMatrix->_13, pD3DMatrix->_23, pD3DMatrix->_33);

	// set the rotation matrix.
	pParent->Rotate() = matTrans;

	// build the translation vector. this is the last row of the 4x4 ded matrix.
	// and move to the current MGC node.
	vecTrans = Vector3(pD3DMatrix->_41, pD3DMatrix->_42, pD3DMatrix->_43);
	pParent->Translate() =vecTrans;
	return C_SUCCESS;
}
	
/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXScene::LoadMaterial(LPDIRECTXFILEDATA pFileData, CXMaterialArray *lplpMaterialArry)
{
HRESULT					hr;
LPDIRECTXFILEDATA		pChildData = NULL;
LPDIRECTXFILEOBJECT		pChildObj = NULL;
PBYTE					pData = NULL;
DWORD					cbSize = 0;
const GUID				*pGUID;
CXMaterial				*lpMaterial = NULL;
D3DCOLORVALUE			pColor;
	
	// get pointer to data payload 
    hr = pFileData->GetData( NULL, &cbSize, (VOID**)&pData );
    if( FAILED(hr) )
        return C_ERR_CANNOT_GET_XDATA;
	
	// allocate new class 
	lpMaterial = (CXMaterial *) new CXMaterial();
	assert(lpMaterial!=NULL);
	lplpMaterialArry->push_back(lpMaterial);
	
	// popualte the class for use later.
	memcpy(&pColor, pData, sizeof(D3DCOLORVALUE));
	lpMaterial->setD3DRGB(&pColor);
	lpMaterial->setAlpha(&pColor.a);

	pData+=sizeof(D3DCOLORVALUE);

	lpMaterial->setPower((float *)pData);
	pData+=sizeof(float);

	lpMaterial->setSpecularColor((D3DVECTOR *) pData);
	pData+=sizeof(D3DVECTOR);

	lpMaterial->setEmissiveColor((D3DVECTOR *) pData);
	pData+=sizeof(D3DVECTOR);

    // Enumerate child objects
    while( SUCCEEDED( pFileData->GetNextObject(&pChildObj)))  {
        // Query the child for it's FileData
        hr = pChildObj->QueryInterface( IID_IDirectXFileData,
                                        (VOID**)&pChildData );
        if(SUCCEEDED(hr)) {
			// Get the type of the object
			if(FAILED(hr = pChildData->GetType( &pGUID )))
				return C_ERR_CANNOT_GET_XTYPE;
			
			if( *pGUID == TID_D3DRMTextureFilename ) {

				char** string;

				hr = pChildData->GetData( NULL, &cbSize, (VOID**)&string);
				if( FAILED(hr) )
					return C_ERR_CANNOT_GET_XDATA;

				lpMaterial->setTextureFilename(*string);
				lpMaterial->setTextureDirectories(m_szTextureDirectory);

			}

            pChildData->Release();
        }

        pChildObj->Release();

        if( FAILED(hr) )
            return C_ERR_CANNOT_GET_XDATA;
    }

    return C_SUCCESS;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXScene::AddFacetoMgcModelData(CXMeshData *pMeshModelData, 
									DWORD dwFace, 
									CIndirectIndex *lpIndirect)
{
CPoly2Tri				*lpPoly;
DWORD					dwVertex;
DWORD					dwVertexIndex;
DWORD					dwStorageIndex;
DWORD					dwContructedTriangles;
DWORD					dwLoop;


	// Used in the triangulation of polygons
	lpPoly = new CPoly2Tri();
	assert(lpPoly!=NULL);

	// status
	char *sStatus="-|\\|/";
	static int iCnt=0;
	static int iSpeed=0;
	if(++iSpeed>100) {
		iSpeed=0;
		if(++iCnt>4)
			iCnt=0;
		cout << "\b" << sStatus[iCnt] << flush;
	}


	lpPoly->ClearVerticies();
	
#ifdef DEBUG_OUTPUT
	cout << "++++++++++++++++++\n";
#endif

	// iterate the verticies on the face.
	for(dwVertex=0; dwVertex<pMeshModelData->VertexCount(dwFace); dwVertex++) {
		
		// get the face, vertex index 
		dwVertexIndex = pMeshModelData->VertexIndex(dwFace, dwVertex);

		// if the vertex has been NOT stored already 
		// in the MGC Model then generate a new translated index
		// This is done because we are going to produce a separate PKMesh
		// with it's own group of model data for each material.
		if(lpIndirect->AlreadyStoredVertex(dwVertexIndex)) {
			dwStorageIndex = lpIndirect->getVertexStorageIndex(dwVertexIndex);

		} else {					
			// allocate a new position
			dwStorageIndex = m_dwVertexCount;

			// make sure there is room for the item .
			assert(m_dwVertexCount<=m_dwVertexAllocatedSize);

			lpIndirect->setVertexStorageIndex(dwStorageIndex, dwVertexIndex);

			// move all the vertex information to the newly assigned address.
			m_akVertex[dwStorageIndex] = pMeshModelData->Vertex(dwVertexIndex);

			if(m_akTexture)
				m_akTexture[dwStorageIndex] = pMeshModelData->TextureCordinates(dwVertexIndex);

			if(!m_bForceNormalCalculation && m_akNormal) 
				m_akNormal[dwStorageIndex] = pMeshModelData->LightingNormal(dwVertexIndex);

			if(m_akColor)
				m_akColor[dwStorageIndex] = pMeshModelData->VertexColor(dwVertexIndex);

			m_dwVertexCount++;
		}
		
		assert(dwStorageIndex<=m_dwVertexAllocatedSize);

		// place all the polygon faces into the Polygon 2 triangle class
		lpPoly->AddVertex(dwStorageIndex,				// the index of the item. this will be returned back.
						false,								// is it a hole
						m_akVertex[dwStorageIndex].x,	// vertex information linked to the index.
						m_akVertex[dwStorageIndex].y,
						m_akVertex[dwStorageIndex].z);
		
#ifdef DEBUG_OUTPUT
		cout << dwVertexIndex << "\t" << dwStorageIndex << "\n";
#endif

	}

#ifdef DEBUG_OUTPUT
	cout << flush;
#endif

	// now break the polygon into triangles 
	dwContructedTriangles = lpPoly->BuildTriangles();
//	cout << dwContructedTriangles << "\t";

	// now output triangle indexes to the connection stream,
	for(dwLoop=0;dwLoop<dwContructedTriangles;dwLoop++) {
		// get the index of the triangle. 
		assert(m_dwConnectionCount<=m_dwConnectionAllocatedSize);

		m_aiConnect[m_dwConnectionCount] = lpPoly->getTriangleIndex(dwLoop);
		m_dwConnectionCount++;
	}	

	delete lpPoly;
	return C_SUCCESS;
}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CXScene::BuildMgcModel(Node *pParent, CXMaterial *lpXMaterial, char *lpName)
{
TriMesh				*pkMesh=NULL;
TextureStatePtr		spkTexture= NULL;
TexturePtr			pkTexture = NULL;
MaterialStatePtr	lpMaterialState = NULL;

	// first generate the model based on the current data.
	if(m_bForceNormalCalculation  || m_akNormal==NULL ) {			
		pkMesh= new TriMesh(m_dwVertexCount, m_akVertex, NULL, m_akColor, 
							m_akTexture, m_dwConnectionCount / 3, m_aiConnect);
		assert(pkMesh!=NULL);
		pkMesh->UpdateModelNormals();

	} else {
		pkMesh = new TriMesh(m_dwVertexCount, m_akVertex, m_akNormal, m_akColor, 
							m_akTexture, m_dwConnectionCount / 3, m_aiConnect);
		assert(pkMesh!=NULL);

#ifdef DEBUG_OUTPUT
		cout << m_dwVertexCount << "\n";
		int i;
		for(i=0;i<m_dwVertexCount;i++)
			cout << m_akVertex[i].x << "\t" << m_akVertex[i].y << 
						"\t" << m_akVertex[i].z << "\n";

		cout << "Normals\n";
		for(i=0;i<m_dwVertexCount;i++)
			cout << m_akNormal[i].x << "\t" << m_akNormal[i].y << "\t" 
					<< m_akNormal[i].z << "\n";

		cout << "Connections\n";
		for(i=0;i<m_dwConnectionCount;i++)
			cout << m_aiConnect[i] << "\n";
		
		cout << "====================\n" << flush;
#endif

	}

	// update stats
	m_dwTotalTriangles += m_dwConnectionCount / 3;

	// apply the texture if one exists
	if(lpXMaterial) {
		pkTexture = lpXMaterial->getMgcTexture();
		if(pkTexture) {
			spkTexture= new TextureState();
			spkTexture->Set(0,pkTexture);
			pkMesh->SetRenderState(spkTexture);
		}

		// Set the material
		lpMaterialState = new MaterialState();
		assert(lpMaterialState !=NULL);

		lpMaterialState->Emissive() = lpXMaterial->getEmissiveColor();
		lpMaterialState->Ambient() = lpXMaterial->getColorRGB();
		lpMaterialState->Diffuse() = lpXMaterial->getColorRGB();
		lpMaterialState->Specular() = lpXMaterial->getSpecularColor();
		lpMaterialState->Shininess() = lpXMaterial->getPower();
		lpMaterialState->Alpha() = lpXMaterial->getAlpha();
		pkMesh->SetRenderState(lpMaterialState);
	}

	// set hte name of the object 
	if(lpName)	
		pkMesh->SetName(lpName);

	// attach the mesh to passed node.
	assert(pParent!=NULL);
	pParent->AttachChild(pkMesh);

}
