#ifndef CBTCDECODERTIFF_INCLUDED
#define CBTCDECODERTIFF_INCLUDED

#pragma once

#include "BTICodec.h"
#include "tiffio.h"

#ifndef BTFILETYPE_TIFF_ORG
#define BTFILETYPE_TIFF_ORG BTFILETYPE_EXTERN + 3
#endif

class CBTCDecoderTIFF : public BTCDecoder  
{
public:
	CBTCDecoderTIFF();
	virtual ~CBTCDecoderTIFF();

	virtual long IsValidType(BTCIStream* pIStream);

	virtual const char *GetFormat();
	virtual const char *GetDescription();
	virtual const char *GetExtension();

	virtual bool Load(	BTCIStream*              pIStream,
						BTCImageData*            pImageData,
						BTIProgressNotification* pProgressNotification = NULL,
						BTCDecoderOptions*       pOptions = NULL);

private:
	TIFF					*m_tif;

};

#endif 
