#ifndef CIMAGECONVERTER_H
#define CIMAGECONVERTER_H

#include <windows.h>
#include "CConverter.h"
#include <BTCImageData.h>
#include <BTCImageObject.h>
#include <BTNexgenIPL.h>
#include <BTICodec.h>
#include <BTIProgressNotification.h>
#include <BTDefines.h>
#include <BTCColor.h>
#include <BTCOptions.h>
#include <MgcApplication.pkg>
#include "ErrorCodes.h"

#include "CBTCIFStream.h"
#include "CBTCDecoderJPG.h"
#include "CBTCDecoderTIFF.h"

using namespace Mgc;


class CImageConverter : public CConverter
{
public:
	CImageConverter();
	~CImageConverter();

	long Convert(void);	
	void Cleanup(void);

	void setResize(int iWidth, int iHeight, BTCImageData::BTResizeFilter lResFilter);
	void setResize(char *szDimension, char *szFilter);
	BTCImageData::BTResizeFilter Str2Filter(char *szFilter);
	bool ValidFormat(char *szExt);
	Image *ConvertToMgcImage(void);
	bool PreprocessImageData(BTCImageData lpImageData, BTCImageData &lpNewImage);


private:
	HRESULT ConvertToMif(void);
	HRESULT ReadImageBits(char *lpFileName);
	HRESULT FindFile(char *szDirs, char *lpFile, char *szOutput );
	bool	FileExists(char *lpFile);
	bool	InternalFormat(char *szExt);


private:
	unsigned char					*m_aucDst;
	int								m_iResizeWidth;
	int								m_iResizeHeight;
	BTCImageData::BTResizeFilter	m_lResFilter;
    Image*							m_pkImage;
	int								m_iWidth;
	int								m_iHeight;
};

#endif
