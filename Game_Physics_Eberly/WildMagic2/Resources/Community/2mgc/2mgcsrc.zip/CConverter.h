#ifndef CConverter_H
#define CConverter_H

#include <windows.h>
#include <vector>

#define C_DEFAULT_IMAGE_EXT ".MIF"
#define C_DEFAULT_3D_EXT ".MGC"

using namespace std ;

typedef vector<char *, allocator<char *> > StringArray;


class  CConverter
{

public:
	CConverter();
	~CConverter();

	virtual long Convert(void);

	setDisplayVerbose(bool bVerbose);
	setDisplayStats(bool bStats);
	setInputFile(char *szInputFile);
	setTextureDirectories(char *szTextureDirectory);
	setOutputFile(char *szOutputFile);
	setForceNormalCalculations(bool bVal);
	setAddLight(bool bVal);
	setSaveNames(bool bVal);
	setCorrectWinding(bool bVal);
	setReverseMeshes(char *szMesh);
	setReducePolygonCount(DWORD dwCount);
	setDumpData(char *szData);
	setTextureResize(char *szDimension, char *szFilter);

protected:
	bool	m_bVerbose;
	bool	m_bStats;
	bool	m_bForceNormalCalculation;
	bool	m_AddLight;
	bool	m_bSaveNames;
	bool	m_bCorrectWinding;

	char	*m_szInputFile;
	char	*m_szOutputFile;
	char	*m_szTextureDirectory;
	char	*m_szDumpData;
	char	*m_szDimension;
	char	*m_szFilter;

	bool	m_bReducePolygonCount;
	DWORD	m_dwNewPolygonCount;

	bool			m_bReverseAllMeshWindings;
	StringArray		m_ReverseMeshNames;
	

};

#endif
