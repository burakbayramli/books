#ifndef CBTCDECODERJPG_INCLUDED
#define CBTCDECODERJPG_INCLUDED

#pragma once

#include "BTICodec.h"
#include "ijl.h"

#ifndef BTFILETYPE_INTEL_JPG
#define BTFILETYPE_INTEL_JPG BTFILETYPE_EXTERN + 2
#endif

class CBTCDecoderJPG : public BTCDecoder  
{
public:
	CBTCDecoderJPG();
	virtual ~CBTCDecoderJPG();

	virtual long IsValidType(BTCIStream* pIStream);

	virtual const char *GetFormat();
	virtual const char *GetDescription();
	virtual const char *GetExtension();

	virtual bool Load(	BTCIStream*              pIStream,
						BTCImageData*            pImageData,
						BTIProgressNotification* pProgressNotification = NULL,
						BTCDecoderOptions*       pOptions = NULL);

private:
	JPEG_CORE_PROPERTIES	m_jpg_image;
	bool					mb_Init;
	PBYTE					mby_Buffer;

};

#endif 
