#include "CConverter.h"

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::CConverter()
{

	m_bVerbose=false;
	m_bStats=false;
	m_bForceNormalCalculation=false;
	m_AddLight=false;
	m_bSaveNames=false;
	m_bCorrectWinding=false;

	m_szInputFile=NULL;
	m_szOutputFile=NULL;
	m_szTextureDirectory=NULL;
	m_szDimension=NULL;
	m_szFilter=NULL;

	m_szDumpData=NULL;
	m_bReducePolygonCount=FALSE;
	m_dwNewPolygonCount=0;

	m_ReverseMeshNames.clear();
	m_bReverseAllMeshWindings = false;

}


long CConverter::Convert()
{
	return 1;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::~CConverter()
{

	if(m_szInputFile) {
		delete []m_szInputFile;
		m_szInputFile = NULL;
	}

	if(m_szOutputFile) {
		delete []m_szOutputFile;
		m_szOutputFile=NULL;
	}

	if(m_szTextureDirectory) {
		delete []m_szTextureDirectory;
		m_szTextureDirectory = NULL;
	}

}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setDisplayVerbose(bool bVerbose)
{
	m_bVerbose = bVerbose;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setDisplayStats(bool bStats)
{
	m_bStats = bStats;
}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setForceNormalCalculations(bool bVal)
{
	m_bForceNormalCalculation = bVal;
}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setCorrectWinding(bool bVal)
{
	m_bCorrectWinding = bVal;
}



/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setSaveNames(bool bVal)
{
	m_bSaveNames = bVal;
}
/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setAddLight(bool bVal)
{
	m_AddLight = bVal;
}



/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setInputFile(char *szInputFile)
{
	long llLen;
	if(szInputFile) {
		llLen = strlen(szInputFile) +1;

		m_szInputFile = new char[llLen];
		strcpy(m_szInputFile, szInputFile);
	} else {
		if(m_szInputFile) {
			delete []m_szInputFile;
			m_szInputFile = NULL;
		}
	}
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setReverseMeshes(char *szMesh)
{
	long llLen;
	if(szMesh) {
		if(stricmp(szMesh,"ALL")==0) {
			m_bReverseAllMeshWindings = true;

			m_ReverseMeshNames.clear();


		} else {
			// parse the string for sub models. 
			m_bReverseAllMeshWindings = false;

			llLen = strlen(szMesh) +1;
			char *szTmp = new char[llLen];
			char *lpToken;

			strcpy(szTmp,szMesh);
			if(szMesh[llLen-1] != ';')
				strcat(szTmp,";");


			lpToken = strtok(szMesh,";");
			while( lpToken!= NULL )	{

				char *lpStr = new char[strlen(lpToken)+1];
				strcpy(lpStr, lpToken);
				m_ReverseMeshNames.push_back(lpStr);

				lpToken  = strtok( NULL, ";");
			}

		}
	} else {
		if(m_szInputFile) {
			m_ReverseMeshNames.clear();
			m_bReverseAllMeshWindings = false;
		}
	}
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setTextureDirectories(char *szTextureDirectory)
{
	long llLen;
	if(szTextureDirectory) {
		llLen = strlen(szTextureDirectory) +1;

		m_szTextureDirectory = new char[llLen];
		strcpy(m_szTextureDirectory, szTextureDirectory);

	} else {
		if(m_szTextureDirectory) {
			delete []m_szTextureDirectory;
			m_szTextureDirectory = NULL;
		}
	}
}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setOutputFile(char *szOutputFile)
{
	long llLen;
	if(szOutputFile) {
		llLen = strlen(szOutputFile) +1;

		m_szOutputFile = new char[llLen];
		strcpy(m_szOutputFile, szOutputFile);

	} else {
		if(m_szOutputFile) {
			delete []m_szOutputFile;
			m_szOutputFile = NULL;
		}
	}
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setDumpData(char *szDumpData)
{
	long llLen;
	if(szDumpData) {
		llLen = strlen(szDumpData) +1;

		m_szDumpData = new char[llLen];
		strcpy(m_szDumpData, szDumpData);

	} else {
		if(m_szDumpData) {
			delete []m_szOutputFile;
			m_szOutputFile = NULL;
		}
	}
}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CConverter::setTextureResize(char *szDimension, char *szFilter)
{
long llLen;

	if(szDimension) {
		llLen = strlen(szDimension) +1;

		m_szDimension = new char[llLen];
		strcpy(m_szDimension, szDimension);

	} else {
		if(m_szDimension) {
			delete []m_szDimension;
			m_szDimension = NULL;
		}
	}

	
	if(szFilter) {
		llLen = strlen(szFilter) +1;

		m_szFilter = new char[llLen];
		strcpy(m_szFilter, szFilter);

	} else {
		if(m_szFilter) {
			delete []m_szFilter;
			m_szFilter= NULL;
		}
	}

		
	

}

