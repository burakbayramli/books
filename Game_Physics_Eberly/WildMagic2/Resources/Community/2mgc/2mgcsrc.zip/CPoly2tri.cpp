#include "CPoly2tri.h"

CPoly2Tri::CPoly2Tri()
{
	m_Triangles.clear();
	m_lpVertex.clear();
}

CPoly2Tri::~CPoly2Tri()
{
	VertexArray::iterator pVertex;

	// search for a trangle. 
	for (pVertex=m_lpVertex.begin(); pVertex!= m_lpVertex.end(); pVertex++)
		delete *pVertex;

	m_Triangles.clear();
	m_lpVertex.clear();

}


/************************************************************************************
	Function	AddVertex

	Parameters
		DWORD dwVertexIndex, 
		bool bHole,
		float x,
		float y,
		float x

	Returns - 

	Description - 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CPoly2Tri::AddVertex(DWORD dwVertexIndex, 
								  bool bHole,
								  float x,
								  float y,
								  float z)
{
	
	LPVertex lpVert = new Vertex;

	lpVert->bHole = bHole;
	lpVert->dwVertexIndex = dwVertexIndex;
	lpVert->x = x;
	lpVert->y = y;
	lpVert->z = z;
	
	// I think the STL implentation has a bug on the second time around.
	// dangling pointer.
	m_lpVertex.push_back(lpVert);

	return true;
}

/************************************************************************************
	Function	AddVertex

	Parameters
		DWORD dwVertexIndex, 
		bool bHole,
		float x,
		float y,
		float x

	Returns - 

	Description - 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CPoly2Tri::ClearVerticies(void)
{
	VertexArray::iterator pVertex;

	// search for a trangle. 
	for (pVertex=m_lpVertex.begin(); pVertex!= m_lpVertex.end(); pVertex++)
		delete *pVertex;

	m_lpVertex.clear();
	m_Triangles.clear();
}

/************************************************************************************
	Function	AddVertex

	Parameters
		DWORD dwVertexIndex, 
		bool bHole,
		float x,
		float y,
		float x

	Returns - 

	Description - 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
DWORD CPoly2Tri::getTriangleIndex(DWORD ldIndex)
{
	if(ldIndex>=0 && ldIndex<m_Triangles.size()) {
//		printf("==%d\n", m_Triangles[ldIndex]->dwVertexIndex); 
		return m_Triangles[ldIndex]->dwVertexIndex;
	} else { 
		return 0;
	}
}

/************************************************************************************
	Function	AddVertex

	Parameters
		int iTriangle
		LPTriangle lpTri

	Returns - bool - true - triangle was found
				false - triangle not found (index out of range.)

	Description - Retrieves the requested triangle.

  When		Who		What
  =======	=====	=================

*************************************************************************************/
LPVertex CPoly2Tri::getTriangle(int iTriangle)
{
	if(iTriangle>=0 && iTriangle < m_Triangles.size()) {
		return m_Triangles[iTriangle];
	} else { 
		return NULL;
	}
}

/************************************************************************************
	Function	ComputeNumberTriangles

	Parameters
		DWORD dwVerticies

	Returns - The number of triangles that will be output.

	Description - 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
DWORD CPoly2Tri::ComputeTriangulatedVerticies(DWORD dwVerticies)
{
	if(dwVerticies<=2)
		return 0;

	if(dwVerticies==3)
		return 3;

	return (dwVerticies -2)* 3;

}

/************************************************************************************
	Function	BuildTriangles

	Parameters

	Returns - the number of triangles built. Before calling this function you should
		use the AddVertex function to add all the verticies of the polygon. They 
		should be added in the same order as they appear in the stream. 

	Description - Call this procedure with a polygon, this divides it into triangles
		while building a list.

		Note that this does not work for polygons with holes or self
		penetrations.

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CPoly2Tri::BuildTriangles()
{
Vertex		center;
int			i, j, a, b, c;
VertexArray	lpTriangle(3);
VertexArray	lpVertex;
	
	ClearTriangleList();

    if (m_lpVertex.size() < 3)
		return 0; /* No triangle found */


	// copy the arrays to local
	for(i=0;i<m_lpVertex.size();i++) {
        lpVertex.push_back(m_lpVertex[i]);
//		printf("%d ", m_lpVertex[i]->dwVertexIndex);
	}
//	printf("\n");

	do {
		/* This simplest case and is the exit */
		if (lpVertex.size() == 3) {

			lpTriangle[0]=lpVertex[0];
			lpTriangle[1]=lpVertex[1];
			lpTriangle[2]=lpVertex[2];

			OutputTriangle(lpTriangle);
			break;
		}

		VertexArray::iterator pVertex;

		// search for a trangle. 
		for (i = 0,pVertex=lpVertex.begin(); i < lpVertex.size(); i++,pVertex++) {
			a = i;
			b = (i + 1) % lpVertex.size();
			c = (i + 2) % lpVertex.size();

			/* Select a candidate triangle */
			lpTriangle[0]=lpVertex[a];
			lpTriangle[1]=lpVertex[b];
			lpTriangle[2]=lpVertex[c];

			/* Calculate the center of the triangle */
			vect_init (&center, 0.0, 0.0, 0.0);
			vect_add (&center, &center, lpTriangle[0]);
			vect_add (&center, &center, lpTriangle[1]);
			vect_add (&center, &center, lpTriangle[2]);
			vect_scale (&center, 1.0f/3.0f);

			/* Is the center of the triangle inside the original polygon? */
			/* If not skip this triangle */
			if (!poly_inside (lpVertex, lpVertex.size(), &center))
				continue;

			/* Are any of the polygons other vertices inside the triangle */
			/* If so skip this triangle */
			for (j = 0; j < lpVertex.size(); j++) {
				if (j != a && j != b && j != c && poly_inside (lpTriangle, 3, lpVertex[j]))
					break;
			}

			if (j < lpVertex.size())
				continue;

			/* This is the one */
			OutputTriangle(lpTriangle);

			/* Remove this triangle from the polygon */
			pVertex++;
			lpVertex.erase(pVertex);
			break;

		}
	} while(1);

	return m_Triangles.size();
}


/************************************************************************************
	Function	

	Parameters

	Returns

	Description 
		Determines if the specified point 'v' is inside the polygon.
		Uses a convoluted version of the sum of angles approach

  When		Who		What
  =======	=====	=================

*************************************************************************************/
int CPoly2Tri::poly_inside (VertexArray poly, int polysize, Vertex *v)
{
    Vertex sum, cross, v1, v2;
    float  magcross;
    int    i;

    vect_init (&sum, 0.0, 0.0, 0.0);

    for (i = 0; i < polysize; i++) {
	vect_sub (&v1, v, poly[i]);
	vect_sub (&v2, v, poly[(i+1) % polysize]);

	cross_prod (&cross, &v1, &v2);
	magcross = vect_mag (&cross);

	if (magcross > 0.0)
	    vect_scale (&cross, static_cast<float>(1.0/magcross));

	vect_scale (&cross, vect_angle (&v1, &v2));
	vect_add (&sum, &sum, &cross);
    }
	
    return (vect_mag (&sum) > M_PI);
}

/************************************************************************************
	Function	

	Parameters

	Returns

	Description 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CPoly2Tri::vect_init (Vertex *v, float  x, float  y, float  z)
{
    v->x = x;
    v->y = y;
    v->z = z;
}

/************************************************************************************
	Function	

	Parameters

	Returns

	Description 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CPoly2Tri::vect_copy (Vertex *v1, Vertex *v2)
{
	memcpy(v1,v2, sizeof(Vertex));
}

/************************************************************************************
	Function	

	Parameters

	Returns

	Description 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CPoly2Tri::vect_add (Vertex *v1, Vertex *v2, Vertex *v3)
{
    v1->x = v2->x + v3->x;
    v1->y = v2->y + v3->y;
    v1->z = v2->z + v3->z;
}


/************************************************************************************
	Function	

	Parameters

	Returns

	Description 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CPoly2Tri::vect_sub (Vertex *v1, Vertex *v2, Vertex *v3)
{
    v1->x = v2->x - v3->x;
    v1->y = v2->y - v3->y;
    v1->z = v2->z - v3->z;
}

/************************************************************************************
	Function	

	Parameters

	Returns

	Description 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CPoly2Tri::vect_scale (Vertex *v, float  k)
{
    v->x = k * v->x;
    v->y = k * v->y;
    v->z = k * v->z;
}


/************************************************************************************
	Function	

	Parameters

	Returns

	Description 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
float CPoly2Tri::vect_mag (Vertex *v)
{
    float mag;
    if (v->x==0.0 && v->y==0.0 && v->z==0.0) return 0.0;
    mag = static_cast<float>(sqrt(v->x*v->x + v->y*v->y + v->z*v->z));

    return mag;
}


/************************************************************************************
	Function	

	Parameters

	Returns

	Description 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
float CPoly2Tri::dot_prod (Vertex *v1, Vertex *v2)
{
    return (v1->x*v2->x + v1->y*v2->y + v1->z*v2->z);
}

/************************************************************************************
	Function	

	Parameters

	Returns

	Description 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CPoly2Tri::cross_prod (Vertex *v1, Vertex *v2, Vertex *v3)
{
    v1->x = (v2->y * v3->z) - (v2->z * v3->y);
    v1->y = (v2->z * v3->x) - (v2->x * v3->z);
    v1->z = (v2->x * v3->y) - (v2->y * v3->x);
}


/************************************************************************************
	Function	

	Parameters

	Returns

	Description 
		Return the angle (rads) between two Vertexs

  When		Who		What
  =======	=====	=================

*************************************************************************************/
float CPoly2Tri::vect_angle (Vertex *v1, Vertex *v2)
{
    float  mag1, mag2, angle, cos_theta;

    mag1 = vect_mag(v1);
    mag2 = vect_mag(v2);

    if (mag1 * mag2 == 0.0)
	angle = 0.0;
    else {
	cos_theta = dot_prod(v1,v2) / (mag1 * mag2);

	if (cos_theta <= -1.0)
	    angle = M_PI;
	else if (cos_theta >= +1.0)
	    angle = 0.0;
	else
	    angle = static_cast<float>(acos(cos_theta));
    }

    return angle;
}


/************************************************************************************
	Function	ClearTriangleList

	Parameters

	Returns - 

	Description - Initializes the triangle list.

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CPoly2Tri::ClearTriangleList(void) 
{

	// search for a trangle. 
	m_Triangles.clear();

}

/************************************************************************************
	Function	OutputTriangle

	Parameters
		int iVertex1 - the verticies of the triangle. 
		int iVertex2, 
		int iVertex3

	Returns - 

	Description - The routine writes a triangle in the output list. 

  When		Who		What
  =======	=====	=================

*************************************************************************************/
bool CPoly2Tri::OutputTriangle(VertexArray lpTriangle) 
{	
	if(lpTriangle.size()!=3)
		return false;

	m_Triangles.push_back(lpTriangle[0]);	
	m_Triangles.push_back(lpTriangle[2]);	
	m_Triangles.push_back(lpTriangle[1]);	
	
//	printf("%d %d %d\n", lpTriangle[0]->dwVertexIndex, lpTriangle[1]->dwVertexIndex, lpTriangle[2]->dwVertexIndex); 
	return true;
}
