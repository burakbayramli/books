#ifndef MGCCONVERTER_H
#define MGCCONVERTER_H

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <iostream.h>
#include <conio.h>
#include "ErrorCodes.h"

#include "CXScene.h"
#include "C3dsScene.h"
#include "CImageConverter.h"

#include "MgcAnimation.pkg"
#include "MgcDetail.pkg"
#include "MgcEngine.pkg"
#include "MgcSorting.pkg"
#include "MgcTerrain.pkg"

using namespace Mgc;

int main (int iQuantity, char** apcArgument);
void FixFilePaths(char *szInputFile, char *szOutputFile, char *szInFile, char *szOutFile);
bool getParameters(int iQuantity, char** apcArgument);
bool CheckParameters(void);
void Usage(long llType);

long Convert(char *szInputFile, char *szOutputDirectory, 
			char *szTextureDirectory, 
			bool bVerbose, bool bStats);
void FixFilePaths(char *szInputFile, char *szOutputFile, char *szInFile, char *szOutFile);
void ParseFilename(char *lpFullPath, char *lpDrive, 
				   char *lpDirectory, char *lpFilename, 
				   char *lpExtension);
bool FileExists(char *lpFile);
void ParsePath(char *lpInputFile, char *lpPath);
void setTexturePaths(char *szInputFile);

#endif
