#ifndef CMESHUTILITIES_H
#define CMESHUTILITIES_H

#include <windows.h>
#include <lib3ds/file.h>
#include <lib3ds/chunk.h>
#include <lib3ds/mesh.h>
#include <vector>
#include <algorithm>
#include <MgcDetail.pkg>


using namespace Mgc;
using namespace std;

typedef set<TriangleMesh::Triangle,less<TriangleMesh::Triangle>, allocator<TriangleMesh::Triangle> >	ConnectionSet;
typedef vector<TriangleMesh *, allocator<TriangleMesh *> > TriangleMeshArray;

class CMeshUtilities : public Mgc::TriangleMesh
{

public:
	CMeshUtilities();
	~CMeshUtilities();

	bool	CorrectFaceWinding(Lib3dsMesh *lpMesh);
	bool	ReverseFaceWinding(Lib3dsMesh *lpMesh);

protected:
    virtual void OnTriangleInsert (const Triangle& rkT, bool bCreate, void*& rpvData);
	virtual void OnTriangleRemove (const Triangle&, bool bDestroy, void* pvData);

private:
	void	AddConnectionPoints(Lib3dsMesh *lpMesh);
	void	AddConnectionPoints(Lib3dsMesh *lpMesh, bool bFilterTris);


private:
	DWORD		m_dwCurrentFace;
	Lib3dsMesh *m_lpMesh;
};


#endif




