#include "CIndirectIndex.h"
#include "assert.h"

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CIndirectIndex::CIndirectIndex()
{
	m_IndexArray=NULL;
	m_IndexArraySize=10000;
	Clear();
}

CIndirectIndex::CIndirectIndex(DWORD dwMaxSize)
{
	m_IndexArray=NULL;
	m_IndexArraySize = dwMaxSize;
	Clear();
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
CIndirectIndex::~CIndirectIndex()
{
	if(m_IndexArray) {
		delete []m_IndexArray;
		m_IndexArray = NULL;
	}
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CIndirectIndex::Clear(void)
{
	if(m_IndexArray) {
		delete []m_IndexArray;
		m_IndexArray = NULL;
	}
	m_IndexArray = new DWORD[m_IndexArraySize];
	memset(m_IndexArray, 0xFFFFFFFF, sizeof(DWORD) * m_IndexArraySize);
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
DWORD CIndirectIndex::getVertexStorageIndex(DWORD dwVertexIndex)
{
	assert(dwVertexIndex <m_IndexArraySize);
	return m_IndexArray[dwVertexIndex];
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void CIndirectIndex::setVertexStorageIndex(DWORD dwStorageIndex, DWORD dwVertexIndex)
{

	assert(dwVertexIndex <m_IndexArraySize);
	m_IndexArray[dwVertexIndex] = dwStorageIndex;
	return;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
bool CIndirectIndex::AlreadyStoredVertex(DWORD dwVertexIndex)
{
	//assert(dwVertexIndex <m_IndexArraySize);
	if(dwVertexIndex >m_IndexArraySize)
		return false; 

	return m_IndexArray[dwVertexIndex] !=0xFFFFFFFF;

}



