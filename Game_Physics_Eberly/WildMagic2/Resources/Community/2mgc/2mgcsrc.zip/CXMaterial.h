
#ifndef CXMATERIAL_H
#define CXMATERIAL_H

#include <windows.h>
#include <iostream.h>
#include <objbase.h>
#include "D3d8types.h"
#include <MgcApplication.pkg>

using namespace Mgc;

class CXMaterial 
{
public:
    CXMaterial();
	~CXMaterial();

	//*****************************
	void setID(DWORD *pVal ) {
		dwID = *pVal;
	}
	
	void setName(char *lpName) {
		if(m_szName)
			delete []m_szName;
		m_szName = new char[strlen(lpName)+1];
		strcpy(m_szName,lpName);
	}

	//*****************************
	void setD3DRGB(D3DCOLORVALUE	*pVal) {
		memcpy(&pD3dRGBA, pVal, sizeof(D3DCOLORVALUE));
	}

	//*****************************
	void setPower(float	*pVal) {
		fPower=*pVal;
	}

	//*****************************
	void setAlpha(float	*pVal) {
		fAlpha=*pVal;
	}

	//*****************************
	void setSpecularColor(D3DVECTOR	*pVal) {
		memcpy(&pSpecularColor, pVal, sizeof(D3DVECTOR));
	}

	//*****************************
	void setEmissiveColor(D3DVECTOR	*pVal) {
		memcpy(&pEmissiveColor, pVal, sizeof(D3DVECTOR));
	}

	//*****************************
	void setTextureFilename(char *pVal) {
		szTextureFilename = new char[strlen(pVal)+1];
		strcpy(szTextureFilename, pVal);
	}

	//*****************************
	void setTextureDirectories(char *pVal) {
		szTextureDirectories = new char[strlen(pVal)+1];
		strcpy(szTextureDirectories, pVal);
	}

	DWORD	getID() { return dwID; }
	ColorRGB getColorRGB() { 
		return ColorRGB(pD3dRGBA.r, pD3dRGBA.g, pD3dRGBA.b);
	}

	float getPower(void) { return fPower;}	
	float getAlpha(void) { return fAlpha; }

	ColorRGB getSpecularColor(void) {
		return ColorRGB(pSpecularColor.x, pSpecularColor.y, pSpecularColor.z);
	}
		
	ColorRGB getEmissiveColor(void) {
		return ColorRGB(pEmissiveColor.x, pEmissiveColor.y, pEmissiveColor.z);
	}

	char *getName(void) {
		return m_szName;
	}

	Texture*			getMgcTexture();

private:
	HRESULT Convert2Mif(char *szFileName);
	bool FindFile(char *szDirs, char *lpFile, char *szOutput );
	bool FileExists(char *lpFile);

protected:
	Texture*			m_pkTexture;
    Image*				m_pkImage;
	DWORD				dwID;
	
	ColorRGB			pMGCColor;

	D3DCOLORVALUE		pD3dRGBA;
	float				fPower;
	float				fAlpha;

	D3DVECTOR			pSpecularColor;
	D3DVECTOR			pEmissiveColor;
	char				*szTextureFilename;
	char				*szTextureDirectories;
	char				*m_szName;

    char				*szTexture1_map;
    char				*szTexture1_mask;
    char				*szTexture2_map;
    char				*szTexture2_mask;
    char				*szOpacity_map;
    char				*szOpacity_mask;
    char				*szBump_map;
    char				*szBump_mask;
    char				*szSpecular_map;
    char				*szSpecular_mask;
    char				*szShininess_map;
    char				*szShininess_mask;
    char				*szSelf_illum_map;
    char				*szSelf_illum_mask;
    char				*szReflection_map;
    char				*szReflection_mask;

};
#endif

