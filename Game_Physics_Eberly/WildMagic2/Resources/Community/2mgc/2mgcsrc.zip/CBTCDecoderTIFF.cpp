//#include <stdafx.h>
#include <windows.h>

#include "BTDefines.h"
#include "CBTCDecoderTIFF.h"
#include "CBTCIFStream.h" // needed because the TIFF routines do not easily support memory 

CBTCDecoderTIFF::CBTCDecoderTIFF()
{
	m_tif=NULL;
}

CBTCDecoderTIFF::~CBTCDecoderTIFF()
{
	if(m_tif) 
		TIFFClose(m_tif);
}

/////////////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////////////

const char *CBTCDecoderTIFF::GetFormat()      { return "TIFF"; }
const char *CBTCDecoderTIFF::GetDescription() { return "TIFF Reader Decompression"; }
const char *CBTCDecoderTIFF::GetExtension()   { return "tif"; }

/////////////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////////////

long CBTCDecoderTIFF::IsValidType(BTCIStream* pIStream)
{
	long lResult = BTFILETYPE_UNKNOWN;

	if(!pIStream)
		return lResult;

	if( pIStream->Seek( 0L, BTCIOStream::Begin) == -1)
		return lResult;
	
	//pIStream->
	long lSize = pIStream->GetSize();

	if( -1 == lSize)
		return lResult;

	// read the stream in.
	m_tif = TIFFOpen(((BTCIFStream *)pIStream)->m_szFileName, "r");
	if (m_tif) {
		lResult = BTFILETYPE_TIFF_ORG;
	}

	return lResult;
}


/////////////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////////////
bool CBTCDecoderTIFF::Load(	BTCIStream*              pIStream,
							BTCImageData*            pImageData,
							BTIProgressNotification* pProgressNotification /* = NULL */,
							BTCDecoderOptions*       pOptions /* = NULL */)
{
uint32	w=0;
uint32	h=0;
uint32	*raster=NULL;
uint32	xx=0;
uint32	yy=0;
uint32	lCount=0;
uint32	imageSize = 0;

	// check parameters
	if(!pIStream || !pImageData)
		return false;

	if(!m_tif)
		return false;

	long lSize = pIStream->GetSize();

	if( -1 == lSize)
		return false;
	
	// read the header
	TIFFGetField(m_tif, TIFFTAG_IMAGEWIDTH, &w);
	TIFFGetField(m_tif, TIFFTAG_IMAGELENGTH, &h);
	
	if(w==0 || h==0)
		return false;

	if(!pImageData->Create( w, h, 24))
		return false;

	// calcualte the total number of bytes rquired for storage.
	// the reader will convert colorspaces to 32bit.
    imageSize = w * h;

	raster = (uint32*) _TIFFmalloc(imageSize * sizeof(uint32));
    if( raster== NULL ) {
		return false;
    }

	// read the image into the reaster pointer.
	if (!TIFFReadRGBAImage(m_tif, w, h, raster, 0)) {
		return false;
	}
	
	// move the data to image.
	for(lCount=0;lCount<imageSize;lCount++) {			
			pImageData->SetColorForPixel( xx++, h-yy-1, raster[lCount]);

		if(xx>=w) {
			yy++;
			xx=0;

			// Step progress.
			if( pProgressNotification) 
				pProgressNotification->OnProgress( (int)((100.0 / h) * yy) + 1);

		}
	}

	// clean up
	_TIFFfree(raster);

	return true;
}
