#pragma warning( disable : 4786 4788 )
#include "2mgc.h"


bool bVerbose;
bool bStats;
bool bOverWrite;
char *szTextureDirectory;
char *szInputFile;
char *szOutputFile;
char *szResize;
char *szFilter;
bool bWildCard;
bool bForceNormals;
bool bAddLight;
bool bSaveNames;
bool bCorrectWinding;
char *szReverseWinding;
char *szDumpData;
bool bUsage1;
bool bUsage2;

	
/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
int main (int iQuantity, char** apcArgument)
{
bool		bDone = false;
bool		bRet = false;
char		szInFile[MAX_PATH];
char		szOutFile[MAX_PATH];

	// check command line
	if(iQuantity<=1) {
		Usage(0);
		return 0;
	}
	
	bRet = getParameters(iQuantity, apcArgument);

	if(bRet && bUsage1) {
		Usage(1);

	} else if(bRet && bUsage2) {
		Usage(2);

	} else if(bRet) {
		// set up the texture path to include the current drive and path for the models.
		setTexturePaths(szInputFile);

		if(bWildCard) {
			HANDLE hDir;
			WIN32_FIND_DATA DirFile;

			hDir = FindFirstFile(szInputFile, &DirFile);
			
			if(hDir==0x00) {
				cout << "No files were found using the mask " <<  szInputFile << "\n";

			} else {
				
				char szPath[MAX_PATH];
				char szFilename[MAX_PATH];

				ParsePath(szInputFile, szPath);

				// iterate all matching files 
				do {
					if(!(DirFile.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
						sprintf(szFilename, "%s%s", szPath, DirFile.cFileName);
						FixFilePaths(szFilename, szOutputFile, szInFile, szOutFile);
						Convert(szFilename, szOutFile, szTextureDirectory, bVerbose, bStats);
					}

				} while(FindNextFile(hDir, &DirFile));

				FindClose(hDir);
			}


		} else {
			if(!FileExists(szInputFile)) {
				cout << szInputFile << " could not be found.\n";

			} else {
				FixFilePaths(szInputFile, szOutputFile, szInFile, szOutFile);
				Convert(szInputFile, szOutFile, szTextureDirectory, bVerbose, bStats);
			}
		}
	}

	if(szTextureDirectory) 
		delete []szTextureDirectory;

	if(szInputFile)
		delete []szInputFile;

	if(szOutputFile)
		delete []szOutputFile;

	if(szResize)
		delete []szResize;

	if(szFilter)
		delete []szFilter;

	if(szReverseWinding)
		delete []szReverseWinding;

	if(szDumpData)
		delete []szDumpData;

	cout << "Done.\n\n";
	return 0;
}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
void FixFilePaths(char *szInputFile, char *szOutputFile, char *szInFile, char *szOutFile)
{
char szInputDrive[MAX_PATH];
char szInputDirectory[MAX_PATH];
char szInputFilename[MAX_PATH];
char szInputFileExt[MAX_PATH];

char szOutputDrive[MAX_PATH];
char szOutputDirectory[MAX_PATH];
char szOutputFilename[MAX_PATH];
char szOutputFileExt[MAX_PATH];
CImageConverter *lpConverter = new CImageConverter();


	// parse filename routines require that the strings be nulled first.
	memset(szInputDrive,0x00,MAX_PATH);
	memset( szInputDirectory,0x00,MAX_PATH);
	memset( szInputFilename,0x00,MAX_PATH);
	memset( szInputFileExt,0x00,MAX_PATH);

	memset( szOutputDrive,0x00,MAX_PATH);
	memset( szOutputDirectory,0x00,MAX_PATH);
	memset( szOutputFilename,0x00,MAX_PATH);
	memset( szOutputFileExt,0x00,MAX_PATH);


	ParseFilename(szInputFile, szInputDrive, szInputDirectory, szInputFilename, szInputFileExt);

	// if the user specified a output file,
	if(szOutputFile) {
		ParseFilename(szOutputFile, szOutputDrive, szOutputDirectory, szOutputFilename, szOutputFileExt);

		// is a directory ? meaning it does not have a filename
		if(*szOutputFilename==0x00) {

			strcpy(szOutFile,szOutputFile);
			strcat(szOutFile,szInputFilename);
			if(lpConverter->ValidFormat(szInputFileExt))
				strcat(szOutFile, C_DEFAULT_IMAGE_EXT);
			else 
				strcat(szOutFile, C_DEFAULT_3D_EXT);


		} else {
			strcpy(szOutFile,szOutputFile);

			if(*szOutputFileExt==0x00) {
				if(lpConverter->ValidFormat(szInputFileExt))
					strcat(szOutFile, C_DEFAULT_IMAGE_EXT);
				else 
					strcat(szOutFile, C_DEFAULT_3D_EXT);
			} else {
				strcat(szOutFile,szOutputFileExt);
			}
		} 

	} else {
		char szTmp[10];

		if(lpConverter->ValidFormat(szInputFileExt))
			strcpy(szTmp, C_DEFAULT_IMAGE_EXT);
		else 
			strcpy(szTmp, C_DEFAULT_3D_EXT);

		sprintf(szOutFile, "%s%s%s%s", szInputDrive, szInputDirectory, szInputFilename, szTmp);

	}
	delete lpConverter;	
}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
void ParsePath(char *lpInputFile, char *lpPath)
{
char szInputDrive[MAX_PATH];
char szInputDirectory[MAX_PATH];
char szInputFilename[MAX_PATH];
char szInputFileExt[MAX_PATH];

	// parse filename routines require that the strings be nulled first.
	memset(szInputDrive,0x00,MAX_PATH);
	memset( szInputDirectory,0x00,MAX_PATH);
	memset( szInputFilename,0x00,MAX_PATH);
	memset( szInputFileExt,0x00,MAX_PATH);

	ParseFilename(lpInputFile, szInputDrive, szInputDirectory, szInputFilename, szInputFileExt);
	sprintf(lpPath, "%s%s", szInputDrive, szInputDirectory);

}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
void setTexturePaths(char *szInputFile)
{
char szTmpTextures[MAX_PATH];

char szInputDrive[MAX_PATH];
char szInputDirectory[MAX_PATH];
char szInputFilename[MAX_PATH];
char szInputFileExt[MAX_PATH];

	memset(szInputDrive,0x00,MAX_PATH);
	memset( szInputDirectory,0x00,MAX_PATH);
	memset( szInputFilename,0x00,MAX_PATH);
	memset( szInputFileExt,0x00,MAX_PATH);

	ParseFilename(szInputFile, szInputDrive, szInputDirectory, szInputFilename, szInputFileExt);

	// set the default texture directories
	memset(szTmpTextures, 0x00, MAX_PATH);
	strcat(szTmpTextures, szInputDrive);
	strcat(szTmpTextures, szInputDirectory);
	strcat(szTmpTextures, ";");

	if(szTextureDirectory) {
		strcat(szTmpTextures, szTextureDirectory);
		strcat(szTmpTextures, ";");
		delete []szTextureDirectory;
	}
	
	szTextureDirectory = new char[strlen(szTmpTextures)+1];
	strcpy(szTextureDirectory,szTmpTextures);
}	


/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
bool FileExists(char *lpFile)
{
	FILE	*f1;
	bool	bRet;

	f1 = fopen(lpFile,"r");
	if(f1) {
		bRet = true;
		fclose(f1);
	} else {
		bRet = false;
	}

	return bRet;
}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
void ParseFilename(char *lpFullPath, char *lpDrive, 
				   char *lpDirectory, char *lpFilename, 
				   char *lpExtension)
{
char szTmp[MAX_PATH];
char *lpPos;

	// if the drive letter was there, get it out 
	lpPos = strrchr(lpFullPath, ':');
	if(lpPos) {
		strncpy(lpDrive, lpFullPath, lpPos - lpFullPath + 1);
		lpPos++;
		strcpy(szTmp,lpPos);
	} else {
		lpDrive=0x00;
		strcpy(szTmp,lpFullPath);
	}

	// get the directory and filename 
	lpPos = strrchr(szTmp, '\\');
	if(lpPos) {
		strncpy(lpDirectory, szTmp, lpPos - szTmp + 1);
		lpPos++;
		strcpy(lpFilename, lpPos);
	} else {
		lpDirectory = 0x00;
		strcpy(lpFilename,szTmp);
	}

	// get the extension 
	lpPos = strrchr(lpFilename, '.');
	if(lpPos) {
		strcpy(lpExtension,lpPos);

		// remove the extension from the filename 
		*lpPos = 0x00;
	} else {
		*lpExtension=0x00;
	}
}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
bool getParameters(int iQuantity, char** apcArgument)
{
	int			i;
	long		llLen;	
	bool		bRet = true;

	// set defautls for parameters
	bVerbose = false;
	bStats = false;
	bOverWrite = false;
	szTextureDirectory = NULL;
	szInputFile = NULL;
	szOutputFile = NULL;
	bWildCard = false;
	bAddLight = false;
	bForceNormals = false;
	bCorrectWinding = false;
	bUsage1 = false;
	bUsage2 = false;

	for(i=1;i<iQuantity;i++) {

		if(stricmp(apcArgument[i], "/V") ==0) {
			bVerbose = true;

		} else if(stricmp(apcArgument[i], "/1") ==0) {
			bUsage1 = true;

		} else if(stricmp(apcArgument[i], "/2") ==0) {
			bUsage2 = true;

		} else if(stricmp(apcArgument[i], "/S") ==0) {
			bStats = true;

		} else if(stricmp(apcArgument[i], "/WC") ==0) {
			bCorrectWinding = true;

		} else if(stricmp(apcArgument[i], "/W") ==0) {
			bOverWrite = true;

		} else if(stricmp(apcArgument[i], "/L") ==0) {
			bAddLight = true;

		} else if(stricmp(apcArgument[i], "/N") ==0) {
			bForceNormals = true;

		} else if(strnicmp(apcArgument[i], "/WR",3) ==0) {			
			llLen = strlen(apcArgument[i] + 3) + 1;
			if(llLen<=1) {
				llLen =4;
				szReverseWinding = new char[llLen];
				strcpy(szReverseWinding, "ALL");

			} else {			
				szReverseWinding = new char[llLen];
				strcpy(szReverseWinding, apcArgument[i] +3);
			}
			

		} else if(strnicmp(apcArgument[i], "/D",2) ==0) {			
			llLen = strlen(apcArgument[i] + 2) + 1;
			szDumpData = new char[llLen];
			strcpy(szDumpData, apcArgument[i] +2);

		} else if(stricmp(apcArgument[i], "/H") ==0) {
			bSaveNames = true;

		} else if(strnicmp(apcArgument[i], "/RI",3) ==0) {
			llLen = strlen(apcArgument[i] + 3) + 1;
			szResize = new char[llLen];
			strcpy(szResize, apcArgument[i]+3);

		} else if(strnicmp(apcArgument[i], "/F",2) ==0) {
			llLen = strlen(apcArgument[i] + 2) + 1;
			szFilter= new char[llLen];
			strcpy(szFilter, apcArgument[i]+2);

		} else if(strnicmp(apcArgument[i], "/T:" , 3) ==0) {
			
			llLen = strlen(apcArgument[i]) + 1;
			szTextureDirectory = new char[llLen];
			strcpy(szTextureDirectory, apcArgument[i]);

		} else if (szInputFile==NULL) {			
			llLen = strlen(apcArgument[i]) + 1;
			szInputFile = new char[llLen];
			strcpy(szInputFile, apcArgument[i]);

		} else if(strnicmp(apcArgument[i], "/O:" , 3) ==0 || szOutputFile==NULL) {
			
			llLen = strlen(apcArgument[i]) + 1;
			szOutputFile = new char[llLen];
			strcpy(szOutputFile, apcArgument[i]);
		}
	}

	if(szInputFile) {
		if(strstr(szInputFile,"*") || strstr(szInputFile,"?")) {
			bWildCard = true;
		}
	}

	bRet=CheckParameters();

	return bRet;

}


/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
bool CheckParameters(void)
{
	bool		bRet;

	bRet = true;

	if(!bWildCard) {
		// ensure input file exists
	
	}

	if(szTextureDirectory) {
		// see if the directory exists
	}

	if(bWildCard && szOutputFile) {
		// see if the directory exists and it is a directory
		
	}

	return bRet;
}


/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
void Usage(long llType)
{

	printf(" MGC Conversion Utility\n");
	printf("========================\n\n");

	switch(llType) {
		case 0:
			printf("Usage:\n\n");
			printf("   2mgc InputFile [OutputFile] [/(Option)][...] \n\n");
			printf("Examples:\n");
			printf("   2mgc starhawk.x\n");
			printf("   2mgc starhawk.x /O:newfile.mgc\n");
			printf("   2mgc *.x /O:c:\\models\\\n");
			printf("\n\n");
			printf("Parameters:\n");
			printf("   InputFile - The file you wish to convert. This can also be a wild card \n");
			printf("    to convert several models at once. For a list of available file formats\n");
			printf("    type 2mgc \\2\n\n");

			printf("   OutputFile - Optional. The output file name. If you do not specify \n");
			printf("    parameter, the output will go in the same directory with \n");
			printf("    the extension of .mgc. If you specified a wildcard on InputFile\n");
			printf("    this parameter should be the destination directory.\n\n");

			printf("   /W - OverWrite existing. Optional. The application will overwrite existing\n");
			printf("    files without prompting! Backup files before using this option. \n");
			printf("    Original file(s) will be overwritten!\n\n");

			printf("   /N - Lighting Normals. Forces calculation of lighting normals using \n");
			printf("    MGC routines.\n\n");

			printf("   /L - Add Light. Automatically add light in the top level. This is good \n");
			printf("    for just viewing models in the SceneViewer tool.\n\n");

			printf("   /T - Texture Search Path. The path to search for textures during conversion.\n");
			printf("    You can specify multiple paths separating them with a ';'\n\n");

			printf("   /H - Make Header File. Creates a C++ Header file that defines all Mesh\n");
			printf("    and Transform node names. This is useful for identifying \n");
			printf("    the names of the meshes and their parent transforms within the \n");
			printf("    Magic Engine. \n\n");

			printf("   /RI###x### - Resize Textures. Will resize texture image to the \n");
			printf("    desired size. You must specify the widthxheight. In conjunction with\n");
			printf("    this parameter, you can set the high-quality resize filter used. \n");
			printf("    Note: If you do not specify a power of 2 width/height the parameters\n");
			printf("    will automatically be set to the next highest power of two.\n\n");
			
			printf("   /Ffilter - Allows you t oset which filter is used when resizing the texture \n");
			printf("    image. Type 2mgc \\1 for more information about what filters are \n");
			printf("    available.\n\n");

			printf("   /WR[name;][;...] - Reverse Winding on model. This parameter will reverse\n");
			printf("    the face winding of the named sub model. You can specify 'ALL' if you\n");
			printf("    want the entire model to be reversed. To find out names of the \n");
			printf("    meshes in the model use the '/DN' parameter.\n\n");

			printf("   /WC - Winding Correct. This parameter will use a MGC algrorthm\n");
			printf("    to ensure all faces are pointing the the same direction. Some model\n");
			printf("    formats support two sided faces. This parameter will ensure that \n");
			printf("    the model has single sided polygons and each are pointing in the \n");
			printf("    correct direction.\n\n");

			printf("   /DM[N] - Dump information. Will display information about the model. \n");
			printf("    Specifying 'M' will show the material information. 'N' will show a \n");
			printf("    summary of meshes in the file.\n\n");

		break;

		case 1:
			printf("\nAvailable Filters\n");
			printf("=================\n");
			printf("Examples:\n");
			printf("   2mgc test.tga /ri256x256 /FBilinear\n");
			printf("   2mgc test.tga /ri256x256 /FBi\n");
			printf("   2mgc test.tga /ri256x256 /FHam\n");
			printf("\n\n");
			printf("	Default\n");
			printf("	Box\n");
			printf("	Bilinear\n");
			printf("	Gaussian\n");
			printf("	Hamming\n");
			printf("	Blackman\n");
			printf("	Triangle\n");
			printf("	Bell\n");
			printf("	BSpline\n");
			printf("	Sinc\n");
			printf("	Lanczos3\n");
			printf("	Mitchell\n");
			printf("	Quadratic\n");
			printf("	Hermite\n");
			printf("	Hanning\n");
			printf("	Catrom\n");
			printf("	Cubic\n");
			printf("	Hann4\n");
			printf("	\n*Note: For the /F parameter, you do not have to spell the entire filter\n");
			printf("	name out.\n\n");
		break;

		case 2:
			printf("\nSupported Import File formats\n");
			printf("=============================\n");
			printf("	3d Model formats: \n");
			printf("			X, 3DS\n\n");
			printf("	Texture and Image formats:\n");
			printf("			BMP, PCX, PNG, PBM, PPM, PGM, TGA, TIFF, \n");
			printf("			JPEG, GIF, IFF, ILBM, RAS, EPS, MNG, JNG, \n");
			printf("			WMF, EMF, AMP, JP2, JPC, and YUV. \n\n");
			printf("	*Note: All images not 24bpp are automatically converted \n");
			printf("	to 24bpp MIF format\n\n");

		break;

	}

/* 
	The follow are common 3d file formats. 
-i 3ds      = Import 3D Studio scene or material files (.3ds, .prj, .mat)
-i 3dmf     = Import Apple QuickDraw 3D files (.3dm, .3dmf)
-i alias    = Import Alias triangle file (.tri)
-i cad3d    = Import CAD-3D binary scene file (.3d2)
-i dem      = Import USGS DEM (Digital Elevation Model) file (.dem)
-i dxf      = Import DXF ASCII or binary file (.dxf)
-i flt      = Import OpenFlight file (.flt)
-i iges     = Import IGES 5.3 ASCII object file (.igs, .iges)
-i ima      = Import Imagine binary scene file (.iob, .obj)
-i lw       = Import Lightwave object files (.lw, .lw*, .lwb)
                  or Lightwave scene files (.lws*, .scn, .scene, scene*)
-i nff      = Import Haines NFF file (.nff)
-i ng_bdf   = Import NuGraf binary scene file (.bdf)
-i ng_scr   = Import NuGraf ASCII script file (.scr)
-i slp      = Import Pro/Engineer Render file (.slp)
-i soft     = Import SoftImage .hrc/.dsc files (.hrc, .dsc)
-i sspro    = Import Strata StudioPro file (.vis)
-i stl      = Import StereoLithography file (.stl)
-i true     = Import Caligari trueSpace file (.cob, .scn)
-i vpro     = Import Vistapro DEM (Digital Elevation Model) file (.dem)
-i wave     = Import Wavefront ASCII object file (.obj)
*/

}

/************************************************************************************
	Function: Convert

	Parameters:
		char *szInputFile
		char *szOutputFile
		char *szTextureDirectory
		bool bVerbose
		bool bStats

	Returns: 
		bool - true the conversion was successful
				false the conversion was NOT successful

	Description: The routine decides what converter to invoke based on the file 
		extension. Invokes the scene builder. Lastly calls the MGC stream routines
		to output the desired file. 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
long Convert(char *lpInputFile, char *lpOutputFile, 
			char *lpTextureDirectory, 
			bool bVerbose, bool bStats)

{
long		lRet = C_SUCCESS;
CConverter	*lpConverter = NULL;
bool		bWrite;
char		szInputDrive[MAX_PATH];
char		szInputDirectory[MAX_PATH];
char		szInputFilename[MAX_PATH];
char		szInputFileExt[MAX_PATH];

	lRet = C_ERR_UNKNOWN_FORMAT;
	lpConverter = NULL;

	memset(szInputDrive,0x00,MAX_PATH);
	memset( szInputDirectory,0x00,MAX_PATH);
	memset( szInputFilename,0x00,MAX_PATH);
	memset( szInputFileExt,0x00,MAX_PATH);
	
	// if the output file already exists, check to see if the 
	// user wants to overwrite the file.
	if(szDumpData==NULL && 
		!bOverWrite && 
		FileExists(lpOutputFile)) {
		bWrite = false;
		cout << "OVERWRITE " << lpOutputFile << " (Y/N) ?" << flush;
		int ch = _getche();
		ch = toupper(ch);
		if(ch=='Y')
			bWrite = true;
		cout << "\n" << flush;
		
	} else {
		bWrite = true;
	}
	
	// if the conversion should take place...
	if(bWrite) {

		// based on the file extension 
		ParseFilename(lpInputFile, szInputDrive, szInputDirectory, szInputFilename, szInputFileExt);

		// X File 
		if (stricmp(szInputFileExt,".X")==0) {
			lpConverter = (CConverter *) new CXScene();

		// 3D Studio Max
		} else if (stricmp(szInputFileExt,".3DS")==0) {
			lpConverter = (CConverter *) new C3DSScene();

		// Truespace
		} else if (stricmp(szInputFileExt,".COB")==0) {
		
		// Autocad
		} else if (stricmp(szInputFileExt,".DXF")==0) {
		
		// Lightwave
		} else if (stricmp(szInputFileExt,".LWO")==0) {
		
		} else {
			CImageConverter *lpImageConverter = new CImageConverter();
			
			if(lpImageConverter->ValidFormat(szInputFileExt)) {				
				lpImageConverter->setResize(szResize, szFilter);

				lpConverter = (CConverter *) lpImageConverter;
			} else {
				delete lpImageConverter;
				lpConverter = NULL;
			}

		} 
		
		// configure converter object for output 
		if(lpConverter) {		
			lpConverter->setDisplayVerbose(bVerbose);
			lpConverter->setDisplayStats(bStats);
			lpConverter->setCorrectWinding(bCorrectWinding);
			lpConverter->setInputFile(lpInputFile);		
			lpConverter->setOutputFile(lpOutputFile);		
			lpConverter->setTextureDirectories(lpTextureDirectory);
			lpConverter->setForceNormalCalculations(bForceNormals);
			lpConverter->setAddLight(bAddLight);
			lpConverter->setSaveNames(bSaveNames);
			lpConverter->setReverseMeshes(szReverseWinding);
			lpConverter->setDumpData(szDumpData);
			lpConverter->setTextureResize(szResize, szFilter);

			lRet = lpConverter->Convert();
			delete lpConverter;

		}

	}


	return lRet;

}

