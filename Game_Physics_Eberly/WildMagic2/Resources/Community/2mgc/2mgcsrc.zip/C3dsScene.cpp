#include <lib3ds/material.h>
#include <lib3ds/mesh.h>
#include <lib3ds/io.h>
#include <lib3ds/chunk.h>
#include <lib3ds/vector.h>
#include <lib3ds/matrix.h>

#include <MgcAnimation.pkg>

#include "C3dsScene.h"

/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
C3DSScene::C3DSScene()
{
	m_spkScene = NULL;
	m_Trans= NULL;

	m_aiConnect= NULL;
	m_akVertex= NULL;
	m_akNormal= NULL;
	m_akColor= NULL;
	m_akTexture= NULL;

	m_dwVertexCount = 0;
	m_dwConnectionCount= 0;

	m_dwVertexAllocatedSize= 0;
	m_dwConnectionAllocatedSize= 0;
	m_dwTotalTriangles= 0;
	m_ObjNames.clear();
	m_3DSReader=NULL;

}



/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
C3DSScene::~C3DSScene()
{


}

/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long C3DSScene::Convert(void)
{
long lRet;

	// just display the parse infromation.
	// typically a user will use this to find out names of the meshes in the model.
	if(m_szDumpData) {
			m_3DSReader=lib3ds_file_load(m_szInputFile);

			if (!m_3DSReader) {
				cout << "Could not load this file. (" << m_szInputFile << ")\n\n" << flush;
				return C_ERR_UNABLE_LOAD_3DS;
			}	
			
			for(const char *p = m_szDumpData;*p;p++)
				Dump3DSData(*p);

		lib3ds_file_free(m_3DSReader);
		return C_SUCCESS;
	}

	// create the initial node 
	m_spkScene = new Node;
	assert(m_spkScene!=NULL);

	// set the rotation matrix so that it converts LHC to RHC
	Matrix3 kRot, kIncr;

	kRot = Matrix3 (1.0f, 0.0f, 0.0f,
					0.0f, 1.0f, 0.0f,
					0.0f, 0.0f, -1.0f);

	kIncr.FromAxisAngle(Vector3::UNIT_Y, 3.141592654f);

	m_spkScene->Rotate() = kIncr*kRot;

	// build the translation vector. this is the last row of the 4x4 ded matrix.
	// and move to the current MGC node.

	// add light optiong
	if(m_AddLight) {
		// add lights 
		LightStatePtr lpLightState;
		lpLightState = new LightState();

		DirectionalLight	*lpLight;
		lpLight = new DirectionalLight();
		lpLight->Ambient() = ColorRGB(0.3f,0.3f,0.3f);
		lpLight->Diffuse() = ColorRGB(0.8f,0.8f,0.8f);
		lpLight->Specular() = ColorRGB(0.2f,0.2f,0.2f);
		

		lpLightState->Attach(lpLight);
		m_spkScene->SetRenderState(lpLightState);
	}

	
	cout << m_szInputFile << flush;
	
	lRet = LoadScene(m_szInputFile);

	if(lRet==C_SUCCESS) {
		// save out the MGC file using the 
		// expertly crafted stream system!
		cout << "\b\b\b" << "\x01" << flush; // smile it is done.
		Stream m_Stream;
		m_Stream.Insert(m_spkScene);	
		m_Stream.Save(m_szOutputFile);
		cout << "\bmgc - (" << m_dwTotalTriangles << " tris)\n" << flush;

		// save out model part names.
		if(m_bSaveNames)
			SaveNames(m_szInputFile);

	} else {

		cout << "\nConversion error : ";
		switch(lRet) {
			case C_ERR_UNABLE_LOAD_3DS:
				cout << "Could not load this file.\n\n" << flush;
				break;
		}
	}
	
	// clean up
	delete m_spkScene;

	ClearNames();

	return lRet;
}

/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long C3DSScene::Dump3DSData(char cData)
{
Lib3dsMaterial			*lp3DSMaterial=NULL;
Lib3dsMesh				*lpMesh=NULL;
int						iUnder;

	switch(toupper(cData)) {

		// Mesh Names
		case 'N':

			for (lpMesh=m_3DSReader->meshes; lpMesh!=0; lpMesh=lpMesh->next) {
				cout << lpMesh->name << "\n" << flush;
				for(iUnder=0;iUnder<strlen(lpMesh->name);iUnder++)
					cout << "\xCD";
				cout << "\n";

				cout << "\t" << lpMesh->points << " verts.\n" << flush;
				cout << "\t" << lpMesh->faces << " faces.\n" << flush;
				cout << "\t" << lpMesh->texels << " texels.\n" << flush;
				cout << "\n" << flush;

			}

			break;

		// Materials
		case 'M':
			for (lp3DSMaterial=m_3DSReader->materials; lp3DSMaterial!=0; lp3DSMaterial=lp3DSMaterial->next) {

				cout << lp3DSMaterial->name << "\n" << flush;
				for(iUnder=0;iUnder<strlen(lp3DSMaterial->name);iUnder++)
					cout << "\xCD";
				cout << "\n";

				cout << "\t" << "Two Sided      = ";
				if(lp3DSMaterial->two_sided) {
					cout << "Yes\n" << flush;
				} else {
					cout << "No\n" << flush;
				}

				cout << "\t" << "Ambient  Red   = " << lp3DSMaterial->ambient[0] << "\n" << flush;
				cout << "\t" << "		  Green = " << lp3DSMaterial->ambient[1] << "\n" << flush;
				cout << "\t" << "		  Blue  = " << lp3DSMaterial->ambient[2] << "\n" << flush;
				cout << "\t" << "Diffuse  Red   = " << lp3DSMaterial->diffuse[0] << "\n" << flush;
				cout << "\t" << "		  Green = " << lp3DSMaterial->diffuse[1] << "\n" << flush;
				cout << "\t" << "		  Blue  = " << lp3DSMaterial->diffuse[2] << "\n" << flush;
				cout << "\t" << "		  Aplha = " << lp3DSMaterial->diffuse[3] << "\n" << flush;
				cout << "\t" << "Specular Red   = " << lp3DSMaterial->specular[0] << "\n" << flush;
				cout << "\t" << "		  Green = " << lp3DSMaterial->specular[1] << "\n" << flush;
				cout << "\t" << "		  Blue  = " << lp3DSMaterial->specular[2] << "\n" << flush;
				cout << "\t" << "		  Aplha = " << lp3DSMaterial->specular[3] << "\n" << flush;
				cout << "\t" << "Texture Map 1  = " << lp3DSMaterial->texture1_map.name << "\n" << flush;
				cout << "\t" << "Texture Map 2  = " << lp3DSMaterial->texture1_map.name << "\n" << flush;
				cout << "\t" << "Bump    Map 1  = " << lp3DSMaterial->bump_map.name << "\n" << flush;
				cout << "\n" << flush;
			}
			break;

		default:
			Dump3DSData('N');
			Dump3DSData('M');
			return C_ERR_UNKNOWN_FORMAT;

	}
	return C_SUCCESS;

}

/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long C3DSScene::LoadScene(char *szFilename)
{
long lRet = C_SUCCESS;

	m_3DSReader=lib3ds_file_load(szFilename);

	if (!m_3DSReader) {
		return C_ERR_UNABLE_LOAD_3DS;
	}

	// iterate all the meshes in the file and build MGC tree
	Lib3dsMesh *lpMesh;
	for (lpMesh=m_3DSReader->meshes; lpMesh!=0; lpMesh=lpMesh->next) {
			BuildMgcModel(m_spkScene, lpMesh);			
	}

	// clean up
	lib3ds_file_free(m_3DSReader);
	return lRet;
}

/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
Lib3dsMaterial *C3DSScene::FindMaterial(char *szCurrentMaterial)
{
Lib3dsMaterial			*lpMaterialRet=NULL;
Lib3dsMaterial			*lp3DSMaterial=NULL;

	if(szCurrentMaterial==0x00)
		return NULL;

	// iterate the materials and find a match
	for (lp3DSMaterial=m_3DSReader->materials; lp3DSMaterial!=0; lp3DSMaterial=lp3DSMaterial->next) {

		if(strcmp(lp3DSMaterial->name, szCurrentMaterial)==0) {
			lpMaterialRet = lp3DSMaterial;
			break;
		}
	}

	return lpMaterialRet;

}

/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void C3DSScene::BuildMgcModel(Node *pParent, Lib3dsMesh *lpMesh)
{
int						iLoop=0;
int						iLoop2=0;
TriMeshPtr				pkMesh=NULL;
MeshMaterialListArray	vecMaterialsList;
MeshMaterialList		MaterialItem;
char					*szCurrentMaterial;
DWORD					dwCount;
DWORD					dwStorageIndex;
bool					bFirstTime;
long					llEnd;
bool					bTwoSided=false;
bool					bProcessTwoSided = false;
Lib3dsMaterial			*lp3DSMaterial=NULL;
CMeshUtilities			*lpMeshUtilities=NULL;

	if(lpMesh->faces==0)
		return;

	// determine if any materials are double sided. 
	for (lp3DSMaterial=m_3DSReader->materials; lp3DSMaterial!=0; lp3DSMaterial=lp3DSMaterial->next) {
		if(lp3DSMaterial->two_sided) {
			bTwoSided = true;
			break;
		}
	}

	// if the material is two sided and the user has opted to 
	// correct winding on these surfaces. Do so now. This is because 
	// some of the faces might be removed.
	if(bTwoSided && m_bCorrectWinding) {
		lpMeshUtilities = new CMeshUtilities();
		bProcessTwoSided = !lpMeshUtilities->CorrectFaceWinding(lpMesh);
		delete lpMeshUtilities;
		lpMeshUtilities=NULL;
	}
	
	// see if this mesh is supposed to be rewound. 
	bool bReverseWinding = false;
	StringArray::iterator lpStr;
	char *szTmp = NULL;

	for(lpStr=m_ReverseMeshNames.begin();lpStr!=m_ReverseMeshNames.end();lpStr++) {
		// if the user has placed a " to specify meshes that 
		// end in spaces.
		if(strstr(*lpStr,"\"")) {
			szTmp = new char[strlen((*lpStr))-1];
			memset(szTmp,0x00,strlen((*lpStr))-1);
			strncpy(szTmp, (*lpStr) + 1, strlen((*lpStr))-2);
		} else {
			szTmp = new char[strlen((*lpStr))+1];
			strcpy(szTmp, (*lpStr));
		}
		
		// user has specified wild card on mesh name EG Face*
		// would match FACE, FACE_EYES, FACE_MOUTH
		if(szTmp[strlen(szTmp)-1] == '*') {
			if(strnicmp(szTmp,lpMesh->name,strlen(szTmp)-2)==0) {
				bReverseWinding = true;
				break;
			}
		} else {
			if(stricmp(szTmp,lpMesh->name)==0) {
				bReverseWinding = true;
				break;
			}
		}
	}

	if(m_bReverseAllMeshWindings || bReverseWinding) {
		lpMeshUtilities = new CMeshUtilities();
		lpMeshUtilities->ReverseFaceWinding(lpMesh);
		delete lpMeshUtilities;
		lpMeshUtilities=NULL;
	}

	// set the transform for this entire mesh
	LoadTransformMatrix(pParent, lpMesh->matrix);

	// count the number of separate materials in this object 
	// also record the position of each in the structure	
	//szCurrentMaterial = lpMesh->faceL[iLoop].material;
	szCurrentMaterial = "\x27\x12\x23";
	dwCount = 0;
	bFirstTime = true;
	memset(&MaterialItem,0x00,sizeof(MaterialItem));

	for (iLoop=0; iLoop<lpMesh->faces; iLoop++) {
		if(strcmp(lpMesh->faceL[iLoop].material, szCurrentMaterial) != 0) {

			// push the old information on the vector. 
			if(!bFirstTime) {				
				MaterialItem.dwFaceCount = dwCount + 1;
				MaterialItem.lpMaterialName = szCurrentMaterial;
				vecMaterialsList.push_back(MaterialItem);

			} else {
				bFirstTime=false;
				MaterialItem.lpMaterialName = lpMesh->faceL[iLoop].material;
			}

			MaterialItem.dwBegin = iLoop;

			// reset the control break
			dwCount = 0;
			szCurrentMaterial=lpMesh->faceL[iLoop].material;

		} else {
			dwCount++;
		}
		// break apart for materials.
	}

	MaterialItem.lpMaterialName = szCurrentMaterial;
	MaterialItem.dwFaceCount = dwCount +1;
	vecMaterialsList.push_back(MaterialItem);

	MeshMaterialListArray::iterator pItem;

	// iterate the materials
	dwStorageIndex = 0;
	for (pItem=vecMaterialsList.begin(); pItem!= vecMaterialsList.end(); pItem++) {
		
		// calculate the bounds for the data and store where
		// the new index will be in the MGC mesh.
		CIndirectIndex *lpIndirect;
		lpIndirect = new CIndirectIndex(lpMesh->points* 3);
//		lpIndirect->Clear();
		dwStorageIndex=0;

		llEnd = pItem->dwBegin +pItem->dwFaceCount;
		for (iLoop=pItem->dwBegin; iLoop<llEnd; ++iLoop) {

			// discard invalid triangles
			bool bDiscardTri = false;
			for(iLoop2=0;iLoop2<3;iLoop2++) {
				if(lpMesh->faceL[iLoop].points[iLoop2] > lpMesh->points) {
					bDiscardTri = true;
					break;
				}
			}
			
			if(!bDiscardTri) {
				for(iLoop2=0;iLoop2<3;iLoop2++) {
					if(!lpIndirect->AlreadyStoredVertex(lpMesh->faceL[iLoop].points[iLoop2])) {
						lpIndirect->setVertexStorageIndex(dwStorageIndex, lpMesh->faceL[iLoop].points[iLoop2]);
						dwStorageIndex++;
					}
				}
			}
		}

		m_dwVertexCount = dwStorageIndex;

		// preallocate the necessary array information 		
		m_aiConnect= new int[pItem->dwFaceCount * 3];	
		m_akVertex = new Vector3[dwStorageIndex ];

		// if the model has texture cordinates allocate sotrage. 
		if(lpMesh->texels > 0) {		
			m_akTexture = new Vector2[dwStorageIndex ];
		} else {
			m_akTexture = NULL;
		}

		m_akNormal = new Vector3[dwStorageIndex];

		// add the faces to the MGC data. This will move all 
		// information assocatied with the face. 	
		m_dwConnectionCount = 0;
		
		llEnd = pItem->dwBegin +pItem->dwFaceCount;
		for (iLoop=pItem->dwBegin; iLoop<llEnd; ++iLoop) {
			AddFacetoMgcModelData(lpMesh, iLoop, lpIndirect, bProcessTwoSided);
		}

		
		pkMesh= new TriMesh(m_dwVertexCount, m_akVertex, m_akNormal , NULL, 
						m_akTexture, m_dwConnectionCount / 3, m_aiConnect);

		assert(pkMesh!=NULL);

		// update state
		m_dwTotalTriangles+=m_dwConnectionCount/ 3;

		// update information
		if(m_bForceNormalCalculation) 
			pkMesh->UpdateModelNormals();

		pkMesh->SetName(lpMesh->name);
		char *lpNameTmp = new char[strlen(lpMesh->name)+1];
		strcpy(lpNameTmp, lpMesh->name);
		m_ObjNames.push_back(lpNameTmp);

		// set the material for the item.
		LoadMaterial(pkMesh, pItem );

		pParent->AttachChild(pkMesh);

		// clean up
		delete lpIndirect;
		lpIndirect=NULL;

	}


}


/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void C3DSScene::AddFacetoMgcModelData(Lib3dsMesh *lpMesh, long lFace, CIndirectIndex *lpIndirect, bool bTwoSided)
{
int					iLoop;
DWORD				dwStorage;
DWORD				dwIndex;
Lib3dsVector		p3DSVector;
int					TriSpin[3];
	
	// make sure valid triangle.	
	bool bDisgardTri = false;
	for(iLoop=0;iLoop<3;iLoop++) {
		if(lpMesh->faceL[lFace].points[iLoop] >= lpMesh->points) {
			bDisgardTri = true;
		}
	}

	if(!bDisgardTri) {

		// Set the windig of the tri points. 
		TriSpin[0]=0;
		TriSpin[1]=1; 
		TriSpin[2]=2;
		
		// create the face. 
		for(iLoop=0;iLoop<3;iLoop++) {
			assert(lFace <= lpMesh->faces);

			dwIndex = lpMesh->faceL[lFace].points[TriSpin[iLoop]];
			dwStorage = lpIndirect->getVertexStorageIndex(dwIndex);

			m_aiConnect[m_dwConnectionCount++] = dwStorage;
			
			assert(dwIndex < lpMesh->points);

			lib3ds_vector_copy(p3DSVector, lpMesh->pointL[dwIndex].pos);
			m_akVertex[dwStorage] = Vector3(p3DSVector[0], p3DSVector[1], p3DSVector[2]);
			m_akNormal[dwStorage] = Vector3(lpMesh->faceL[lFace].normal[0] , 
											lpMesh->faceL[lFace].normal[1], 
											lpMesh->faceL[lFace].normal[2]);


			if(m_akTexture) {
				if(dwIndex < lpMesh->texels) {
					m_akTexture[dwStorage] = Vector2(lpMesh->texelL[dwIndex][0], lpMesh->texelL[dwIndex][1]);
				} else {
					m_akTexture[dwStorage] = Vector2(0.0f, 0.0f);
				}
			}
		}

	}
}


/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long C3DSScene::LoadTransformMatrix(Node *pParent, Lib3dsMatrix matrix)
{
Matrix3		matTrans;
Vector3		vecTrans;

	// move the contents from the d3d format to the MGC format
	// notice the rows and columns are reversed. 	
	matTrans = Matrix3 (matrix[0][0], matrix[1][0], matrix[2][0],
						matrix[0][1], matrix[1][1], matrix[2][1],
						matrix[0][2], matrix[1][2], matrix[2][2]);

	// set the rotation matrix.
	pParent->Rotate() = matTrans;

	// build the translation vector. this is the last row of the 4x4 ded matrix.
	// and move to the current MGC node.
	vecTrans = Vector3(matrix[3][0] , matrix[3][1], matrix[3][2]);

	pParent->Translate() =vecTrans;
	return C_SUCCESS;
}

/************************************************************************************
	Function: Convert

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
bool C3DSScene::LoadMaterial(TriMesh	*pMesh, LPMeshMaterialList lpMaterialItem)
{
long				lRet = C_SUCCESS;
TextureStatePtr		spkTexture= NULL;
TexturePtr			pkTexture = NULL;
MaterialStatePtr    lpMaterialState;
Image				*lpMIFImage = NULL;
Lib3dsMaterial		*lp3DSMaterial=NULL;
char				*szTextureNames[2];
DWORD				dwLoop;
DWORD				dwEnd;

	// Get the material record.
	lp3DSMaterial = FindMaterial(lpMaterialItem->lpMaterialName);
	
	if(!lp3DSMaterial) 
		return NULL;
	
	// set the names of the textures to load.
	szTextureNames[0] = lp3DSMaterial->texture1_map.name;
	szTextureNames[1] = lp3DSMaterial->texture2_map.name;
	dwEnd = sizeof(szTextureNames) / sizeof(char *);
	
	// Load the textures
	for(dwLoop=0;dwLoop<dwEnd;dwLoop++) {
		
		// convert the image to MIF
		CImageConverter *lpImageConverter;
		lpImageConverter = new CImageConverter();

		// if acceptable format 
		if(lpImageConverter->ValidFormat(szTextureNames[dwLoop])) {
			// check to see if the item already has been converted. 
			pkTexture = GetTexture(szTextureNames[dwLoop]);
			if(!pkTexture) {
				lpImageConverter->setInputFile(szTextureNames[dwLoop]);		
				lpImageConverter->setTextureDirectories(m_szTextureDirectory);
				lpImageConverter->setResize(m_szDimension, m_szFilter);
				lpMIFImage = lpImageConverter->ConvertToMgcImage();
				
				if(lpMIFImage) {
					pkTexture = new Texture;	
					if ( !pkTexture ) 
						return NULL;
					pkTexture->SetImage(lpMIFImage);
					pkTexture->Filter() = Texture::FM_LINEAR;
					pkTexture->Mipmap() = Texture::MM_LINEAR;
					pkTexture->Wrap() = Texture::WM_CLAMP_S_CLAMP_T;
					AddTexture(szTextureNames[dwLoop], pkTexture);
				}
			}

			if(pkTexture) {
				spkTexture= new TextureState();
				spkTexture->Set(dwLoop,pkTexture);
				pMesh->SetRenderState(spkTexture);
			}

		}

		// clean up 
		delete lpImageConverter;
		lpImageConverter=NULL;	
	}

	// Set the material
	lpMaterialState = new MaterialState();
	assert(lpMaterialState !=NULL);

//	lpMaterialState->Emissive() = ColorRGB( lp3DSMaterial->ambient[0], 
//									lp3DSMaterial->ambient[1], 
//									lp3DSMaterial->ambient[2]);

	lpMaterialState->Ambient() = ColorRGB( lp3DSMaterial->ambient[0], 
									lp3DSMaterial->ambient[1], 
									lp3DSMaterial->ambient[2]);

	lpMaterialState->Diffuse() = ColorRGB( lp3DSMaterial->diffuse[0], 
									lp3DSMaterial->diffuse[1], 
									lp3DSMaterial->diffuse[2]);

	lpMaterialState->Specular() = ColorRGB( lp3DSMaterial->specular[0], 
									lp3DSMaterial->specular[1], 
									lp3DSMaterial->specular[2]);

	lpMaterialState->Shininess() =128.0 * lp3DSMaterial->shininess;
	

	lpMaterialState->Alpha() = 1.0f - lp3DSMaterial->transparency;
	pMesh->SetRenderState(lpMaterialState);

	return true;

}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void C3DSScene::AddTexture(char *szName, TexturePtr pkTexture)
{
SharedTexture  Item;

	strcpy(Item.szName, szName);
	Item.pkTexture = pkTexture;
	m_SharedTextures.push_back(Item);
}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
TexturePtr C3DSScene::GetTexture(char *szName)
{
TexturePtr						lpRet= NULL; 
SharedTextureArray::iterator	lpItem;

	lpRet = NULL;
	for(lpItem=m_SharedTextures.begin();lpItem!=m_SharedTextures.end();lpItem++) {
		if(stricmp(lpItem->szName, szName) == 0) {
			lpRet = lpItem->pkTexture;
			break;
		}
	}

	return lpRet;

}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void C3DSScene::ClearNames()
{
	if(!m_ObjNames.empty()) {
		for(int i=0;i<m_ObjNames.size();i++)
			delete []m_ObjNames[i];

		m_ObjNames.clear();
	}
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
void C3DSScene::SaveNames(char *szFilename)
{
FILE	*f1;
char	*lpPos;
char	szTmpFileName[MAX_PATH];
char	szHeaderTemplateName[255];
char	szUpperName[255];
char	*ptr;

	strcpy(szTmpFileName, szFilename);
	
	// chop off the other extension
	lpPos = strstr(szTmpFileName,".");
	if(lpPos)
		szTmpFileName[lpPos - szTmpFileName] = 0x00;

	lpPos=strrchr(szTmpFileName, '\\');
	
	if(lpPos) {
		strcpy(szHeaderTemplateName,lpPos +1);

		for (ptr = szHeaderTemplateName; *ptr; ptr++)
			*ptr = toupper( *ptr );

	} else {
		strcpy(szHeaderTemplateName,"3DS");
	}

	strcat(szTmpFileName, ".h");


	f1= fopen(szTmpFileName, "w+");
	if(f1) {

		fprintf(f1,"#ifndef %s_MODEL_H\n", szHeaderTemplateName);
		fprintf(f1,"#define %s_MODEL_H\n\n\n", szHeaderTemplateName);

		if(m_ObjNames.empty()) {
			fprintf(f1,"// No names were found.\n");
	
		} else {
			for(int i=0;i<m_ObjNames.size();i++) {
				// convert the defined name ot upper
				strcpy(szUpperName, m_ObjNames[i]);
				for (ptr = szUpperName; *ptr; ptr++) {
					*ptr = toupper( *ptr );
					if(*ptr=='-') *ptr='_';
				}

				fprintf(f1,"#define C_%s_%s \"%s\"\n", szHeaderTemplateName, szUpperName, m_ObjNames[i]);

			}
		}

		fprintf(f1,"\n#endif\n\n");

		fclose(f1);
	}
}
