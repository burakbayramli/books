// STL gens names too long for the debugger. 
#pragma warning( disable : 4786 4788 )

#include "CXMeshData.h"

CXMeshData::CXMeshData()
{
	Init();
}

CXMeshData::CXMeshData(bool bVal) 
{
	Init();
	m_bCalcNormals = bVal;
}

CXMeshData::~CXMeshData()
{
	Clean();
}

void CXMeshData::Init(void )
{
	m_Vertex.clear();
	m_Connect.clear();
	m_MaterialList.clear();
	m_Normals.clear();
	m_Texture.clear();
	m_bCalcNormals=false;

}

void CXMeshData::Clean(void )
{
	m_Vertex.clear();
	m_Connect.clear();
	m_MaterialList.clear();
	m_Normals.clear();
	m_Texture.clear();
}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
DWORD	CXMeshData::MaterialListCount()
{
	return m_MaterialList.size();
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long	CXMeshData::TextureCordinateCount()
{
	if(m_Texture.empty())
		return -1;

	return m_Texture.size();
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
DWORD	CXMeshData::MaterialList(DWORD dwFace)
{
	assert(dwFace<=m_MaterialList.size());
	if(m_MaterialList.empty()) {
		return 0;
	}

	return m_MaterialList[dwFace];
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
DWORD	CXMeshData::VertexCount(DWORD dwFace)
{
	assert(dwFace<=m_Connect.size());

	return m_Connect[dwFace].Faces.size();
}

DWORD	CXMeshData::VertexCount(void)
{
	return  m_Vertex.size();
}

DWORD	CXMeshData::FaceCount(void)
{
	return m_Connect.size();
}

long	CXMeshData::NormalsCount(void)
{
	if(m_Normals.empty()) return -1;
	return m_Normals.size();

}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long	CXMeshData::VertexColorCount(void)
{
	if(m_VertexColors.empty()) return -1;
	return m_VertexColors.size();

}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
ColorRGB CXMeshData::VertexColor(DWORD	dwVertexIndex)
{
	if(m_VertexColors[dwVertexIndex].dwVertexIndex == dwVertexIndex)  {
		return m_VertexColors[dwVertexIndex].vColor;
	} else {

		VertexColorArray::iterator pItem;

		// search for a trangle. 
		for (pItem=m_VertexColors.begin(); pItem!= m_VertexColors.end(); pItem++)
			if(pItem->dwVertexIndex == dwVertexIndex)
				return pItem->vColor;
	}

	return(ColorRGB(1.0f,1.0f,1.0f));
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
DWORD	CXMeshData::VertexIndex(DWORD dwFace, DWORD dwVertex)
{
	assert(dwFace<=m_Connect.size());
	assert(dwVertex<=m_Connect[dwFace].Faces.size());

	return m_Connect[dwFace].Faces[dwVertex];
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
Vector3 CXMeshData::Vertex(DWORD dwVertexIndex)
{
	assert(dwVertexIndex<=m_Vertex.size());
	return m_Vertex[dwVertexIndex];
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
Vector2 CXMeshData::TextureCordinates(DWORD dwVertexIndex)
{
	assert(dwVertexIndex<=m_Texture.size());
	assert(!m_Texture.empty());

	return m_Texture[dwVertexIndex];
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
Vector3 CXMeshData::LightingNormal(DWORD dwVertexIndex)
{
	assert(dwVertexIndex<=m_Normals.size());

	return m_Normals[dwVertexIndex];
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
DWORD CXMeshData::NumMaterialSeq(DWORD dwBegin)
{
DWORD	dwCount = 0;
bool	bFirstTime = true;
DWORD	dwCurrentMaterialIndex;
	
	// simple control break on the numeric
	for(dwCount=dwBegin;dwCount<m_MaterialList.size();dwCount++) {
		if(bFirstTime) {
			dwCurrentMaterialIndex = m_MaterialList[dwCount];
			bFirstTime = false;
		} else if(dwCurrentMaterialIndex != m_MaterialList[dwCount]) {
			return dwCount-dwBegin;
		}
	}

	return dwCount-dwBegin;

}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
DWORD CXMeshData::NumMaterialSeqConnections(DWORD dwBegin)
{
CPoly2Tri	*lpPoly= new CPoly2Tri();
DWORD		dwCount = 0;
bool		bFirstTime = true;
DWORD		dwCurrentMaterialIndex;
DWORD		dwTriangles=0;
DWORD		dwIndexes=0;

	// simple control break on the numeric
	for(dwCount=dwBegin;dwCount<m_MaterialList.size();dwCount++) {
		if(bFirstTime) {
			dwCurrentMaterialIndex = m_MaterialList[dwCount];
			bFirstTime = false;

		} else if(dwCurrentMaterialIndex != m_MaterialList[dwCount]) {
			delete lpPoly;
			return dwTriangles;
		}
		
		// add the verticies for the faces. 
		dwIndexes = m_Connect[dwCount].Faces.size();
		dwTriangles+=lpPoly->ComputeTriangulatedVerticies(dwIndexes);
		
	}

	delete lpPoly;
	return dwTriangles;

}

DWORD CXMeshData::NumTriangles()
{
CPoly2Tri	*lpPoly= new CPoly2Tri();
DWORD		dwCount = 0;
bool		bFirstTime = true;
DWORD		dwTriangles=0;
DWORD		dwIndexes=0;

	// simple control break on the numeric
	for(dwCount=0;dwCount<m_Connect.size();dwCount++) {

		// add the verticies for the faces. 
		dwIndexes = m_Connect[dwCount].Faces.size();
		dwTriangles+=lpPoly->ComputeTriangulatedVerticies(dwIndexes);
		
	}

	delete lpPoly;
	return dwTriangles;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXMeshData::GetMeshData(LPDIRECTXFILEDATA pFileData)
{
HRESULT					hr = S_OK;
long					lRet = C_SUCCESS;
LPDIRECTXFILEOBJECT		pChildObj = NULL;
LPDIRECTXFILEDATA		pChildData = NULL;
const GUID*				pGUID;
PBYTE					pData= NULL;
DWORD					cbSize;

	// get a pointer the the raw data in the file.
    hr = pFileData->GetData( NULL, &cbSize, (VOID**)&pData );
    if( FAILED(hr) )
        return C_ERR_CANNOT_GET_XDATA;
	
	// load the model information.
	// this routine will also advance the pData pointer
	// so that it points to the next payload data.
	lRet = GetMeshVerticies(&pData);
	lRet = GetMeshFaceIndicies(&pData);
	
    // Enumerate child objects
    while( SUCCEEDED( pFileData->GetNextObject( &pChildObj ) ) ) {
        // Query the child for it's FileData
        hr = pChildObj->QueryInterface( IID_IDirectXFileData,
                                        (VOID**)&pChildData );
        if( SUCCEEDED(hr) )  {
			// Get the type of the object
			if( FAILED( hr = pChildData->GetType( &pGUID ) ) )
				return C_ERR_CANNOT_GET_XTYPE;

			if (*pGUID == TID_D3DRMMeshMaterialList) {
				lRet =  GetMeshMaterialList(pChildData);

			} else if (*pGUID == TID_D3DRMMeshNormals && !m_bCalcNormals) {
				lRet = GetMeshLightingNormals(pChildData);

			} else if (*pGUID == TID_D3DRMMeshTextureCoords) {
				lRet = GetMeshTextureCordinates(pChildData);

			} else if (*pGUID == TID_D3DRMMeshVertexColors) {
				lRet = GetMeshVertexColors(pChildData);
			}

			pChildData->Release();
        }
				
        pChildObj->Release();

        if( FAILED(hr) )
            return C_ERR_CANNOT_GET_XDATA;
    }
	return C_SUCCESS;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXMeshData::GetMeshVerticies(LPBYTE *lplpData)
{
D3DVECTOR				*pVector;
DWORD					dwLoop;
DWORD					dwVerts;
LPBYTE					pData = *lplpData;

	// get the number of verticies in the model
	memcpy(&dwVerts, pData, sizeof(DWORD));
	pData+=sizeof(DWORD);

	// allocate memory to hold the verticies
	m_Vertex.clear();

	// set pointer to the vertext information 
	pVector = (D3DVECTOR*)(pData);
	 
	// copy the information to the array
	for (dwLoop=0;dwLoop<dwVerts;dwLoop++) {
		m_Vertex.push_back(Vector3(pVector->x, pVector->y, pVector->z));
		pVector++;
	}

	// advance to the indexes in the stream
	pData+=(sizeof(D3DVECTOR) * dwVerts);
	*lplpData = pData;

	return C_SUCCESS;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXMeshData::GetMeshFaceIndicies(LPBYTE *lplpData)
{
DWORD					*pdwFaceVertexIndex;
DWORD					dwCount;
DWORD					dwLoop;
DWORD					dwFaces;
DWORD					dwIndexes;
FaceArray				Item;
LPBYTE					pData = *lplpData;

	// get the number of face indexes
	memcpy(&dwIndexes, pData, sizeof(DWORD));
	
	// set pointer to the index data in the stream	
	//memcpy(pdwFaceVertexIndex, pData, sizeof(DWORD));
	pdwFaceVertexIndex = (DWORD *)(pData + sizeof(DWORD));	

	// allocate array
	m_Connect.clear();

	// move the information 
	for (dwCount=0;dwCount<dwIndexes;dwCount++) {

		dwFaces = *pdwFaceVertexIndex;
		pdwFaceVertexIndex++;

	

		// place all the polygon faces into the Polygon 2 
		// triangle class
		Item.Faces.clear();
		for(dwLoop=0;dwLoop<dwFaces;dwLoop++) {
			Item.Faces.push_back(*pdwFaceVertexIndex);
			pdwFaceVertexIndex++;
		}
		
		m_Connect.push_back(Item);

	}

	*lplpData = pData;

	return C_SUCCESS;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXMeshData::GetMeshMaterialList(LPDIRECTXFILEDATA pFileData)
{
HRESULT					hr = S_OK;
long					lRet = C_SUCCESS;
PBYTE					pData= NULL;
DWORD					dwMaterials = 0;
DWORD					dwFaceIndexes =0;
DWORD					dwCount = 0;
DWORD					cbSize;
DWORD					dwIndex;

	hr = pFileData->GetData( NULL, &cbSize, (VOID**)&pData );
	if( FAILED(hr) )
		return C_ERR_CANNOT_GET_XDATA;

	memcpy(&dwMaterials, pData, sizeof(DWORD));
	pData+=sizeof(DWORD);

	memcpy(&dwFaceIndexes, pData, sizeof(DWORD));
	pData+=sizeof(DWORD);
	
	m_MaterialList.clear();

	for (dwCount=0;dwCount<dwFaceIndexes;dwCount++) {

		// the stream contains a zero based index to the material.
		// the pMaterials list was populated and created in the load 
		// routine. THis list comes first in the format.
		memcpy(&dwIndex, pData, sizeof(DWORD));
		pData+=sizeof(DWORD);

		m_MaterialList.push_back(dwIndex);
	}

	return C_SUCCESS;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXMeshData::GetMeshLightingNormals(LPDIRECTXFILEDATA pFileData)
{
HRESULT					hr = S_OK;
long					lRet = C_SUCCESS;
PBYTE					pData= NULL;
DWORD					dwCount = 0;
bool					bCalcNormals = false;
DWORD					dwNormals;
D3DVECTOR				*pVector=NULL;
DWORD					cbSize;

	// if calculating the normals 
	if(m_bCalcNormals) {
		m_Normals.clear();
		return C_SUCCESS;
	}
	
	// get pointer to payload 
	hr = pFileData->GetData( NULL, &cbSize, (VOID**)&pData );
	if( FAILED(hr) )
		return C_ERR_CANNOT_GET_XDATA;
	
	// determine if the mesh has the correct number of lighting normals. 
	memcpy(&dwNormals, pData, sizeof(DWORD));				
	pData+=sizeof(DWORD);

	if(dwNormals != m_Vertex.size()) {
		//cout << "\nWarning. The XFile does not contain the proper amount of vertex normals.\n";
		//cout << "Using MGC to calculate lighting normals.\n\n" << flush;
		bCalcNormals = true;		
	}

	// if normals are not going to be calculated, but read from the file
	if(!bCalcNormals) {

		// set pointer to the vertext information 
		pVector = (D3DVECTOR*)(pData);	 

		// copy the information to the array
		for (dwCount=0;dwCount<dwNormals;dwCount++) {
			m_Normals.push_back(Vector3(pVector->x, pVector->y, pVector->z));
			pVector++;
		}
	}
	
	return C_SUCCESS;
}

/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXMeshData::GetMeshTextureCordinates(LPDIRECTXFILEDATA pFileData)
{
HRESULT					hr = S_OK;
long					lRet = C_SUCCESS;
PBYTE					pData= NULL;
DWORD					dwCount = 0;
bool					bCalcNormals = false;
DWORD					dwTextureCords;
float					*tVal;
float					tu;
float					tv;
DWORD					cbSize;

	hr = pFileData->GetData( NULL, &cbSize, (VOID**)&pData );
	if( FAILED(hr) )
		return C_ERR_CANNOT_GET_XDATA;

	memcpy(&dwTextureCords, pData, sizeof(DWORD));				
	m_Texture.clear();
	tVal= (float*)(pData+sizeof(DWORD));

	// move the information
	for (dwCount=0;dwCount<dwTextureCords;dwCount++) {
		tu = *tVal;
		tVal++;
		tv = *tVal;
		tVal++;

		m_Texture.push_back(Vector2( tu  , tv));
		
	}

	return C_SUCCESS;

}


/************************************************************************************
	Function

	Parameters

	Returns

	Description

  When		Who		What
  =======	=====	=================

*************************************************************************************/
long CXMeshData::GetMeshVertexColors(LPDIRECTXFILEDATA pFileData)
{
HRESULT					hr = S_OK;
long					lRet = C_SUCCESS;
PBYTE					pData= NULL;
DWORD					dwCount = 0;
bool					bCalcNormals = false;
DWORD					dwVertexColors;
DWORD					cbSize;
D3DCOLORVALUE			pColor;
VertexIndexColor		Item;


	hr = pFileData->GetData( NULL, &cbSize, (VOID**)&pData );
	if( FAILED(hr) )
		return C_ERR_CANNOT_GET_XDATA;

	memcpy(&dwVertexColors, pData, sizeof(DWORD));				
	m_VertexColors.clear();
	pData+=sizeof(DWORD);

	// move the information
	for (dwCount=0;dwCount<dwVertexColors;dwCount++) {
		memcpy(&Item.dwVertexIndex, pData, sizeof(DWORD));
		pData+=sizeof(DWORD);

		memcpy(&pColor, pData, sizeof(D3DCOLORVALUE));
		Item.vColor = ColorRGB(pColor.r, pColor.g, pColor.b);
		pData += sizeof(D3DCOLORVALUE);

		m_VertexColors.push_back(Item);
		
	}

	return C_SUCCESS;
}


