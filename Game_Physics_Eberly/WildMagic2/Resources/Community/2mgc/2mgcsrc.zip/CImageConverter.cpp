/*****************************************************************************************
The image load support - NexgenIPL Version 2.9.1 - is provided by: 

		www.binary-technologies.com
	
BMP, PCX, PNG, PBM, PPM, PGM, TGA, TIFF, JPEG, GIF (animated), IFF, ILBM, RAS, EPS,
         ICO, MNG, JNG, WMF, EMF, AMP, PSP, JP2, JPC, YUV, CUT

*****************************************************************************************/
#pragma warning( disable : 4786 4788 )
#include "CImageConverter.h"
#include <stdio.h>

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
CImageConverter::CImageConverter()
{
	m_aucDst=NULL;
	m_iResizeWidth=-1;
	m_iResizeHeight=-1;
	m_lResFilter=BTCImageData::BTResizeFilter::Default;
    m_pkImage=NULL;
}

CImageConverter::~CImageConverter()
{
	Cleanup();
}

void CImageConverter::Cleanup(void)
{
	//delete []m_aucDst;
	m_iResizeWidth=-1;
	m_iResizeHeight=-1;
	m_lResFilter=BTCImageData::BTResizeFilter::Default;
}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
void CImageConverter::setResize(int iWidth, int iHeight, BTCImageData::BTResizeFilter lResFilter)
{
	m_iResizeWidth = iWidth;
	m_iResizeHeight = iHeight;
	m_lResFilter = lResFilter;
}

void CImageConverter::setResize(char *szDimension, char *szFilter)
{
char *lpPos;
char *szTmp;
char *ptr;

	if(!szDimension)
		return;

	szTmp = new char[strlen(szDimension)+1];
	strcpy(szTmp, szDimension);

	for (ptr = szTmp; *ptr; ptr++) {
		*ptr = toupper( *ptr );
		if(*ptr=='-') *ptr='_';
	}

	lpPos = strstr(szTmp, "X");
	if(!lpPos) {
		m_iResizeWidth=-1;
		m_iResizeHeight=-1;
		m_lResFilter=BTCImageData::BTResizeFilter::Default;
	} else {
		*lpPos=0x00;
		m_iResizeWidth = atoi(szTmp);
		m_iResizeHeight = atoi(lpPos+1);
		m_lResFilter = Str2Filter(szFilter);
	}

}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
long CImageConverter::Convert(void)
{
	if(FAILED(ConvertToMif())) {
		printf("Unable to convert %s\n", m_szInputFile);
		return C_ERR_UNKNOWN_FORMAT;
	}

	printf("%s\n", m_szInputFile);

//	m_pkImage->SetName(m_szInputFile);
	m_pkImage->Save(m_szOutputFile);	
	delete m_pkImage;
	Cleanup();

	return C_SUCCESS;

}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	================= 
	5/13/02	AFM		Created.

*************************************************************************************/
Image *CImageConverter::ConvertToMgcImage(void)
{
	ConvertToMif();
	Cleanup();
	return m_pkImage;
}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
bool CImageConverter::ValidFormat(char *szExt)
{
	char *lpPos=NULL;
	char *s[] = {"BMP", "PCX", "PNG", "PBM", "PPM", "PGM", \
				"TGA", "TIFF", "TIF", "JPEG","JPG", "GIF", "IFF", "ILBM", \
				"RAS", "EPS", "ICO", "MNG", "JNG", "WMF", \
				"EMF", "AMP", "PSP", "JP2", "JPC", "YUV", \
				"CUT", 0x00}; 
	
	lpPos = strstr(szExt,".");
	if(lpPos)
		lpPos++;
	else
		lpPos = szExt;

	for(char **p=s;*p;p++) {
		if(stricmp(lpPos,*p)==0) {
			return true;
		}
	}

	return false;

}

/************************************************************************************
	Function: The NexgenIPL library says it handles these however cannot read 
		them. This function is responsible for deciding which formats are to be 
		handled by means other than the NexgenIPL library.

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
bool CImageConverter::InternalFormat(char *szExt)
{
	char *lpPos=NULL;
	char *s[] = {"JPG", "JP2", "TIFF", "TIF", 0x00}; 
	
	lpPos = strstr(szExt,".");
	if(lpPos)
		lpPos++;
	else
		lpPos = szExt;

	for(char **p=s;*p;p++) {
		if(stricmp(lpPos,*p)==0) {
			return true;
		}
	}

	return false;

}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
HRESULT CImageConverter::ConvertToMif(void)
{
char szTmp[MAX_PATH];
char *lpPos;

	if(FAILED(FindFile(m_szTextureDirectory, m_szInputFile, szTmp )))
		return E_FAIL;
	
	if(FAILED(ReadImageBits(szTmp)))
		return E_FAIL;
	
	// the information for the stream should be saved in the 
	// MGC file, but it only writes out the file name.
	// it looks like a tmp fix that dave did or could be a bug
	lpPos = strstr(szTmp,".");
	if(lpPos) {
		*lpPos = 0x00;
		//memset(szTmp,0x00,MAX_PATH);
		//strncpy(szTmp, m_szInputFile, lpPos- m_szInputFile);
		strcat(szTmp, ".mif");

	} else {
		strcpy(szTmp, m_szInputFile);
		strcat(szTmp, ".mif");
	}

	m_pkImage = new Image(Image::IT_RGB888,m_iWidth,m_iHeight,m_aucDst, szTmp);

    assert( m_pkImage );

	return S_OK;
}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
HRESULT CImageConverter::ReadImageBits(char *lpFileName)
{
BTCImageObject	lpImage;
BTCIFStream		lpInputStream;
BTCImageData	lpImageData;
BTCOLORREF		dwColor;
int				x;
int				y;
int				i0,i1,i2;
int				iDesiredWidth =0;
int				iDesiredHeight =0;
	
	// if the format is an internal one
	if(InternalFormat(lpFileName)) {

		// add our own JPG codec. 
		lpImage.RemoveCodec(BTFILETYPE_JPEG, BTCODECTYPE_DECODER );
		lpImage.AddCodec(BTFILETYPE_INTEL_JPG, new CBTCDecoderJPG());
		
		// add our TIFF decoder.
		lpImage.RemoveCodec(BTFILETYPE_TIFF, BTCODECTYPE_DECODER );
		lpImage.AddCodec(BTFILETYPE_TIFF_ORG, new CBTCDecoderTIFF());

	}

	// Open input stream.
	if(!lpInputStream.Open(lpFileName))
		return E_FAIL;

	// Load any image.
	if(!lpImage.Load( &lpInputStream)) {
		lpInputStream.Close();
		return E_FAIL;
	}


	lpImageData = lpImage.GetObjectData();

	// size the image to the nearest power of two
	int iNearestPowerWidth=1;
	int iNearestPowerHeight=1;

	iDesiredWidth = m_iResizeWidth==-1  ? lpImageData.GetWidth()  : m_iResizeWidth;
	iDesiredHeight= m_iResizeHeight==-1 ? lpImageData.GetHeight() : m_iResizeHeight;

	while(iNearestPowerWidth < iDesiredWidth)
		iNearestPowerWidth=iNearestPowerWidth<<1;

	while(iNearestPowerHeight < iDesiredHeight)
		iNearestPowerHeight=iNearestPowerHeight<<1;

	if(!lpImageData.Resize( iNearestPowerWidth, iNearestPowerHeight, m_lResFilter))
		return E_FAIL;

	// Should be a 24 bit image. 
    if ( lpImageData.GetBitsPerPixel() != 24 ) {
		// could not process. 
		if(!lpImageData.ConvertTo24BPP()) {
			return E_FAIL;
		}
    }

	// copy the information 
    m_iWidth = lpImageData.GetWidth();
    m_iHeight = lpImageData.GetHeight();
    int iQuantity = m_iWidth*m_iHeight;
	
	// Windows BMP stores BGR, need to invert to RGB.
    m_aucDst = new unsigned char[3*iQuantity];

	// move the data 
	i0 = 0, i1 = 1, i2 = 2;

	for(y=0;y<m_iHeight;y++) {
		for(x=0;x<m_iWidth;x++) {
			// get pixel data 
			dwColor = lpImageData.GetColorFromPixel(x,m_iHeight-y-1);
			
			// move color to channel
			m_aucDst[i0] = BTGetRValue(dwColor);
			m_aucDst[i1] = BTGetGValue(dwColor);
			m_aucDst[i2] = BTGetBValue(dwColor);
			i0 += 3;
			i1 += 3;
			i2 += 3;
		}
	}

	// clean up	
	lpInputStream.Close();

	if(InternalFormat(lpFileName)) {
		lpImage.RemoveCodec(BTFILETYPE_INTEL_JPG, BTCODECTYPE_DECODER );
		lpImage.RemoveCodec(BTFILETYPE_TIFF_ORG, BTCODECTYPE_DECODER );
	}

	return S_OK;
}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
bool CImageConverter::PreprocessImageData(BTCImageData lpImageData, BTCImageData &lpNewImage)
{
int iNearestPowerWidth=1;
int iNearestPowerHeight=1;

	while(iNearestPowerWidth < lpImageData.GetWidth())
		iNearestPowerWidth=iNearestPowerWidth<<1;

	while(iNearestPowerHeight < lpImageData.GetHeight())
		iNearestPowerHeight=iNearestPowerHeight<<1;

	lpNewImage.Create(iNearestPowerWidth, iNearestPowerHeight, 24);

	if(!lpImageData.Resize(lpNewImage, iNearestPowerWidth, iNearestPowerHeight, m_lResFilter))
		return false ;

	// Should be a 24 bit image. 
    if ( lpNewImage.GetBitsPerPixel() != 24 ) {
		// could not process. 
		if(!lpNewImage.ConvertTo24BPP()) {
			return false;
		}
    }

	return true;
}

/************************************************************************************
	Function: Usage

	Parameters:
	Returns: 
	Description: 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
BTCImageData::BTResizeFilter CImageConverter::Str2Filter(char *szFilter)
{
long lLen;
		if(szFilter==0x00)
			return BTCImageData::BTResizeFilter::Default;

		lLen = strlen(szFilter);
		if(strnicmp(szFilter, "Default", lLen)) {
				return BTCImageData::BTResizeFilter::Default;

		} else if (strnicmp(szFilter, "Box", lLen)) {
				return BTCImageData::BTResizeFilter::Box;

		} else if (strnicmp(szFilter, "Bilinear", lLen)) {
				return BTCImageData::BTResizeFilter::Bilinear;

		} else if (strnicmp(szFilter, "Gaussian", lLen)) {
				return BTCImageData::BTResizeFilter::Gaussian;

		} else if (strnicmp(szFilter, "Hamming", lLen)) {
				return BTCImageData::BTResizeFilter::Hamming;

		} else if (strnicmp(szFilter, "Blackman", lLen)) {
				return BTCImageData::BTResizeFilter::Blackman;

		} else if (strnicmp(szFilter, "Triangle", lLen)) {
				return BTCImageData::BTResizeFilter::Triangle;

		} else if (strnicmp(szFilter, "Bell", lLen)) {
				return BTCImageData::BTResizeFilter::Bell;

		} else if (strnicmp(szFilter, "BSpline", lLen)) {
				return BTCImageData::BTResizeFilter::BSpline;

		} else if (strnicmp(szFilter, "Sinc", lLen)) {
				return BTCImageData::BTResizeFilter::Sinc;

		} else if (strnicmp(szFilter, "Lanczos3", lLen)) {
				return BTCImageData::BTResizeFilter::Lanczos3;

		} else if (strnicmp(szFilter, "Mitchell", lLen)) {
				return BTCImageData::BTResizeFilter::Mitchell;

		} else if (strnicmp(szFilter, "Quadratic", lLen)) {
				return BTCImageData::BTResizeFilter::Quadratic;

		} else if (strnicmp(szFilter, "Hermite", lLen)) {
				return BTCImageData::BTResizeFilter::Hermite;

		} else if (strnicmp(szFilter, "Hanning", lLen)) {
				return BTCImageData::BTResizeFilter::Hanning;

		} else if (strnicmp(szFilter, "Catrom", lLen)) {
				return BTCImageData::BTResizeFilter::Catrom;

		} else if (strnicmp(szFilter, "Cubic", lLen)) {
				return BTCImageData::BTResizeFilter::Cubic;

		} else if (strnicmp(szFilter, "Hann4", lLen)) {
				return BTCImageData::BTResizeFilter::Hann4;

		} 

	return BTCImageData::BTResizeFilter::Default;
}

/************************************************************************************
	Function: FindFile

	Parameters:
		char *szDirs - A semicolon delimited string with path names. 
		char *lpFile - the file being sought
		char *szOutput  - the output path if one is found. 

	Returns: 
	Description: The routine scanns all the directors named for the file. 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
HRESULT CImageConverter::FindFile(char *szDirs, char *lpFile, char *szOutput )
{
char *lpCH;
char szTmp[MAX_PATH];
	
	// see if the file exists in the current path 
	if(FileExists(lpFile)) {
		strcpy(szOutput,lpFile);
		return true;
	}

	// if the driecotry was NOT sent
	if(szDirs) {
		// create temp working array for null tokens 
		strcpy(szTmp,szDirs);

		lpCH = strtok( szTmp, ";");
		while( lpCH != NULL )	{

			// build the texture. 
			strcpy(szTmp, lpCH );
			strcat(szTmp,lpFile);

			// see if the file exists in the current path 
			if(FileExists(szTmp)) {
				strcpy(szOutput,szTmp);
				return S_OK;
			}

			// goto the next
			lpCH  = strtok( NULL, ";");
		}
		
	}

 	// nope, do not load the file 
	*szOutput = 0x00;
	return E_FAIL;

}

/************************************************************************************
	Function: FileExists

	Parameters: char *lpFile

	Returns: bool - True the file does exist. - false the file was not found.

	Description: The function uses the sdio function fopen to determine if the file 
		is  in the located named. 

	When	Who		What
	=======	=====	=================
	5/13/02	AFM		Created.

*************************************************************************************/
bool CImageConverter::FileExists(char *lpFile)
{
	FILE	*f1;
	bool	bRet;

	f1 = fopen(lpFile,"r");
	if(f1) {
		bRet = true;
		fclose(f1);
	} else {
		bRet = false;
	}

	return bRet;
}
