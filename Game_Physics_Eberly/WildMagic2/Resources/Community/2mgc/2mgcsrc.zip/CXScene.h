
#ifndef CXSCENE_H
#define CXSCENE_H

#include <windows.h>
#include <iostream.h>
#include <objbase.h>
#include "D3d8types.h"
#include "dxfile.h"
#include "rmxfguid.h"

#include "CConverter.h"
#include "CXMaterial.h"
#include "CXMeshData.h"
#include "CIndirectIndex.h"

using namespace Mgc;
using namespace std;

typedef vector<CXMaterial *, allocator<CXMaterial *> > CXMaterialArray;
typedef vector<char *, allocator<char *> > StringArray;

class CXScene : public CConverter
{
public:
	CXScene();
	~CXScene();

	long Convert(void);
	
private:
	long LoadScene(char *szFilename);

	long LoadFrame(LPDIRECTXFILEDATA pFileData, Node *pParent, CXMaterialArray	*lpMaterial);
	long LoadMesh(LPDIRECTXFILEDATA pFileData, Node *pParent, CXMaterialArray	lpMaterial);
	long LoadTransformMatrix(LPDIRECTXFILEDATA pFileData, Node *pParent);	
	long LoadMaterial(LPDIRECTXFILEDATA pFileData, CXMaterialArray *lpMaterial);

	long AddFacetoMgcModelData(CXMeshData *pMeshModelData, DWORD dwFace, CIndirectIndex *pCIndirect);	
	void BuildMgcModel(Node *pParent, CXMaterial *lpXMaterial, char *lpName);
	void SetObjectName( LPDIRECTXFILEDATA pFileData, Node *pParent );
	void ClearNames();
	void SaveNames(char *szFilename);

private:	
    NodePtr				m_spkScene;
	NodePtr				m_Trans;

	int					*m_aiConnect;
	Vector3				*m_akVertex;
	Vector3				*m_akNormal;
	ColorRGB			*m_akColor;
	Vector2				*m_akTexture;

	DWORD				m_dwVertexCount;
	DWORD				m_dwConnectionCount;

	DWORD				m_dwVertexAllocatedSize;
	DWORD				m_dwConnectionAllocatedSize;
	DWORD				m_dwTotalTriangles;
	StringArray			m_ObjNames;

};

#endif
