import sys
from simbad.gui import *
from simbad.sim import *
from simbad.sim.RobotFactory import addSonarBeltSensor
from javax.vecmath import *

# a very simple robot controller
class MyRobot(Agent): 

	def __init__(self, vector, name):
		Agent.__init__(self, vector, name)
		# sonars start as front sonar being #0, and increasing 
		# counter-clockwise
		self.sonars = addSonarBeltSensor(self, 12) 
		self.out = open('/tmp/complex-world-robot.dat', 'w')
		
	def initBehavior(self):
		# The plan we want to execute
		self.plan = [['move', 8], # straight down
			     ['turn',90],['move', 8], # turn left, forward
			     ['turn',90],['move', 8], # turn left, forward
			     ['turn',90],['move', 8], # turn left, forward
			     ['turn',90],['move', 8]  # turn left, forward
			     ]
		# a counter representing time left for current action 
		self.count = 0 
	
	def performBehavior(self):
		# when counter exhausted, fetch next action
		if self.count<1: self.nextAction()
		self.count -=1 
		if self.getCounter() % 10 == 0:
			#print "Count: " + str(self.count)
			for i in xrange(12):
				self.out.write(str(self.sonars.getMeasurement(i)) + " ")
			self.out.write('\n')
			self.out.flush()
			   	
	def nextAction(self):
		""" set up the next action """
		fps = self.getFramesPerSecond()
		#print "fps="+str(fps) # this prints 20
		if len(self.plan)==0 : 
			self.setvel(0,0)
			return
		action = self.plan.pop(0)
		print action
		# a turn action ?
		if action[0] == 'turn':
			rv = 0.5
			self.count= fps*(degToRad(action[1]))/rv
			self.setvel(0, rv)
			self.out.write('turn\n')

		# a move action
		elif action[0] =='move':
			tv = 0.5
			self.count = fps*action[1]/tv
			self.setvel(tv, 0)
			self.out.write('forward\n')

	def setvel(self, tv, rv):
		""" shortcut for setting velocities"""		
		self.setTranslationalVelocity(tv)
		self.setRotationalVelocity(rv)
			
def degToRad(deg):
	""" convert degrees to radians """
	return  deg * (3.1416/180.0)
			

# description of the environment 
class MyEnv(EnvironmentDescription):
	def __init__(self):
		self.objects = [
			[0.864850921137, 0.857083294131],
			[-1.64107392071, -1.43868093957],
			[0.669733669706, -2.57848514928],
			[-2.25816095799, 1.59228745542],
			[-0.63179945525, -0.396925880353],
			[2.79360024313, -0.604155022976],
			[0.450915864356, 1.2644821005],
			[-1.49508318683, 3.00175224174],
			[0.0629267182819, -0.7924086609],
			[-2.74548484045, 1.50716715809],
			[-1.09221932463, -1.80189355509],
			[2.10478559492, 1.30650408661],
			[3.1, -2]
			]

		self.add(Arch(Vector3d(1.7, 0, 2.5), self))
		self.setWorldSize(12);
		self.setUsePhysics(True);
		self.add(Box(Vector3d(-5, 0, 0), Vector3f(0.1, 1, 10), self));
		self.add(Box(Vector3d(0, 0, -5), Vector3f(10, 1, 0.1), self));
		self.add(Box(Vector3d(5, 0, 0), Vector3f(0.1, 1, 10), self));
		self.add(Box(Vector3d(0, 0, 5), Vector3f(10, 1, 0.1), self));
		self.add(MyRobot(Vector3d(-4, 0, 4), "Python Robot"));
		for n in xrange(len(self.objects)):
			x = self.objects[n][0]
			z = self.objects[n][1]
			self.add(Wall(Vector3d(x, 0, z), 1, 1, self))
			
			
# launch simbad 
simbad = Simbad(MyEnv(),0)
	
	
