#!/usr/bin/env python
# vim: set fileencoding=utf-8
'''
test.py
Written 2008-6-6 by Peter Mawhorter
This script tests the FastSLAM 1 implementation and provides
visualization for the testing.
'''

# TODO: make this not a hack.
import sys
sys.path.append("../../visualizer/")
sys.path.append("FastSLAM_1/")

import math, time

import visualizer

import fastslam

import components

# The scale factor, to work with the visualizer:
sf = 10

# Landmark positions, keyed by identities:
landmarks = {
"hey": (5*sf, 5*sf),
"over here": (1*sf, 8*sf),
"ooh, pick me": (-3*sf, -2*sf),
"me, me!": (4*sf, -3*sf),
"test1": (5*sf, 0*sf),
"test2": (3*sf, 3*sf),
"test3": (3*sf, -3*sf),
"test4": (1*sf, 4*sf)
}

# Poses: snapshots of the robot's pose over time, along with which
# landmarks are "visible" at each pose:
poses = [
((0*sf, 0*sf, 0), ()),
((2*sf, 1*sf, math.pi/4.), ("hey",)),
((3*sf, 3*sf, math.pi/2.), ("hey", "over here")),
((3*sf, 5*sf, math.pi/2. + math.pi/6.), ("over here",)),
((1*sf, 6*sf, math.pi), ()),
((-1*sf, 5*sf, math.pi + math.pi/4.), ()),
((-2*sf, 3*sf, math.pi + math.pi/2.), ("ooh, pick me",)),
((-2*sf, 1*sf, math.pi + math.pi/2.), ("ooh, pick me",)),
((-1*sf, -1*sf, math.pi + math.pi/2. + math.pi/4.), ()),
((1*sf, -2*sf, 0), ("me, me!",)),
((3*sf, -1*sf, math.pi/4.), ("hey",)),
((3*sf, 0*sf, math.pi/2.), ("hey",)),
((3*sf, 2*sf, math.pi/2.), ("hey", "over here")),
((2*sf, 5*sf, math.pi/2. + math.pi/4.), ("over here",))
]

#poses = [
#((0, 0, 0), ("test1", "test2", "test3", "test4")),
#((0*sf, -5*sf, 0), ("test1", "test2", "test3", "test4"))
#]


# Landmark positions and robot poses:
#                  |
#                  | X
#                  |
#                  | -
#                / 5   \ \   X
#                  |
#              |   |     |
#                  |     |
#              |   |   /
#- - - - 5 - - - - > - - | - 5 - - - - -
#                \ |     /
#            X     | -
#                  |       X
#                  |
#                  5
#                  |
#                  |
#                  |
#                  |

# A globally unique identifying number:
idn = 0

thread, queue = visualizer.startThreaded()

particles = [
components.Particle(components.Path([components.Pose(x=0, y=0, thr=0)]))
  for i in range(5)]

print "Press Enter to step through the test."

lastpose = (0, 0, 0)
for p, lms in poses:
  offset = p[0] - lastpose[0], p[1] - lastpose[1], p[2] - lastpose[2]
  lastpose = p
  times = 0
  for lm in lms:
    lmcoords = landmarks[lm]
    x, y = lmcoords[0] - p[0], lmcoords[1] - p[1]
    thr = math.atan2(y, x)
    range = (x**2 + y**2)**0.5
    measurement = (range, thr - p[2])
    if times == 0:
      particles = fastslam.FastSLAM(particles, offset, measurement, lm)
    else:
      particles = fastslam.FastSLAM(particles, (0, 0, 0), measurement, lm)
    times += 1
  if not lms:
    for particle in particles:
      particle.path.poses.append(components.Pose(x = p[0],
                                                 y = p[1],
                                                 thr = p[2]))
  queue.put("clear")
  for particle in particles:
    loc = particle.path.poses[-1]
    #print loc
    for key in particle.landmarks:
      lm = particle.landmarks[key]
      queue.put(visualizer.Landmark(id = str(idn),
                                    x = lm.x,
				    y = lm.y,
				    covar = lm.covar))
      idn += 1
    queue.put(visualizer.Robot(id = str(idn),
                               x = loc.x,
			       y = loc.y,
			       thr = loc.thr))
    idn += 1
  raw_input()
