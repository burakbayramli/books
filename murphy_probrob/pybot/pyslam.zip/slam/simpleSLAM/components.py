'''
components.py
Written 2008-6-4 by Peter Mawhorter
This module defines a bunch of data-oriented classes used in the FastSLAM
implementation in fastslam.py. These classes just represent simple data
abstractions that help the FastSLAM algorithm be easy to understand.
'''

import copy


# This constant indicates a radius of convergence for floating point
# values:
moreOrLessTheSame = 0.0000000000001

class CovarianceError(Exception):
  '''
  This error indicates that a matrix is not a covariance matrix, even
  though it should be.
  '''
  def __init__(self, matrix):
    '''
    This constructor takes as an argument the singular matrix.
    '''
    self.matrix = matrix

  def __str__(self):
    return "Bad Covariance Matrix: " + str(self.matrix)

  def __repr__(self):
    return "CovarianceError(" + repr(self.matrix) + ")"

class Particle(object):
  '''
  This class describes a single FastSLAM particle. In FastSLAM,
  particles contain a single estimated pose as well as gaussian location
  estimates for each landmark. Particles also contain an importance
  factor, which weights them during resampling.
  '''
  def __init__(self, path = None, landmarks = {}, importance = 1):
    '''
    This constructor takes a path (a Path object), a dictionary of
    landmarks (a dictionary of Landmark objects), and an importance
    value (a number) and creates the defined Particle.
    '''
    self.path = path
    self.landmarks = dict(landmarks)
    self.importance = importance

  def __str__(self):
    if self.path:
      return "a FastSLAM particle with " + str(self.path) + " and " +\
             str(len(self.landmarks.keys())) + " landmarks"
    else:
      return "a FastSLAM particle with " + str(len(self.landmarks.keys())) +\
             " landmarks"

  def __repr__(self):
    return "Particle(" + repr(self.path) + ", " +\
                         repr(self.landmarks) + ")"

  def __copy__(self):
    return self

  def __deepcopy__(self, memo):
    ret = Particle()
    memo[id(self)] = ret
    ret.path = copy.deepcopy(self.path, memo)
    ret.landmarks = copy.deepcopy(self.landmarks, memo)
    ret.importance = self.importance
    return ret

class Pose(object):
  '''
  This class holds all of the information about robot pose used in the
  algorithm. It just stores information, and doesn't have any methods.
  '''
  def __init__(self, **kwargs):
    '''
    This constructor takes arbitrary keyword arguments, and assigns them
    to class member variables as appropriate. The accepted keyword
    arguments are:
      x - The x position of the robot. A number. Defaults to 0.
      y - The y position of the robot. A number. Defaults to 0.
      thr - The bearing of the robot in radians. A number. Defaults to 0.
    '''
    defaults = {
      'x':0,
      'y':0,
      'thr':0,
    }
    # Overwrite values in the defaults dictionary with values from the kwargs:
    defaults.update(kwargs)

    # Add the member variables:
    self.x = defaults['x']
    self.y = defaults['y']
    self.thr = defaults['thr']

  def __str__(self):
    return "a robot pose at (" + str(self.x) + "," + str(self.y) + ") "\
           "with bearing " + str(self.thr)

  def __repr__(self):
    return "Pose(x = " + repr(self.x) + ", "\
                "y = " + repr(self.y) + ", "\
                "thr = " + repr(self.thr) + ")"

  def __copy__(self):
    return self

  def __deepcopy__(self, memo):
    ret = Pose()
    memo[id(self)] = ret
    ret.x = self.x
    ret.y = self.y
    ret.thr = self.thr
    return ret

class Landmark(object):
  '''
  This class holds all of the information about a landmark used in the
  algorithm. It just stores information, and doesn't have any methods.
  '''
  def __init__(self, **kwargs):
    '''
    This constructor takes arbitrary keyword arguments, and assigns them
    to class member variables as appropriate. The accepted keyword
    arguments are:
      x - The x position of the robot. A number that defaults to 0.
      y - The y position of the robot. A number that defaults to 0.
      covar - The covariance matrix of the landmark. This measures the
              uncertainty of the landmark's position. It must be a 2x2
              two-dimensional tuple. It defaults to ((0,0),(0,0)).
    '''
    defaults = {
      'x':0,
      'y':0,
      'covar':((0,0),(0,0))
    }
    # Overwrite values in the defaults dictionary with values from the
    # kwargs:
    defaults.update(kwargs)

    # Add the member variables:
    self.x = defaults['x']
    self.y = defaults['y']
    self.covar = defaults['covar']
    # Fix rounding errors in covariance by using the higher of b or c:
    if self.covar[0][1] != self.covar[1][0] and \
       self.covar[0][1] - self.covar[1][0] <= moreOrLessTheSame:
      if abs(self.covar[0][1]) > abs(self.covar[1][0]):
        self.covar = ((self.covar[0][0], self.covar[1][0]),
                      (self.covar[1][0], self.covar[1][1]))
      elif abs(self.covar[0][1]) < abs(self.covar[1][0]):
        self.covar = ((self.covar[0][0], self.covar[0][1]),
                      (self.covar[0][1], self.covar[1][1]))
    elif self.covar[0][1] != self.covar[1][0]:
      raise CovarianceError(self.covar)

  def __str__(self):
    return "a landmark at (" + str(self.x) + "," + str(self.y) + ")"

  def __repr__(self):
    return "Landmark(x = " + repr(self.x) + ", "\
                    "y = " + repr(self.y) + ", "\
		    "covar = " + repr(self.covar) + ")"

  def __copy__(self):
    return self

  def __deepcopy__(self, memo):
    ret = Landmark()
    memo[id(self)] = ret
    ret.x = self.x
    ret.y = self.y
    ret.covar = self.covar
    return ret

class Path(object):
  '''
  This class defines a set of poses through time, which together form a
  path traveled by the robot. These objects form the basis of the
  FastSLAM particles, along with lists of landmarks.
  '''
  def __init__(self, poses = None):
    '''
    This constructor takes a (possibly empty) list of poses and stores
    them in this Path object.
    '''
    self.poses = poses

  def __str__(self):
    if self.poses:
      if len(self.poses) <= 2:
	return "a path of poses starting with " + str(self.poses[0]) + \
               " and ending with " + str(self.poses[-1])
      else:
        return "a path of starting at " + str(self.poses[0])
    else:
      return "an empty path"

  def __repr__(self):
    return "Path(" + repr(self.poses) + ")"

  def __copy__(self):
    return self

  def __deepcopy__(self, memo):
    ret = Path()
    memo[id(self)] = ret
    ret.poses = copy.deepcopy(self.poses, memo)
    return ret
