# vim: set fileencoding=utf-8
'''
slam.py
Written 2008-6-4 by Peter Mawhorter
This module implements the FastSLAM algorithm. It can take a continuous
series of sensor and control inputs and update a set of particles to maintain
pose and landmark estimates.
'''

# TODO: Track down and fix the leaping particle error.

# TODO: Make this not a hack:
import sys; sys.path.append("../")

import copy, math, random

# The components module defines data encapsulation classes like Pose and
# Particle that abstract the pieces of the FastSLAM algorithm.
import components

# The functions module defines functions that work with things in the
# components module or just numbers and do useful things with them. Each
# of these functions plays some role in the FastSLAM algorithm.
import functions
# Shortcuts to common functions:
multiply = functions.multiply
add = functions.add
determinant = functions.determinant
inverse = functions.inverse
transpose = functions.transpose
multVector = functions.multVector
multScalar = functions.multScalar

# This global constant defines how accurate the sensors are. It is the
# covariance matrix for the sensors in range and bearing.
# TODO: tune this.
SensorCovariance = ((101, 0),
                    (  0, 0.101))

# The value of σ for the gaussian motion noise (S is for x and y, Sr is
# for θ):
S = 10
Sr = math.pi/6.

# The 2x2 identity matrix:
Identity = ((1, 0),
            (0, 1))

def FastSLAM(particles, offset, measurement, landmarkName):
  '''
  This function takes a collection of components.Particle objects along
  with a 3-tuple specifying robot movement as x, y, and theta offset
  from an old position (theta should be in radians), a 2-tuple
  specifying range and bearing measurements to a landmark (bearing
  should be in radians as well) and the name of the landmark (which may
  be any hashable object such as a tuple, string, or integer, but must
  be unique to the observed landmark). It returns a new collection of
  particles that have been updated based on the motion and observation
  given. This function performs both the Kalman filtering of the
  observation in each particle (using the updateParticle function) and
  the motion model noise addition and resampling (using the updateEach
  and resampleParticles functions).
  '''
  updateEach(particles, offset, measurement, landmarkName)
  return resampleParticles(particles)

def updateEach(particles, offset, measurement, landmarkName):
  '''
  This function updates a set of FastSLAM particles given a new set of
  robot offset and landmark location measurements, as well as the
  identity of the landmark observed. The particles argument should be a
  list or tuple of components.Particle objects which haven't yet had the
  latest robot motion, given by offset, added to them. Offset should be
  a 3-tuple containing x, y, and bearing offsets from the robot's last
  observation location. This offset will be applied to each particle to
  generate a new Pose within that Particle. The measurement argument
  should be a 2-tuple containing range and bearing information; bearing
  should be in radians. This tuple must indicate the measured range
  and bearing to the observed landmark from the robot's position at the
  end of the movement indicated by the offset argument. The final
  argument is landmarkName, which is a hashable object (tuple, string,
  number, etc.) that uniquely identifies the landmark observed. This
  function modifies the given collection of particles in-place, and
  returns None. It does not perform re-sampling.
  '''
  # Add the new pose (indicated by offset) to each particle, and then
  # update it using the updateParticle function:
  # TODO: Fix this motion noise:
  for p in particles:
    last = p.path.poses[-1]
    new = copy.deepcopy(last)
    # Add motion noise:
    new.x += offset[0] + random.gauss(0, S)
    new.y += offset[1] + random.gauss(0, S)
    new.thr += offset[2] + random.gauss(0, Sr)
    p.path.poses.append(new)
    # Update this particle:
    updateParticle(p, measurement, landmarkName)


def updateParticle(particle, measurement, landmarkName):
  '''
  This function performs a FastSLAM update for a single Particle object.
  It takes the particle object to operate on (which must be a
  components.Particle object that contains at least one pose) and a
  single measurement, which consists of a tuple containing a range
  measurement followed by a bearing measurement (the bearing measurement
  should be in radians, the range measurement may have any units. It
  also needs to know the name of the landmark, which can be any hashable
  Python object (string, int, float, etc.), but must be the same for all
  instances of the same landmark. This function returns nothing,
  modifying the given Particle object in place to be properly updated.
  For this function to work, the measurement given must have been taken
  at the last pose in the particle's Path object.
  '''
  # Retrieve the robot's pose information (x, y, and angle) from the
  # Particle. This should be the pose at which the measurement was
  # taken.
  robotPose = particle.path.poses[-1].x, particle.path.poses[-1].y,\
                  particle.path.poses[-1].thr

  # Calculate an x, y offset from the robot to the landmark based on the
  # measured bearing and range from the robot to the landmark.
  landmarkOffset = (measurement[0]*math.cos(measurement[1] + robotPose[2]),
                    measurement[0]*math.sin(measurement[1] + robotPose[2]))

  # Use the robot's estimated position to estimate the landmark
  # position. We don't need to worry about accounting for robot motion
  # noise, because that entire problem is taken care of by having
  # multiple particles and doing noisy particle updates coupled with
  # particle resampling.
  estimatedPosition = (robotPose[0] + landmarkOffset[0],
                       robotPose[1] + landmarkOffset[1])


  # If the landmark's name isn't known, it's a new landmark as far as
  # this particle is concerned.
  if landmarkName not in particle.landmarks.keys():

    # The Jacobian is a matrix of partial derivatives of range and bearing
    # with respect to x and y. It is different at different x any y
    # locations, so we calculate it here for the location of the landmark
    # relative to the location of the robot. It serves as a transform
    # between Cartesian and radial uncertainties in the position of the
    # landmark.
    Jacobian = functions.bearingRangeJacobian(*landmarkOffset)

 
    # The xyUncertainty is a matrix that specifies uncertainty in x and y
    # for the landmark. It describes the uncertainty in the position of
    # the landmark based on the uncertainty in the range and bearing to
    # the landmark. The conversion from range and bearing uncertainty to
    # global position uncertainty is done using the inverse Jacobian of
    # the Cartesian-to-radial conversion function, calculated at the
    # landmark's offset from the robot. Here the ABAtranspose function
    # computes Ji*sqrt(SC) * sqrt(SC)*Ji.transpose where Ji is the
    # inverse Jacobian, and SC is the (known or estimated) uncertainty in
    # range and bearing measurements, the sensor covariance. As a
    # convariance, it describes squared uncertainty, so Ji and Ji
    # transpose are used to covert each square root to Cartesian
    # coordinates. since sqrt(SC)*Ji.transpose results in the transpose of
    # Ji*sqrt(SC), the overall operation is just multiplying a matrix (the
    # uncertainties in Cartesian coordinates) by its transpose, which is
    # equivalent to the squaring operation that converts standard
    # deviation sigma to sigma squared. Thus, the result is analagous to a
    # sigma squared value for a 1-dimensional gaussian distribution, using
    # sensor variance values transformed from range and bearing space into
    # Cartesian space.
    xyUncertainty = functions.ABAtranspose(inverse(Jacobian), SensorCovariance)

    # We've calculated the location and uncertainty of the new landmark,
    # now we just need to add it to the Particle.
    particle.landmarks[landmarkName] = components.Landmark(
                                                     x = estimatedPosition[0],
                                                     y = estimatedPosition[1],
                                                     covar = xyUncertainty)

    # Because this landmark is new, it's equally important in all
    # particles. That is, the observation and odometry doesn't
    # distinguish the particles in terms of likelihood, because there's
    # no past record of this landmark to agree with or disagree with.
    particle.importance = 1

  # If the landmark isn't new, then it must be in the current
  # Particle's landmarks dictionary.
  else:
    # Retrieve what we know about this landmark from the Particle
    # object.
    landmark = particle.landmarks[landmarkName]
    oldPosition = (landmark.x, landmark.y)
    oldUncertainty = landmark.covar

    # Calculate what the xy offset from the robot to the landmark should
    # be, based on where we think the robot is now, and where we think
    # the landmark is, based only on past observations of the landmark.
    # We'll compare this to the current observation to correct our map.
    projectedOffset = (oldPosition[0] - robotPose[0],
                       oldPosition[1] - robotPose[1])
 
    # The forecast is the predicted sensor input. It is just the
    # projected offset converted into radial coordinates.
    forecast = list(functions.rTheta(*projectedOffset))

    # Update the forecast to reflect the robot's rotation:
    forecast[1] = forecast[1] - robotPose[2]
 
    # The difference between the estimate of the landmark position based
    # on the known robot location and the current sensor data, and the
    # estimate of the landmark location based on the known robot
    # location and the previous estimate of the landmark's global
    # location.
    landmarkCorrection = (measurement[0] - forecast[0],
                          measurement[1] - forecast[1])
 
    # The Jacobian is a matrix of partial derivatives of range and bearing
    # with respect to x and y. It is different at different x any y
    # locations, so we calculate it here for the location of the landmark
    # relative to the location of the robot. It serves as a transform
    # between Cartesian and radial uncertainties in the position of the
    # landmark. Unlike for new particles, this Jacobian is based only on
    # our prior knowledge about the landmark, and not on the current
    # observation.
    Jacobian = functions.bearingRangeJacobian(*projectedOffset)

    # This step updates the old uncertainty for this landmark,
    # converting it to radial coordinates using the ABAtranspose pattern
    # with the Jacobian, and then adding the (known/estimated radial)
    # sensor covariance. The result is an updated uncertainty for the
    # position of the landmark, expressed in radial coordinates. The
    # updated value hasn't yet taken into account the Kalman filtering
    # step, which allows the robot to adjust its beliefs according to
    # the difference between the newly measured landmark position and
    # previous measurements thereof. The newUncertainty variable,
    # calculated later, reflects that and carries on to be the
    # uncertainty during the next iteration.
    updatedUncertainty = add(functions.ABAtranspose(Jacobian, oldUncertainty), 
                             SensorCovariance)
 
    # The Kalman gain is just the old uncertainty, converted into radial
    # coordinates by multiplying it on the right by the transpose of the
    # Jacobian, multiplied with the inverse of the updated uncertainty.
    # Since the updated uncertainty is close to the old uncertainty, its
    # inverse is similar to the old uncertainty, so the Kalman gain
    # captures the magnitude of the difference between the old and new
    # uncertainties. It is used in the subsequent step to weight the
    # combination of the old mean and the estimated new mean (taken just
    # from this measurement). Intuitively (and ignoring the fact that
    # we're dealing with covariance matrices instead of scalars), the
    # Kalman gain will be large when the numerator is larger than the
    # denominator, or when the old uncertainty is larger than the new
    # uncertainty. This makes sense: when past measurements don't give
    # us much information about an object's location (perhaps they were
    # taken from far away, making a small angular error into a large
    # position error), the new measurement, being more certain, should
    # be weighted more heavily when averaging it with the old one.
    # Conversely, when we're pretty certain of the object's position
    # based on previous measurements (maybe we've observed it quite
    # accurately or quite a lot), and the most recent measurement isn't
    # that accurate, we want to assign a low weight to the new mean when
    # averaging it with the old one to get the updated estimated mean.
    # If it were a scalar, the Kalman gain would be proportional to the
    # amount of old uncertainty and inversely proporional to the amount
    # of uncertainty in the most recent measurement. It is in fact a
    # matrix, but similar relationships hold. The extra factor of the
    # transposed Jacobian in the Kalman gain just fixes the "units" of
    # the factor. Because the old uncertainty is in Cartesian
    # coordinates, it must be transformed into radial coordinates (by
    # the Jacobian) before being compared with the new uncertainty
    # (which is also expressed in radial coordinates).
    KalmanGain = multiply(multiply(oldUncertainty, transpose(Jacobian)),
                          inverse(updatedUncertainty))
 
    # Update the mean:
    # This step updates the estimated global Cartesian position of the
    # landmark. To do this, it takes the old position, and adds the
    # vector that separates the old position from the position estimated
    # by the current measurement, weighted by the Kalman gain (see
    # above). The result is a revised estimate of the true position of
    # the landmark that fully incorporates the information from the
    # current observation. The equation used is:
    #
    #  mn = mo + K*(obs - old)
    #
    # Where mn is the new mean, mo is the old mean, K is the Kalman
    # gain, obs is the newly observed landmark position, and old is the
    # old landmark position, both in radial coordinates relative to the
    # robot.  (Actually, the obs-old step is carried out above when
    # landmarkCorrection is calculated). The multiplication by K both
    # weights the correction vector and converts it from radial to
    # Cartesian space.
    correctionVector = multVector(KalmanGain, landmarkCorrection)
    newLandmarkPosition = (oldPosition[0] + correctionVector[0],
                           oldPosition[1] + correctionVector[1])
 
    # Update the covariance:
    # This step adjusts the landmark uncertainty based on the calculated
    # Kalman gain. The formula for the adjustment is:
    #
    #   Un = (I - K*J)*Uo
    #
    # Where Un is the new uncertainty, I is the identity matrix, K is
    # the Kalman gain, J is the Jacobian, and Uo is the old uncertainty.
    newUncertainty = multiply(
                       add(
                         Identity,
                         multScalar(
                           multiply(
                             KalmanGain,
                             Jacobian),
                           -1)),
                       oldUncertainty)
 
    # Calculate the importance factor:
    # This step computes the "importance factor" for the current
    # particle. The importance factor is a measurement of how likely
    # this particle's odometry is given the measurements, and provides
    # feedback from the Kalman filtering that determines landmark
    # uncertainties to the particle resampling that handles robot
    # position uncertainties.  Intuitively, the more uncertainty in the
    # calculated landmark position and the more difference in the
    # calculated landmark mean from past means, the less likely it is
    # that this particle tracks the real position of the robot. These
    # factors contribute to a low importance factor, and thus a higher
    # chance of being thrown out during resampling. The equation used
    # is:
    #
    #  w = det(2*pi*Uu)**(-0.5) * exp(-1/2 transpose(obs - old) *
    #      inverse(Uu) * (obs - old)
    #
    # where w is the weight, Uu is the updated uncertainty (which
    # factors in the new measurement uncertainty but not the Kalman
    # update), obs is the currently observed position, and old is the
    # old estimated position (obs and old are relative positions in
    # radial coordinates).  For the curious, (obs - old) is normally a
    # column vector.
    partOfExponent = multVector(inverse(updatedUncertainty), landmarkCorrection)
    importanceFactor = determinant(
                         multScalar(
                           updatedUncertainty,
                           2*math.pi))**-0.5 *\
                       math.exp(-0.5 *\
                                (landmarkCorrection[0] * partOfExponent[0] +\
                                 landmarkCorrection[1] * partOfExponent[1]))

    # Finally, we update the Particle based on the calculated values:
    landmark.x = newLandmarkPosition[0]
    landmark.y = newLandmarkPosition[1]
    landmark.covar = newUncertainty
    particle.importance = importanceFactor

  # By this point, whichever branch of the if/else we've taken, the
  # particle has been modified to reflect the update and assigned its
  # proper weight. This function is therefore done.

def resampleParticles(particles):
  '''
  This method takes a list or tuple of particles and returns a new tuple
  of particles drawn from the original particles. This new collection is
  the same size as the collection passed in, but has been re-sampled
  according to the particles' relative importance variables. The
  particles must each have an importance value, which must be a number.
  '''
  N = len(particles)
  max = sum(p.importance for p in particles)
  newparticles = []

  # Loop through the number of required particles, adding a particle to
  # newparticles each time:
  for i in range(N):
    # Choose a random number between 0 and the sum of the importance
    # factors, we'll line up the particles in order, giving each a
    # stretch of numbers equal to its importance factor, and then count
    # up to the chosen number, and see which particle we're on.
    choice = random.uniform(0, max)

    # Which particle we're looking at:
    j = 0
    particle = particles[j]

    # If choice > particle.importance, we know that the chosen particle
    # is after this particle:
    while choice > particle.importance:
      # The choice is always indexed from the end of the current
      # particle:
      choice -= particle.importance
      j += 1
      particle = particles[j]

    # Since we're drawing with replacement (i.e. the same particle could
    # get selected multiple times), we need to make deep copies of the
    # particles to add to the new list of particles:
    newparticles.append(copy.deepcopy(particle))

  return tuple(newparticles)
