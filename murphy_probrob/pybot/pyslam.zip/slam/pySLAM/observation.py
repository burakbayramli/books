'''
observation.py
Written 2008-6-11 by Peter Mawhorter
This module defines the Observation class, which holds all of the
information and functions necessary to define a 2-dimensional
observation completely for the purposes of FastSLAM. Thus, an
observation tracks not only the actual measurement (in abstract
coordinates) but also how the measurement was taken, via a Sensor
object, which allows conversion from abstract observation coordinates to
Cartesian coordinates, as well as conversion of variance (which is also
stored in the Sensor object.

WARNING: The observation class represents arbitrary 2-dimensional data.
If you are working with two-dimensional data that wraps, such as the
angle in a radial coordinate system, it is YOUR responsibility to ensure
that values put into observations are consistent.
'''

import sys

import math

import functions

# The list of things to print for debugging:
#DEBUG = ['measurement', 'forecast', 'correction']
DEBUG = []
DEBUG_ALL = ['xyo', 'corrector', 'correction', 'old', 'gain', 'updated',
             'new', 'measurement', 'pose', 'forecast', 'jacobian',
             'association', 'assoc_probs']
DEBUG_STREAM = sys.stderr

# The 2x2 identity matrix:
Identity = ((1, 0),
            (0, 1))

class Observation(object):
  '''
  An observation is a 2-dimensional observation of an object's location
  relative to an observer. Thus, it holds two abstract measurements of
  relative position, called a and b. It also holds a Sensor object: the
  instrument used to take the measurement. The Sensor object knows how
  to convert from the abstract coordinates a and b into Cartesian
  coordinates, and knows how to compute the covariance in Cartesian
  space for any given measurement.
  '''
  def __init__(self, (a, b), sensor):
    '''
    This constructor takes a 2-tuple of abstract measurement
    coordinates (called a and b) and a Sensor object.
    '''
    self.a = a
    self.b = b
    self.sensor = sensor

  def __str__(self):
    return "an observation of (" + str(self.a) + ", " + str(self.b) +\
           ") using " + str(self.sensor)

  def __repr__(self):
    return "Observation((" + repr(self.a) + ", " + repr(self.b) + "), " +\
                             repr(self.sensor) + ")"

  def CartesianPosition(self, basePose):
    '''
    This function calculates the position of the observed object in
    Cartesian space, given a pose triple (x, y, theta) representing the
    position at which the observation was made. This function returns a
    tuple of (x, y) coordinates.
    '''
    return self.sensor.CartesianPosition((self.a, self.b), basePose)

  def CartesianCovariance(self, basePose):
    '''
    This method returns a 2x2 matrix as a 2-tuple of 2-tuples that
    represents the covariance of the observation in Cartesian
    coordinates. It takes a base position that enables it to calculate
    the covariance (the base position should be a 3-tuple of x, y, and
    theta positions).
    '''
    return self.sensor.CartesianCovariance((self.a, self.b), basePose)

  def getLandmarkName(self, candidates, pose, threshold):
    '''
    This function returns the name of the landmark most likely to be the
    landmark that was observed by this observation from among the
    candidates given (a list of Landmark objects), assuming that the
    robot has the given pose (a 3-tuple of x, y, and theta values). If
    no landmark is at least threshold likely to be the correct one, then
    None is returned.
    '''
    # The best association found so far and how good it was:
    best = (None, threshold)
    for c in candidates:
      # These calculations are all duplicated below in updateLandmark:
      # they are the same as the calculation of the importance value of
      # the particle, except that they use c as the landmark observed.
      oldPosition = (candidates[c].x, candidates[c].y)
      oldUncertainty = candidates[c].covar

      forecast = Observation(self.sensor.computeObservation(oldPosition, pose),
                             self.sensor)

      landmarkCorrection = self.sensor.findCorrection((self.a, self.b),
                                                      (forecast.a, forecast.b))

      Jacobian = self.sensor.Jacobian((forecast.a, forecast.b), pose)

      updatedUncertainty = functions.add(
                             functions.ABAtranspose(
                               Jacobian,
                               oldUncertainty), 
                             self.sensor.covar)

      partOfExponent = functions.multVector(
                         functions.inverse(updatedUncertainty),
                         landmarkCorrection)

      probability = functions.determinant(
                      functions.multScalar(
                        updatedUncertainty,
                        2*math.pi))**-0.5 *\
                    math.exp(-0.5 *\
                             (landmarkCorrection[0] * partOfExponent[0] +\
                              landmarkCorrection[1] * partOfExponent[1]))
      # This code when executed throughout the loop selects the landmark
      # with the highest probability greater than threshold:
      if probability > best[1]:
        best = (c, probability)
        if "association" in DEBUG:
          DEBUG_STREAM.write("Associated to %s with probability %.9f\n" %
                             (c, probability))
      if "assoc_probs" in DEBUG:
        DEBUG_STREAM.write("Association probability for %s: %.9f\n" %
                           (c, probability))
    if "association" in DEBUG and best[1] == threshold:
      DEBUG_STREAM.write("New landmark!\n")

    return best[0]

  def updateLandmark(self, landmark, pose):
    '''
    This method updates the given components.Landmark object in place,
    changing its mean and covariance to account for the data contained
    in this Observation, using the Kalman filter. It takes the landmark to
    update along with a pose (x, y, theta) that represents where this
    observation of the given landmark was made. This function returns
    the probability of generating this observation, given the previous
    landmark properties.
    '''
    if 'measurement' in DEBUG:
      DEBUG_STREAM.write("measurement %.3f %.3f" % (self.a, self.b) + '\n')
    if 'pose' in DEBUG:
      DEBUG_STREAM.write("pose %.3f %.3f %.3f" % (pose[0], pose[1], pose[2]) +\
                         '\n')
    # Retrieve what we know about this landmark (the old data):
    oldPosition = (landmark.x, landmark.y)
    oldUncertainty = landmark.covar
    if 'old' in DEBUG:
      DEBUG_STREAM.write("oldP %.3f %.3f" % oldPosition + '\n')
      DEBUG_STREAM.write("oldU" + '\n')
      DEBUG_STREAM.write(" [%.3f %.3f]" % oldUncertainty[0] + '\n')
      DEBUG_STREAM.write(" [%.3f %.3f]" % oldUncertainty[1] + '\n')

    # The forecast is the predicted sensor input from the sensor that
    # made this Observation. It doesn't matter what kinds of sensors
    # took the data that resulted in the estimate up to now; we want to
    # compare the old data to data from the current sensor, so we
    # project what it would have observed:
    forecast = Observation(self.sensor.computeObservation(oldPosition, pose),
                           self.sensor)

    if 'forecast' in DEBUG:
      DEBUG_STREAM.write("forecast %.3f %.3f" % (forecast.a, forecast.b) + '\n')

    # The difference between the estimate of the landmark position based
    # on the known robot location and the current sensor data, and the
    # estimate of the landmark location based on the known robot
    # location and the previous estimate of the landmark's global
    # location.
    landmarkCorrection = self.sensor.findCorrection((self.a, self.b),
                                                    (forecast.a, forecast.b))
    if 'correction' in DEBUG:
      DEBUG_STREAM.write("correction %.3f %.3f" % (landmarkCorrection[0],
                                                   landmarkCorrection[1])+'\n')

    # The Jacobian is a matrix of partial derivatives of the abstract
    # coordinates a and b with respect to x and y. It is different at
    # different x any y locations, so we calculate it here for the
    # location of the landmark relative to the given pose. It serves as
    # a transform between Cartesian and observation uncertainties in the
    # position of the landmark. This Jacobian is based only on our prior
    # knowledge about the landmark, and not on the current observation.
    Jacobian = self.sensor.Jacobian((forecast.a, forecast.b), pose)

    if 'jacobian' in DEBUG:
      DEBUG_STREAM.write("Jacobian" + '\n')
      DEBUG_STREAM.write(" [%.3f %.3f]" % Jacobian[0] + '\n')
      DEBUG_STREAM.write(" [%.3f %.3f]" % Jacobian[1] + '\n')

    # This step updates the old uncertainty for this landmark,
    # converting it to radial coordinates using the ABAtranspose pattern
    # with the Jacobian, and then adding the (known/estimated) sensor
    # covariance. The result is an updated uncertainty for the position
    # of the landmark, expressed in sensor coordinates. The updated
    # value hasn't yet taken into account the Kalman filtering step,
    # which allows the robot to adjust its beliefs according to the
    # difference between the newly measured landmark position and
    # previous measurements thereof. The newUncertainty variable,
    # calculated later, reflects the filtering step.
    updatedUncertainty = functions.add(
                           functions.ABAtranspose(
                             Jacobian,
                             oldUncertainty), 
                           self.sensor.covar)

    if 'updated' in DEBUG:
      DEBUG_STREAM.write("updU" + '\n')
      DEBUG_STREAM.write(" [%.3f %.3f]" % updatedUncertainty[0] + '\n')
      DEBUG_STREAM.write(" [%.3f %.3f]" % updatedUncertainty[1] + '\n')
 
    # The Kalman gain is just the old uncertainty, converted into sensor
    # coordinates by multiplying it on the right by the transpose of the
    # Jacobian, multiplied with the inverse of the updated uncertainty.
    # Since the updated uncertainty is close to the old uncertainty, its
    # inverse is similar to the old uncertainty, so the Kalman gain
    # captures the magnitude of the difference between the old and new
    # uncertainties. It is used in the subsequent step to weight the
    # combination of the old mean and the estimated new mean (taken just
    # from this measurement). Intuitively (and ignoring the fact that
    # we're dealing with covariance matrices instead of scalars), the
    # Kalman gain will be large when the numerator is larger than the
    # denominator, or when the old uncertainty is larger than the new
    # uncertainty. This makes sense: when past measurements don't give
    # us much information about an object's location (perhaps they were
    # taken from far away, making a small angular error into a large
    # position error) the new measurement, being more certain, should
    # be weighted more heavily when averaging it with the old one.
    # Conversely, when we're pretty certain of the object's position
    # based on previous measurements (maybe we've observed it quite
    # accurately or quite a lot), and the most recent measurement isn't
    # that accurate, we want to assign a low weight to the new mean when
    # averaging it with the old one to get the updated estimated mean.
    # If it were a scalar, the Kalman gain would be proportional to the
    # amount of old uncertainty and inversely proporional to the amount
    # of uncertainty in the most recent measurement. It is in fact a
    # matrix, but similar relationships hold. The extra factor of the
    # transposed Jacobian in the Kalman gain just fixes the "units" of
    # the factor. Because the old uncertainty is in Cartesian
    # coordinates, it must be transformed into sensor coordinates (by
    # the Jacobian) before being compared with the new uncertainty
    # (which is also expressed in sensor coordinates).
    KalmanGain = functions.multiply(
                   functions.multiply(
                     oldUncertainty,
                     functions.transpose(Jacobian)),
                   functions.inverse(updatedUncertainty))

    if 'gain' in DEBUG:
      DEBUG_STREAM.write("Kalman Gain" + '\n')
      DEBUG_STREAM.write(" [%.3f %.3f]" % KalmanGain[0] + '\n')
      DEBUG_STREAM.write(" [%.3f %.3f]" % KalmanGain[1] + '\n')

    # Update the mean:
    # This step updates the estimated global Cartesian position of the
    # landmark. To do this, it takes the old position, and adds the
    # vector that separates the old position from the position estimated
    # by the current measurement, weighted by the Kalman gain (see
    # above). The result is a revised estimate of the true position of
    # the landmark that fully incorporates the information from the
    # current observation. The equation used is:
    #
    #  mn = mo + K*(obs - old)
    #
    # Where mn is the new mean, mo is the old mean, K is the Kalman
    # gain, obs is the newly observed landmark position, and old is the
    # old landmark position, both in sensor coordinates relative to the
    # given pose. (Actually, the obs-old step is carried out above when
    # landmarkCorrection is calculated). The multiplication by K both
    # weights the correction vector and converts it from sensor to
    # Cartesian space.
    correctionVector = functions.multVector(KalmanGain, landmarkCorrection)
    if 'corrector' in DEBUG:
      DEBUG_STREAM.write("corrector %.3f %.3f" % correctionVector + '\n')
 
    newLandmarkPosition = (oldPosition[0] + correctionVector[0],
                           oldPosition[1] + correctionVector[1])
 
    # Update the covariance:
    # This step adjusts the landmark uncertainty based on the calculated
    # Kalman gain. The formula for the adjustment is:
    #
    #   Un = (I - K*J)*Uo
    #
    # Where Un is the new uncertainty, I is the identity matrix, K is
    # the Kalman gain, J is the Jacobian, and Uo is the old uncertainty.
    newUncertainty = functions.multiply(
                       functions.add(
                         Identity,
                         functions.multScalar(
                           functions.multiply(
                             KalmanGain,
                             Jacobian),
                           -1)),
                       oldUncertainty)

    if 'new' in DEBUG:
      DEBUG_STREAM.write("newU" + '\n')
      DEBUG_STREAM.write(" [%.3f %.3f]" % newUncertainty[0] + '\n')
      DEBUG_STREAM.write(" [%.3f %.3f]" % newUncertainty[1] + '\n')
 
    # Here we update the landmark given based on the calculated values:
    landmark.x = newLandmarkPosition[0]
    landmark.y = newLandmarkPosition[1]
    landmark.covar = newUncertainty

    # Calculate the importance factor:
    # This step computes the probability that the latest measurement was
    # taken given the preconditions. This probability is returned to
    # provide feedback from the Kalman filtering that determines
    # landmark uncertainties to the particle resampling that handles
    # position uncertainties. Intuitively, the more uncertainty in the
    # calculated landmark position and the more difference in the
    # calculated landmark mean from past means, the less likely it is
    # that this particle tracks the real position of the robot. These
    # factors contribute to a low importance factor, and thus a higher
    # chance of being thrown out during resampling. The equation used
    # is:
    #
    #  w = det(2*pi*Uu)**(-0.5) * exp(-1/2 transpose(obs - old) *
    #      inverse(Uu) * (obs - old)
    #
    # where w is the weight, Uu is the updated uncertainty (which
    # factors in the new measurement uncertainty but not the Kalman
    # update), obs is the currently observed position, and old is the
    # old estimated position (obs and old are relative positions in
    # radial coordinates).  For the curious, (obs - old) is normally a
    # column vector.
    partOfExponent = functions.multVector(
                       functions.inverse(updatedUncertainty),
                       landmarkCorrection)
    probability = functions.determinant(
                    functions.multScalar(
                      updatedUncertainty,
                      2*math.pi))**-0.5 *\
                  math.exp(-0.5 *\
                           (landmarkCorrection[0] * partOfExponent[0] +\
                            landmarkCorrection[1] * partOfExponent[1]))

    # Return the computed probability.
    return probability
 

class Sensor(object):
  '''
  Sensor objects define a transformation between abstract coordinates
  and Cartesian coordinates. They also define the variance of the
  sensor, based on that transformation. This class is an abstract class,
  defined just to demonstrate the proper interface.
  '''
  def __init__(self):
    raise NotImplementedError("Can't instantiate the abstract Sensor class.")

  def CartesianPosition(self, (a, b), pose):
    '''
    This method takes a sensor reading (a 2-tuple of coordinates in
    abstract sensor space) and a pose from which that reading was taken
    (a 3-tuple of x, y, and theta values) and returns a 2-tuple of x, y
    coordinates indicating the position of the observed object.
    '''
    pass

  def CartesianCovariance(self, (a, b), pose):
    '''
    This method takes a sensor reading (a 2-tuple of coordinates in
    abstract sensor space) and a pose from which that reading was taken
    (a 3-tuple of x, y, and theta values) and returns a 2x2 matrix as a
    2-tuple of 2-tuples in row-major order that specifies the x and y
    covariance of the location of the observed object.
    '''
    pass

  def Jacobian(self, (a, b), (x, y, thr)):
    '''
    This function computes the Jacobian of the transform between
    Cartesian coordinates and sensor coordinates. The Jacobian is a
    matrix of partial derivatives of a and b (abstract sensor
    coordinates) with respect to x and y. It is different at different x
    any y locations, so it must be calculated for a specific x, y
    offset, here given by the pose (x, y, thr) and the sensor data (a,
    b).
    '''
    pass

  def computeObservation(self, (x, y), pose):
    '''
    This method takes a pair of Cartesian coordinates and a 3-tuple
    indicating a pose from which an object at the given coordinates has
    been observed (this 3-tuple includes x, y, and theta information).
    This method returns the measurement-space values a and b that
    indicate the true reading for this type of sensor if the position
    (x, y) was observed from the pose given.
    '''
    pass

  def findCorrection(self, (a, b), (c, d)):
    '''
    This function takes two coordinate specifications in sensor
    coordinates and calculates the sensor-space correction vector
    between the two. Different coordinate spaces must implement this
    differently. The value returned should be a vector from (c, d) to
    (a, b) in whatever coordinate space the sensor uses.
    '''
    pass

class RangeBearingSensor(Sensor):
  '''
  This type of sensor senses the relative range and bearing of an object
  in radial coordinates relative to the observation position. See the
  Sensor base class for method details.
  '''
  def __init__(self, covariance):
    '''
    This constructor takes the covariance of the sensor in radial
    coordinates as a 2x2 matrix passed as a 2-tuple of 2-tuples in
    row-major order.
    '''
    self.covar = covariance

  def __str__(self):
    return "a range/bearing sensor with covariance " + str(self.covar)

  def __repr__(self):
    return "RangeBearingSensor(" + repr(self.covar) + ")"

  def CartesianPosition(self, (r, theta), (basex, basey, basethr)):
    '''
    This method converts to Cartesian coordinates. It takes radius and
    theta values as a 2-tuple along with a base pose (in Cartesian
    space plus an angle) as a 3-tuple. It first computes the offset
    based on the angle of observation (the third member of the pose
    tuple) and the angle observed, as well as the observed range. Then
    it adds this offset to the pose at which the observation was taken
    to compute the Cartesian location of the observed feature.
    '''
    # Filter input angle:
    while theta < 0:
      theta += 2*math.pi
    while theta > 2*math.pi:
      theta -= 2*math.pi

    return basex + r*math.cos(theta + basethr),\
           basey + r*math.sin(theta + basethr)

  def CartesianCovariance(self, (r, theta), (basex, basey, basethr)):
    '''
    This method takes a pair of measurement-space coordinates (r and
    theta) and a pose from which they were measured and calculates the x
    and y covariance of the measured position. It does this by
    calculating the Jacobian of the transform from Cartesian to radial
    coordinates and then multiplying the stored covariance matrix by the
    inverse Jacobian on one side and it's transposed inverse on the
    other. Read the method comments for a more specific description of
    what is going on; note that the basex and basey are irrelevant:
    observation position variance for this Sensor depends only on
    relative position, not on absolute position.
    '''
    # Filter input angle:
    while theta < 0:
      theta += 2*math.pi
    while theta > 2*math.pi:
      theta -= 2*math.pi

    # The Jacobian is used to transform uncertainty from sensor (in this
    # case radial) coordinates to Cartesian coordinates.
    Jacobian = self.Jacobian((r, theta), (basex, basey, basethr))
 
    # The xyUncertainty is a matrix that specifies uncertainty in x and y
    # for the observation. It describes the uncertainty in the position
    # of the observation based on the uncertainty in the range and
    # bearing to the observation. The conversion from range and bearing
    # uncertainty to global position uncertainty is done using the
    # inverse Jacobian of the Cartesian-to-radial conversion function,
    # calculated at the observation's offset from the base position.
    # Here the ABAtranspose function computes Ji*sqrt(SC) *
    # sqrt(SC)*Ji.transpose where Ji is the inverse Jacobian, and SC is
    # the (known or estimated) uncertainty in range and bearing
    # measurements, the sensor covariance. As a convariance, it
    # describes squared uncertainty, so Ji and Ji transpose are used to
    # covert each square root to Cartesian coordinates. since
    # sqrt(SC)*Ji.transpose results in the transpose of Ji*sqrt(SC), the
    # overall operation is just multiplying a matrix (the uncertainties
    # in Cartesian coordinates) by its transpose, which is equivalent to
    # the squaring operation that converts standard deviation sigma to
    # sigma squared. Thus, the result is analagous to a sigma squared
    # value for a 1-dimensional Gaussian distribution, using sensor
    # variance values transformed from range and bearing space into
    # Cartesian space.
    return functions.ABAtranspose(functions.inverse(Jacobian), self.covar)

  def Jacobian(self, (r, theta), (x, y, thr)):
    '''
    This function computes the Jacobian of the transform between
    Cartesian coordinates and sensor coordinates. This Jacobian is a
    matrix of partial derivatives of range and bearing with respect to x
    and y. It is different at different x any y locations, so we
    calculate it here for the location of the observed item (given
    relative to the location of observation in radial coordinates as the
    argument (r, theta)) relative to the location of observation (given
    absolutely here as the argument (x, y, thr)). The Jacobian serves as
    a transform between Cartesian and radial uncertainties in the
    position of the landmark. See the bearingRangeJacobian function in
    the functions module for a more complete description of the
    Jacobian.
    '''
    # Filter input angle:
    while theta < 0:
      theta += 2*math.pi
    while theta > 2*math.pi:
      theta -= 2*math.pi

    # First, we must calculate the x- and y-offset distances in
    # Cartesian coordinates:
    xyoffset = (r*math.cos(theta + thr), r*math.sin(theta + thr))
    if 'xyo' in DEBUG:
      DEBUG_STREAM.write("XYOffest " + str(xyoffset) + '\n')

    # We call the bearingRangeJacobian function to calculate the
    # Jacobian:
    return functions.bearingRangeJacobian(*xyoffset)

  def computeObservation(self, (x, y), (basex, basey, basethr)):
    '''
    This function computes the r and theta values of observation for an
    observation of an object at (x, y) from the coordinates basex, basey
    and facing basethr (in radians). It just performs the transform from
    Cartesian to radial coordinates.
    '''
    obs = list(functions.rTheta(x - basex, y - basey))
    obs[1] -= basethr

    # Constrain the predicted observation value:
    while obs[1] < 0:
      obs[1] += 2*math.pi
    while obs[1] > 2*math.pi:
      obs[1] -= 2*math.pi
    return tuple(obs)

  def findCorrection(self, (a, b), (c, d)):
    '''
    This function takes two coordinate specifications in sensor
    coordinates and calculates the sensor-space correction vector
    between the two. Simple substraction does not suffice here, because
    the correction between angles on either side of 0 is small, but one
    of them has a value close to 2*PI and the other has a value close to
    0. This method computes the smaller of the two correction angles.
    '''
    # First, filter both input bearings so that they're between 0 and
    # 2*PI:
    while b < 0:
      b += 2*math.pi
    while b > 2*math.pi:
      b -= 2*math.pi
    while d < 0:
      d += 2*math.pi
    while d > 2*math.pi:
      d -= 2*math.pi

    # First, we compute the simple distance between the two range
    # measurements:
    dist = a - c

    # Next we need figure out which angle difference is smaller:
    # clockwise or counterclockwise. To do this, we compute the normal
    # counterclockwise angle, and test whether it is less than or equal
    # to PI.
    angle = b - d

    if abs(angle) <= math.pi:
      # The angle is simple, just return it:
      return (dist, angle)
    elif angle > 0:
      # The angle's complement is positive and the angle crosses 0:
      # complement it.
      return (dist, angle - 2*math.pi)
    else:
      # The angle's complement is negative and the angle crosses 0:
      # complement it and invert.
      return (dist, angle + 2*math.pi)
