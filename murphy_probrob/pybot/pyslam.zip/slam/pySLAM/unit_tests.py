#!/usr/bin/env python
'''
unit_tests.py
Written 2008-6-13 by Peter Mawhorter
This module provides some unit tests for the FastSLAM modules. Coverage
is quite spotty, so feel free to add tests if there's one missing that
you'd like.
'''

import math

import functions

# This constant indicates a radius of convergence for floating point
# values:
moreOrLessTheSame = 0.0000000000001


def testArcXYTheta():
  '''
  This function tests the arcXYTheta function from the functions module.
  It's fairly thorough.
  '''
  # How many tests failed:
  failed = 0
  # Axle length.
  axle = 100
  # Odometries to be tested:
  odometries = {
    (0, 0): (0, 0, 0),
    (axle * math.pi/2., 0): (axle/2., axle/2., math.pi/2.),
    (-axle * math.pi/2., 0): (-axle/2., axle/2., -math.pi/2.),
    (0, axle * math.pi/2.): (axle/2., -axle/2., -math.pi/2.),
    (0, -axle * math.pi/2.): (-axle/2., -axle/2., math.pi/2.),
    (axle * math.pi/2., -axle * math.pi/2.): (0, 0, math.pi),
    (-axle * math.pi/2., axle * math.pi/2.): (0, 0, -math.pi),
    (axle * math.pi, -axle * math.pi): (0, 0, 2*math.pi),
    (axle * math.pi/4., -3 * axle * math.pi/4.): (0, -axle / 2., math.pi),
    (3 * axle * math.pi/4., -axle * math.pi/4.): (0, axle / 2., math.pi),
    (-axle * math.pi/4., 3 * axle * math.pi/4.): (0, -axle / 2., -math.pi),
    (-3 * axle * math.pi/4., axle * math.pi/4.): (0, axle / 2., -math.pi),
    (axle*2, axle*2): (axle*2, 0, 0),
    (axle/2. * math.pi, axle * math.pi): (1.5*axle, -1.5*axle, -math.pi/2.),
    (axle * math.pi, axle/2. * math.pi): (1.5*axle, 1.5*axle, math.pi/2.),
    (-axle/2. * math.pi, -axle * math.pi): (-1.5*axle, -1.5*axle, math.pi/2.),
    (-axle * math.pi, -axle/2. * math.pi): (-1.5*axle, 1.5*axle, -math.pi/2.)
  }

  for (odor, odol) in odometries:
    result = functions.arcXYTheta(odor, odol, axle)
    expected = odometries[(odor, odol)]
    thisfailed = False
    for i in range(len(result)):
      if abs(result[i] - expected[i]) > moreOrLessTheSame:
        failed += 1
        thisfailed = True
        break
    print "(%6.4f, %6.4f, %3d)" % (odor, odol, axle), "<- input"
    print "(%9.4f, %9.4f, %9.4f)" % expected, "<- expected"
    print "(%9.4f, %9.4f, %9.4f)" % result, "<- ouput"
    if thisfailed:
      print "---FAILED---"
    else:
      print "---Passed---"
    print
  print
  print failed, "tests failed."

def testRangeBearingJacobian():
  '''
  This function tests the bearingRangeJacobian function from the
  functions module.
  '''
  positions = {
    ( 1,  0): ((1,0),(0,1)),
    ( 1,  1): ((0.5*2**0.5,0.5*2**0.5),(-0.5,0.5)),
    ( 0,  1): ((0,1),(-1,0)),
    (-1,  1): ((-0.5*2**0.5,0.5*2**0.5),(-0.5,-0.5)),
    (-1,  0): ((-1,0),(0,-1)),
    (-1, -1): ((-0.5*2**0.5,-0.5*2**0.5),(0.5,-0.5)),
    ( 0, -1): ((0,-1),(1,0)),
    ( 1, -1): ((0.5*2**0.5,-0.5*2**0.5),(0.5,0.5)),
    ( 3,  0)        : ((1,0),(0,1/3.)),
    ( 3**0.5,  1)   : ((0.5*3**0.5,0.5),(-0.25,0.25*3**0.5)),
    ( 1,  3**0.5)   : ((0.5,0.5*3**0.5),(-0.25*3**0.5,0.25)),
    ( 0,  3)        : ((0,1),(-1/3.,0)),
    (-1,  3**0.5)   : ((-0.5,0.5*3**0.5),(-0.25*3**0.5,-0.25)),
    (-(3**0.5),  1) : ((-0.5*3**0.5,0.5),(-0.25,-0.25*3**0.5)),
    (-3,  0)        : ((-1,0),(0,-1/3.)),
    (-(3**0.5), -1) : ((-0.5*3**0.5,-0.5),(0.25,-0.25*3**0.5)),
    (-1, -(3**0.5)) : ((-0.5,-0.5*3**0.5),(0.25*3**0.5,-0.25)),
    ( 0, -3)        : ((0,-1),(1/3.,0)),
    ( 1, -(3**0.5)) : ((0.5,-0.5*3**0.5),(0.25*3**0.5,0.25)),
    ( 3**0.5, -1)   : ((0.5*3**0.5,-0.5),(0.25,0.25*3**0.5))
  }

  failed = 0
  try:
    print "Testing (0, 0)..."
    test = functions.bearingRangeJacobian(0, 0)
    print "---FAILED---"
    failed += 1
  except ValueError:
    print "---Passed---"
  print
  for (x, y) in positions:
    print "Testing (%d, %d)..." % (x, y)
    result = functions.bearingRangeJacobian(x, y)
    if any(
         any(
           abs(result[i][j] - positions[(x, y)][i][j]) > moreOrLessTheSame
           for j in range(2))
         for i in range(2)):
      failed += 1
      print "---FAILED---"
    else:
      print "---Passed---"
    print
  print
  print failed, "tests failed."

if __name__ == "__main__":
  testArcXYTheta()
  print
  print '*'*80
  print
  testRangeBearingJacobian()
