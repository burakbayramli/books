# vim: set fileencoding=utf-8
'''
motion.py
Written 2008-6-12 by Peter Mawhorter
This module defines the Motion interface, which is used to model motion
with noise. Specific Motion subclasses should be developed for specific
robots that model different modes of motion. Each Motion subclass
instance contains some notion of a particular motion or series of
motions that has occurred, and can be sampled based on a given initial
position to get a new position estimation created taking noise into
account.
'''

import copy, math, random

import components, functions

class Motion(object):
  '''
  Motion objects record a particular motion: a movement between two
  poses, each specified by components.Pose object. Each subclass also
  has its own built-in motion model, which allows sampling any
  particular Motion instance noisily.
  '''
  def __init__(self, end = None):
    '''
    This constructor takes a components.Pose object, end, and sets up
    this Motion object to represent a motion from the pose (0, 0, 0) to
    the pose end. If the endpoint is not given or is given as None, the
    object represents the null motion.
    '''
    self.endpoint = end

  def __str__(self):
    return "a motion from (0, 0, 0) to " + str(self.endpoint)

  def __repr__(self):
    return "Motion(" + repr(self.endpoint) + ")"

  def sample(self, initialPose):
    '''
    This method returns a pose (a components.Pose object) that has been
    sampled from the given motion model. The pose represents a possible
    pose after moving from initialPose on a path that would take one
    from the pose (0, 0, 0) to the endpoint of this Motion object. The
    Pose returned is selected using the motion model of this object,
    which is a perfect motion model (no error). Thus, for this Motion
    class, the pose returned by this method will always be the same, and
    will just be the offset from (0, 0, 0) to the endpoint of this
    Motion applied to the pose given. If this motion is the null motion,
    this method returns a deep copy of the initial position.
    '''
    return self.apply(initialPose)

  def apply(self, initialPose):
    '''
    This method returns the pose that results from simply applying the
    transformation from (0, 0, 0) to self.endpoint to the pose
    initialPose. It does not incorporate any sort of motion model, and
    for the same input, always returns the same result. If this is the
    null motion, it returns a deep copy of the initial pose.
    '''
    iP = initialPose
    ep = self.endpoint
    if ep != None:
      return components.Pose(x = iP.x + ep.x*math.cos(iP.thr) +\
                                        ep.y*math.cos(iP.thr + math.pi/2.),
                             y = iP.y + ep.x*math.sin(iP.thr) +\
                                        ep.y*math.sin(iP.thr + math.pi/2.),
                             thr = iP.thr + ep.thr)
    else:
      return copy.deepcopy(initialPose)

class Tesseract(Motion):
  '''
  This type of Motion object describes motion via tesseract: the folding
  of time and space to make your destination be colocated with your
  point of departure. While travel by tesseract is quite convenient, it gives rise to identical Gaussian distributions over position in both
  the x and y coordinates upon arrival. TesseractMotion objects store
  this variance and allow sampling of arrival positions. Travel via
  tesseract also rotates the traveller relative to their initial heading
  according to a Gaussian distribution, that rotation is also recorded
  by this object.
  '''
  def __init__(self, positionVariance, headingVariance, endpos):
    '''
    This constructor takes the variance for position and the variance
    for heading (each being a variance, and thus representing σ
    squared), along with an ending position (a Pose object). The
    position variance argument should be a tuple of x, y variances.
    '''
    self.posvar = positionVariance
    self.headvar = headingVariance
    self.endpos = endpos

  def __str__(self):
    return "a tesseract to " + str(self.endpos)

  def __repr__(self):
    return "Tesseract(" + repr(self.posvar) + ", " +\
                          repr(self.headvar) + ", " +\
                          repr(self.endpoint) + ")"

  def sample(self, initialPose):
    '''
    This method returns a pose (a components.Pose object) that has been
    sampled from the Tesseract. Regardless of the initial pose, the
    returned pose is always this tesseract's end pose with appropriate
    Gaussian noise.
    '''
    return components.Pose(x = self.endpos.x +\
                               random.gauss(0,self.posvar[0]**0.5),
                           y = self.endpos.y +\
                               random.gauss(0,self.posvar[1]**0.5),
                           thr = self.endpos.thr +\
                                 random.gauss(0,self.headvar**0.5))

  def apply(self, initialPose):
    '''
    This method returns the pose that results from simply applying the
    tesseract exactly.
    '''
    return components.Pose(x = endpos.x,
                           y = endpos.y,
                           thr = endpos.thr)

class DifferentialDriveMotion(Motion):
  '''
  This class represents motions that occur along circular arcs (or in
  the degenerate case, straight lines). It takes right and left wheel
  odometries along with variance and bias for each wheel, and assumes
  Gaussian noise with the given variance and bias in the wheel odometry.
  Given that assumption, it can sample poses based on an initial
  position. This class assumes that the motion achieved while the given
  odometry was being recorded was a single arc with each wheel moving at
  constant velocity. If this assumption isn't true, it may produce
  wildly incorrect results.
  '''
  def __init__(self,
               axle,
               (odoright, odoleft),
               (varright, varleft),
               (biasright, biasleft)):
    '''
    This constructor takes an axle length and three pairs of numbers.
    The first represents right and left wheel odometries. The next
    records variance (σ squared) for each wheel, and the last records
    bias for each wheel.
    '''
    self.axle = axle
    self.odoright = odoright
    self.odoleft = odoleft
    self.varright = varright
    self.varleft = varleft
    self.biasright = biasleft
    self.biasleft = biasleft
    self.x, self.y, self.angle = functions.arcXYTheta(self.odoright,
                                                      self.odoleft,
                                                      self.axle)

  def __str__(self):
    return "a differential drive motion with distance " + str(self.dist) +\
           " angle " + str(self.angle) + " and axle length " + str(self.axle)

  def __repr__(self):
    return "DifferentialDriveMotion(" + repr(self.axle) + ", " +\
                                   "(" + repr(self.odoright) + ", " +\
                                         repr(self.odoleft) + "), " +\
                                   "(" + repr(self.varright) + ", " +\
                                         repr(self.varleft) + "), " +\
                                   "(" + repr(self.biasright) + ", " +\
                                         repr(self.biasleft) + "))"

  def sample(self, initialPose):
    '''
    This method generates a Pose object based on an initial pose
    (another Pose object) and a random sample drawn from the Motion
    accounting for noise in the motion model. For this kind of Motion,
    this means that left and right odometries are sampled according to
    Gaussian distributions with the given means and variances, and then
    an offset is calculated based on the sampled odometries. The offset
    is then applied to the initial pose to calculate the resulting pose,
    which is returned.
    '''
    iP = initialPose
    odoright = random.gauss(self.odoright + self.biasright, self.varright**0.5)
    odoleft = random.gauss(self.odoleft + self.biasleft, self.varleft**0.5)
    x, y, theta = functions.arcXYTheta(odoright, odoleft, self.axle)
    return components.Pose(x = iP.x + x*math.cos(iP.thr) +\
                                      y*math.cos(iP.thr + math.pi/2.),
                           y = iP.y + x*math.sin(iP.thr) +\
                                      y*math.sin(iP.thr + math.pi/2.),
                           thr = iP.thr + theta)

  def apply(self, initialPose):
    '''
    This method applies the Motion to an initial pose (a Pose object)
    and returns a new Pose object that represents the pose after going
    through this motion. This method does not account for noise, and
    produces exact results.
    '''
    iP = initialPose
    return components.Pose(x = iP.x + self.x*math.cos(iP.thr) +\
                                      self.y*math.cos(iP.thr + math.pi/2.),
                           y = iP.y + self.x*math.sin(iP.thr) +\
                                      self.y*math.sin(iP.thr + math.pi/2.),
                           thr = iP.thr + self.angle)

class CompositeMotion(Motion):
  '''
  This class represents a motion that consists of many other motions.
  When this Motion object is sampled, it samples each component motion
  and aggregates the results.
  '''
  def __init__(self, motions=()):
    '''
    This constructor takes a list or tuple of Motion objects (which may
    themselves be CompositeMotion objects). If none is given, the
    default of an empty tuple is used.
    '''
    self.motions = list(motions)

  def __str__(self):
    return "a composite of " + str(len(self.motions)) + " motions"

  def __repr__(self):
    return "CompositeMotion(" + repr(self.motions) + ")"

  def add(self, motion):
    '''
    Adds the given motion to this composite motion object.
    '''
    self.motions.append(motion)

  def sample(self, initialPose):
    '''
    This method returns the result of sampling each of the component
    Motion objects in turn, using the output pose from each to feed the
    sampling of the next.
    '''
    return reduce(lambda A, B: B.sample(A), self.motions, initialPose)

  def apply(self, initialPose):
    '''
    This method returns the result of applying each of the component
    Motion objects in turn, using the output pose from each to feed the
    sampling of the next.
    '''
    return reduce(lambda x, y: y.apply(x), self.motions, initialPose)
