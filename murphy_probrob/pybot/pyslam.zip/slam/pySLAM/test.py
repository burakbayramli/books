#!/usr/bin/env python
# vim: set fileencoding=utf-8
'''
test.py
Written 2008-6-6 by Peter Mawhorter
This script tests the FastSLAM 1 implementation and provides
visualization for the testing.
'''

# TODO: make this not a hack.
import sys
sys.path.append("../../visualizer/")
sys.path.append("FastSLAM_1/")

import math, time

import visualizer

import fastslam

import components, observation, motion

# The number of particles:
N_PARTICLES = 10

# The motion variance:
posvar = (10, 10)
headvar = math.pi/8.

# This global constant defines how accurate the sensors are. It is the
# covariance matrix for the sensors in range and bearing.
senseCovar = ((500, 0),
              (  0, 0.25))

# This variable defines the sensor used to observe the landmarks:
sensor = observation.RangeBearingSensor(senseCovar)

# A global unique ID, this is just a hack for working (inefficiently)
# with the visualizer.
idn = 0

# The scale factor, to work with the visualizer:
sf = 10

# Landmark positions, keyed by identities:
landmarks = {
"hey": (5*sf, 5*sf),
"over here": (1*sf, 8*sf),
"ooh, pick me": (-3*sf, -2*sf),
"me, me!": (4*sf, -3*sf)
#"test1": (5*sf, 0*sf),
#"test2": (3*sf, 3*sf),
#"test3": (3*sf, -3*sf),
#"test4": (1*sf, 4*sf)
}

# Poses: snapshots of the robot's pose over time, along with which
# landmarks are "visible" at each pose:
poses = [
((0*sf, 0*sf, 0), ()),
((2*sf, 1*sf, math.pi/4.), ("hey",)),
((3*sf, 3*sf, math.pi/2.), ("hey", "over here")),
((3*sf, 5*sf, math.pi/2. + math.pi/6.), ("over here",)),
((1*sf, 6*sf, math.pi), ()),
((-1*sf, 5*sf, math.pi + math.pi/4.), ()),
((-2*sf, 3*sf, math.pi + math.pi/2.), ("ooh, pick me",)),
((-2*sf, 1*sf, math.pi + math.pi/2.), ("ooh, pick me",)),
((-1*sf, -1*sf, math.pi + math.pi/2. + math.pi/4.), ()),
((1*sf, -2*sf, 0), ("me, me!",)),
((3*sf, -1*sf, math.pi/4.), ("hey",)),
((3*sf, 0*sf, math.pi/2.), ("hey",)),
((3*sf, 2*sf, math.pi/2.), ("hey", "over here")),
((2*sf, 5*sf, math.pi/2. + math.pi/4.), ("over here",)),
((0*sf, 5*sf, math.pi), ())
]

#poses = [
#((0, 0, 0), ("test1", "test2", "test3", "test4")),
#((0*sf, -5*sf, 0), ("test1", "test2", "test3", "test4"))
#]


# Landmark positions and robot poses:
#                  |
#                  | X
#                  |
#                  | -
#                / 5   \ \   X
#                  |
#              |   |     |
#                  |     |
#              |   |   /
#- - - - 5 - - - - > - - | - 5 - - - - -
#                \ |     /
#            X     | -
#                  |       X
#                  |
#                  5
#                  |
#                  |
#                  |
#                  |

thread, queue = visualizer.startThreaded()

particles = [
components.Particle(components.Path([components.Pose(x=0, y=0, thr=0)]))
  for i in range(N_PARTICLES)]

print "Press Enter to step through the test."

lastpose = (0, 0, 0)
for p, lms in poses:
  measurements = []
  offset = p[0] - lastpose[0], p[1] - lastpose[1], p[2] - lastpose[2]
  mot = motion.Tesseract(posvar, headvar,
                         components.Pose(x=p[0],y=p[1],thr=p[2]))
  lastpose = p
  times = 0
  for lm in lms:
    lmcoords = landmarks[lm]
    x, y = lmcoords[0] - p[0], lmcoords[1] - p[1]
    thr = math.atan2(y, x)
    range = (x**2 + y**2)**0.5
    measurement = (range, thr - p[2])
    measurements.append(measurement)
    obs = observation.Observation((measurement[0], measurement[1]), sensor)
    if times == 0:
      particles = fastslam.FastSLAM(particles, mot, obs, lm)
    else:
      particles = fastslam.FastSLAM(particles, motion.Motion(), obs, lm)
    times += 1
  if not lms:
    for particle in particles:
      particle.path.poses.append(mot.sample(components.Pose()))
  queue.put("clear")
  for particle in particles:
    loc = particle.path.poses[-1]
    for key in particle.landmarks:
      lm = particle.landmarks[key]
      queue.put(visualizer.Landmark(id = idn,
                                    x = lm.x,
                                    y = lm.y,
                                    covar = lm.covar,
                                    fill = 25))
      idn += 1
    for lmn in landmarks:
      lm = landmarks[lmn]
      queue.put(visualizer.Landmark(id = idn,
                                    x = lm[0],
                                    y = lm[1],
                                    covar = ((10, 0), (0, 10)),
                                    color = 'orange'))
      idn += 1
    for ms in measurements:
      queue.put(visualizer.Robot(id = idn,
                                 x = loc.x,
                                 y = loc.y,
                                 range = ms[0],
                                 rangethr = ms[1],
                                 thr = loc.thr))
      idn += 1
      queue.put(visualizer.Robot(id = idn,
                                 x = p[0],
                                 y = p[1],
                                 thr = p[2],
                                 range = ms[0],
                                 rangethr = ms[1],
			         color = 'lime green',
                                 sensorcolor = 'lime green'))
      idn += 1
    if not measurements:
      queue.put(visualizer.Robot(id = idn,
                                 x = loc.x,
                                 y = loc.y,
                                 thr = loc.thr))
      idn += 1
      queue.put(visualizer.Robot(id = idn,
                                 x = p[0],
                                 y = p[1],
                                 thr = p[2],
			         color = 'lime green'))
      idn += 1
  quit = raw_input()
  if quit == 'q':
    sys.exit(0)
