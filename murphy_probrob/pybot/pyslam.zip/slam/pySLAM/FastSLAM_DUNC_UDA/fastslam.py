# vim: set fileencoding=utf-8
'''
fastslam.py
Written 2008-6-4 by Peter Mawhorter
Branched 2008-7-7 by Peter Mawhorter
This module implements the FastSLAM algorithm. It can take a continuous
series of sensor and control inputs and update a set of particles to maintain
pose and landmark estimates. This version does not require that landmark
observations be tied to a particular landmark, hence Unknown Data
Association. This version also implements Doddsian UNcertainty
Correction.
'''

# TODO: Make this not a hack:
import sys; sys.path.append("../")

import copy, math, random

# The components module defines data encapsulation classes like Pose and
# Particle that abstract the pieces of the FastSLAM algorithm.
import components

# This represents the probability threshold at which a landmark is
# assumed to be novel: if any possible association is above this one,
# then that association is used, but if none is at least THRESHOLD
# likely, the landmark is assumed to be novel.
THRESHOLD = 0.00001

# The Dodds Correction Values scale covariance matrices that haven't
# been seen for a while. The major correction value is applied to all
# non-observed landmarks whenever a landmark is seen. The minor
# correction value is applied to all landmarks every time a drive
# command is issued.
DCV_MAJOR = 1.10
DCV_MINOR = 1.02

def FastSLAM(particles, mot, obs):
  '''
  This function takes the following arguments:
    particles - a collection of components.Particle objects
    mot - motion.Motion object that describes the motion of the robot
          since the last call to this function.
    obs - a observation.Observation object that defines a sensor
          measurement along with the characteristics of the sensor that
          took the given measurement.
  This function returns a new collection of particles that have been
  updated based on the motion and observation given. This function
  performs both the Kalman filtering of the observation in each particle
  (using the updateParticle function) and the motion model noise
  addition and resampling (using the updateEach and resampleParticles
  functions). It also performs data association within updateEach.
  '''
  updateEach(particles, mot, obs)
  return resampleParticles(particles)

def updateEach(particles, mot, obs):
  '''
  This function updates a set of FastSLAM particles given a new set of
  robot offset and landmark location measurements. The particles
  argument should be a list or tuple of components.Particle objects
  which haven't yet had the latest robot motion, given by motion, added
  to them. The motion argument should be a motion.Motion object. This
  motion will be applied to each particle to generate a new Pose within
  that Particle. The obs argument should be a observation.Observation
  object that describes the location of a landmark, along with sensor
  properties. This description should be relative to the robot's pose at
  the end of the given motion. This function modifies the given
  collection of particles in-place, and returns None. It does not
  perform re-sampling.
  '''
  # Add the new pose (indicated by offset) to each particle, and then
  # update it using the updateParticle function:
  for p in particles:
    last = p.path.poses[-1]
    # Add motion noise:
    new = mot.sample(last)
    p.path.poses.append(new)
    # Update this particle:
    updateParticle(p, obs)

def updateParticle(particle, obs):
  '''
  This function performs a FastSLAM update for a single Particle object.
  It takes the particle object to operate on (which must be a
  components.Particle object that contains at least one pose) and a
  single observation, which consists of a observation.Observation
  object. This function returns nothing, modifying the given Particle
  object in place to be properly updated. For this function to work, the
  observation given must have been taken at the last pose in the
  particle's Path object.
  '''
  # Retrieve the robot's pose information (x, y, and angle) from the
  # Particle. This should be the pose at which the measurement was
  # taken.
  robotPose = particle.path.poses[-1].x, particle.path.poses[-1].y,\
                  particle.path.poses[-1].thr

  # Estimate the landmark position based on the observation and the
  # robot pose. We don't need to worry about accounting for robot motion
  # noise, because that entire problem is taken care of by having
  # multiple particles and doing noisy particle updates coupled with
  # particle resampling.
  estimatedPosition = obs.CartesianPosition(robotPose)

  # Compute the landmark identity. This consists of choosing the
  # landmark that maximizes the importance factor for this particle.
  landmarkName = obs.getLandmarkName(particle.landmarks, robotPose, THRESHOLD)

  # Create a new key if necessary:
  if particle.landmarks.keys() and landmarkName == None:
    landmarkName = max(particle.landmarks.keys()) + 1
  elif landmarkName == None:
    landmarkName = 0

  # If the landmark's name isn't known, it's a new landmark as far as
  # this particle is concerned.
  if landmarkName not in particle.landmarks.keys():

    # Calculate the landmark's uncertainty based on the robot pose.
    # Luckily, the Observation class does this for us.
    xyUncertainty = obs.CartesianCovariance(robotPose)

    # We've calculated the location and uncertainty of the new landmark,
    # now we just need to add it to the Particle.
    particle.landmarks[landmarkName] = components.Landmark(
                                                     x = estimatedPosition[0],
                                                     y = estimatedPosition[1],
                                                     covar = xyUncertainty)

    # Because this landmark is new, it's equally important in all
    # particles. That is, the observation and odometry doesn't
    # distinguish the particles in terms of likelihood, because there's
    # no past record of this landmark to agree with or disagree with.
    particle.importance = 1

  # If the landmark isn't new, then it must be in the current
  # Particle's landmarks dictionary.
  else:
    # This method integrates the new observation with the old data about
    # the landmark, modifying the given landmark in-place and returning
    # the probability of the given observation, which is used as the
    # importance factor. This method accomplishes the entire Kalman
    # filter.
    particle.importance = obs.updateLandmark(particle.landmarks[landmarkName],
                                             robotPose)

  # By this point, whichever branch of the if/else we've taken, the
  # particle has been modified to reflect the update and assigned its
  # proper weight. New we need to perform Doddsian Uncertainty
  # Correction on the unseen landmarks.
  for key in particle.landmarks:
    if key != landmarkName:
      correctUncertainty(particle.landmarks[key], DCV_MAJOR)

def resampleParticles(particles):
  '''
  This method takes a list or tuple of particles and returns a new tuple
  of particles drawn from the original particles. This new collection is
  the same size as the collection passed in, but has been re-sampled
  according to the particles' relative importance variables. The
  particles must each have an importance value, which must be a number.
  '''
  N = len(particles)
  max = sum(p.importance for p in particles)
  newparticles = []

  # Loop through the number of required particles, adding a particle to
  # newparticles each time:
  for i in range(N):
    # Choose a random number between 0 and the sum of the importance
    # factors, we'll line up the particles in order, giving each a
    # stretch of numbers equal to its importance factor, and then count
    # up to the chosen number, and see which particle we're on.
    choice = random.uniform(0, max)

    # Which particle we're looking at:
    j = 0
    particle = particles[j]

    # If choice > particle.importance, we know that the chosen particle
    # is after this particle:
    while choice > particle.importance:
      # The choice is always indexed from the end of the current
      # particle:
      choice -= particle.importance
      j += 1
      particle = particles[j]

    # Since we're drawing with replacement (i.e. the same particle could
    # get selected multiple times), we need to make deep copies of the
    # particles to add to the new list of particles:
    newparticles.append(copy.deepcopy(particle))

  return tuple(newparticles)

def minorUncertaintyCorrection(particles):
  '''
  This function takes a list of particles and performs a minor Dodds
  Uncertainty Correction. It corrects each of the particles according to
  the minor Dodds Correction value.
  '''
  for p in particles:
    for k in p.landmarks:
      correctUncertainty(p.landmarks[k], DCV_MINOR)

def correctUncertainty(landmark, value):
  '''
  This function takes a components.Landmark object and modifies its
  covariance in-place to correct for the fact that the landmark hasn't
  been observed recently. This update step is just a simple increase in
  convariance according to the given Dodds Correction Value.
  '''
  ((a, b), (c, d)) = landmark.covar
  landmark.covar = ((a*value, b*value), (c*value, d*value))
