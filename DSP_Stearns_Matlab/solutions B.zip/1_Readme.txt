1_README.TXT (SOLUTIONS B)

The solutions to "DIGITAL SIGNAL PROCESSING With 
Examples in MATLAB" are available to faculty who have 
adopted the text for a course.

A password is required to extract the solutions in 
this zip file.  If you are a professor or instructor 
and have adopted the text for a course, please 
request the password by writing on your department 
letterhead to the author:

Prof. S. D. Stearns
Dept. of Electrical and Computer Engineering
The University of New Mexico
Albuquerque, NM 87106

Or, if you wish, send an email to 
s.d.stearns@comcast.net.  In your email, give the 
author a website, phone number, or some way to 
verify.

Please include the following information:

1. Name
2. Address
3. Phone number
4. Department phone number
5. Email address
6. Course title and number
7. Number of students enrolled in the course

Some of the solutions are in the pdf format, 
requiring the Adobe Acrobat Reader (free at 
Adobe.com).

These files are updated periodically.  Please notify 
the author if you find an error in a solution.

Thanks,
SDS
