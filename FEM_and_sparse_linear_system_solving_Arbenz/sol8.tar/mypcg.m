function [x,k,reshist] = mypcg(A,M,M2,b,x,tol)
%
%MYPCG Conjugate Gradient Method for solving A x = b
%
%       [x,k] = mypcg(A,M1,M2,b,x,tol)
%	Input:	A  system matrix
%		M1,M2  M = M1*M2 preconditioner
%                      (M1/M2 = [] indicates M1/M2=identity)
%		b  right hand side
%		x  initial vector x^{0} (default x = 0)
%		tol (default tol = eps)
%	Output: x approximate solution
%	        k number of iteration until convergence
%	convergence criterion
%	norm(b - A*x) <= tol*norm(b - A*x0) 

%       14.11.2017 P. Arbenz

if (nargin < 6), tol = eps; end
if (nargin < 5), x = zeros(size(A,1),1); end

r = b - A*x;
rnrm0 = norm(r);  rnrm = rnrm0;  reshist = rnrm;
if isempty(M),
   z = r;
else
   if isempty(M2),
      z = M\r;
   else
      z = M2\(M\r);
   end
end
rho = z'*r;
p = z;
for k=1:1000
   q = A*p;
   alpha = (z'*r)/(z'*q);
   x = x + alpha*z;
   r = r - alpha*q;

   rnrm = norm(r);  reshist = [reshist;rnrm];
   if rnrm < tol*rnrm0, return, end
   
   if isempty(M),
      z = r;
   else
      if isempty(M2),
         z = M\r;
      else
         z = M2\(M\r);
      end
   end
   rho0 = rho;
   rho = z'*r;
   beta = rho/rho0;
   p = z + beta*p;
end
