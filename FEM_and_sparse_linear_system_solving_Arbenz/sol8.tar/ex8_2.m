function ex8_2()
% Exercise 8.2: Conjugate gradient method for solving Ax=b with SPD A
%
% Nov 2017

g = 'squareg';
bond = 'squareb1';
c = 1; a = 0; f = 1;

[p,e,t] = initmesh(g,'hmax',1);  % generate a coarse mesh
[p,e,t] = refinemesh(g,p,e,t);  % refine the mesh
[p,e,t] = refinemesh(g,p,e,t);  % refine the mesh
[p,e,t] = refinemesh(g,p,e,t);  % refine the mesh
[p,e,t] = refinemesh(g,p,e,t);  % refine the mesh

% check the number of nodes by size(p,2), it should be between 1000 to
% 3000.

[A,b] = assempde(bond,p,e,t,c,a,f);

D = diag(diag(A));  % diagonal of A
L = tril(A,-1);     % strictly lower triangle of A

x0 = zeros(size(A,1),1); tol = 1e-6;
[x,nit] = mypcg(A,[],[],b,x0,tol);   % unpreconditioned CG algorithm
fprintf('\nUnpreconditioned CG algorithm: num. of its = %d\n',nit)

[x,nit] = mypcg(A,D,[],b,x0,tol);    % Jacobi preconditioned CG algorithm
fprintf('\nJacobi preconditioned CG algorithm: num. of its = %d\n\n',nit)

for omega=[1:.1:1.9]
   M=sqrt(omega/(2-omega))*(D/omega+L)/sqrt(D);
   [x,nit] = mypcg(A,M,M',b,x0,tol);
   fprintf(['SSOR(%4.2f) preconditioned CG algorithm: ' ...
            'num. of its = %d\n'],omega,nit)
end
