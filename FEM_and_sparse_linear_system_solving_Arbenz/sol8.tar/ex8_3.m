% FEM17 - Exercise 8-3
% 
% Study the convergence rates of the steepest descent method and CG method
%
% Remarks:
%
% 1. PCG usually converges faster than the SD method.
%
% 2. For the ill-conditioned matrix, i.e. the corresponding condition number
% is large, then the convergence is slow for both SD and PCG method.  the
% condition number "kappa=lambda_max/lambda_min".  In this exercise,
% kappa=10^p.
%  
% 3. Usually, both SD and PCG solver converge faster for the matrix with
% clustered eigenvalue distribution than with equally eigenvalue
% distribution. Here is a reason:
%
% According to the theorem in slide 21 of lecture 8, at step m the residual
% r^(m) is bounded by the value of |p_m(lambda)|, where p_m is a polynomial
% function with degree of m.  Usually m is much smaller than N (A is a
% N-by-N matrix).
% 
% In the case of equally distribution of eigenvalues, it's more difficult to
% find a p_m to be small evaluated on all eigenvalues. That is because the
% eigenvalues are apart from each other. According to the theorem, the
% residual r^(m) may also become large, meaning that solver may converge
% slower.
%
% In the case of clustered distribution of eigenvalues, it's much easier to
% make p_m to be small evaluated on all eigenvalues. In fact in the
% clustered region, if p_m is zero evaluated for one eigenvalue, then for
% all the other eigenvalues nearby, p_m is close to zero.  According to the
% theorem, the residual r^(m) may be bounded and small and the solver
% converges faster.
%
% Hua Guo, 19th Nov. 2010.


N=100;
rand('seed',100);
b=rand(N,1);
tol=1e-6;
i=[0:N-1]';
for p=1:3
   fprintf('----------------------------------------------------\n')
   fprintf('with parameter p=%d\n',p);
   fprintf('----------------------------------------------------\n')
 
   % (1) equal distribution
   lambda1=10^(-p)+i*(1-10^(-p))/(N-1);
   A1=diag(lambda1);

   % (2) clustered distribution
   lambda2=10^(-p)+0.1*(1-10^(-p))*cos(i*3.141592654/(2*(N-1)));
   A2=diag(lambda2);

   % 1
   fprintf('matrix with equal eigenvalue distribution.\n\n');

   [x1,it,res]=sd(A1, [], [], b, zeros(N,1), tol, 1000*p);
   if(it==1000*p)
      fprintf('sd method failed to converge!\n');
      relres=norm(b-A1*x1)/norm(b);
   else
      relres=norm(b-A1*x1)/norm(b);
      fprintf('sd converged to the desired tolerance in %d steps!\n',it);
   end

   % 2
   [x2,flag1,rr1,iter1,rv1] = pcg(A1, b, tol, 1000);
   if (flag1==0)
      fprintf('pcg converged to the desired tolerance in %d steps!\n\n',iter1);
   else
      fprintf('pcg method failed to converge!\n\n');
   end

   % 3
   fprintf('matrix with clustered eigenvalue distribution.\n\n');

   [x3,it]=sd(A2, [], [], b, zeros(N,1), tol, 1000*p);
   if(it==1000*p)
      fprintf('sd method failed to converge!\n');
   else
      fprintf('sd converged to the desired tolerance in %d steps!\n',it);
   end

   %4
   [x4,flag1,rr1,iter1,rv1] = pcg(A2, b, tol, 1000);
   if (flag1==0)
      fprintf('pcg converged to the desired tolerance in %d steps!\n',iter1);
   else
      fprintf('pcg method failed to converge!\n');
   end
end
fprintf('----------------------------------------------------\n')
