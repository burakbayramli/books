function [y] = skylinemult(val, ptr, x)
% [y] = skylinemult(val, ptr, x)
% Multiplication of a SPD matrix A in skyline storage format 
% with a vector x. 
% val stores A's elements from the first non-zero element to 
% and including the diagonal element.
% ptr(i) points to the diagonal element of row i.

n=length(x);
if n ~= length(ptr)
   error('Something''s wrong with the dimensions')
end

y = zeros(n,1);
y(1) = val(1)*x(1);
for i=2:n,
  y(i) = val(ptr(i-1)+1:ptr(i))*x(i-(ptr(i)-ptr(i-1))+1:i);
  y(i-(ptr(i)-ptr(i-1))+1:i-1) = y(i-(ptr(i)-ptr(i-1))+1:i-1) ...
			       + x(i)*val(ptr(i-1)+1:ptr(i)-1)';
end
