function [val, ptr] = skyline(A)
% [val, ptr] = skyline(A)
% This function implements the skyline storage format.
% A is a sparse symmetric positive definite matrix.
% (This implies that there is at least one element per row.)
% The vector val stores elements from the first non-zero element to 
% and including the diagonal element.
% ptr(i) points to the diagonal element of row i.

n=size(A,1);
val = [];
ptr = zeros(n,1);

ptr(1) = 1;
val(1) = A(1,1);
for i=2:n,
  for j=1:i,
    if A(i,j) ~= 0
      ptr(i) = ptr(i-1) + (i-j+1);
      val(ptr(i-1)+1:ptr(i)) = A(i,j:i);
      break;    
    end
  end
end
