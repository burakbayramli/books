%% Exercise 6.2 ;  Solution
%% run this code with hmax = 0.1 / 0.03 / 0.01

hmax = .1;
[A,~]=ElasticSolver(hmax);  %% A is a matrix that consists of 2x2 blocks

n = size(A,1);      % determine size of square A
N = n/2;            % A is a N-by-N square block matrix of 2-by-2 blocks

I=1:2:n-1; J=I+1;
AA = abs(A(I,I))+abs(A(I,J))+abs(A(J,I))+abs(A(J,J));% find the nonzero blocks
[cols,rows,~] = find(AA');      % determine block CRS structure
col_ind = cols;

tmp = sum(AA'>0);               % nonzeros per column (AA's nonzeros are > 0)
row_ptr = [0,cumsum(tmp)]+1;    % cumulative sum

vals = zeros(2,2,length(col_ind));  % vector of 2x2 blocks
for k=1:N;
   for i=row_ptr(k):row_ptr(k+1)-1  % fill this vector
      vals(:,:,i) = A(2*k-1:2*k,2*col_ind(i)-1:2*col_ind(i));
   end
end

x = rand(n,1);
y = zeros(n,1);                  % now do the blocked multiply
for k=1:N,
   kk = 2*k-1:2*k;
   for i=row_ptr(k):row_ptr(k+1)-1
      y(kk) = y(kk) + vals(:,:,i)*x(2*col_ind(i)-1:2*col_ind(i));
   end
end

fprintf('\nhmax = %8.4g\n', hmax)
fprintf('nnz(A), nrows(A)+1, nvals(A) = %i, %i, %i\n', nnz(A),size(A,1)+1,nnz(A))
fprintf('nnz(AA), nrows(AA)+1, nvals(AA)*4 = %i, %i, %i\n', nnz(AA),...
        size(AA,1)+1,nnz(AA)*4)
%% nnz(AA) = length(col_ind), size(AA,1)+1 = length(row_ptr), 
%% nnz(AA)*4 = prod(size(vals))