function x = mybicg(A,b,tol,maxit)

   [m,n] = size(A);
   if (m ~= n)
      error('MATLAB:bicg:NonSquareMatrix', 'Matrix must be square.');
   end
   


   % Set up for the method
   x=zeros(n,1);
   r = b - A*x;
   normr = norm(r);                   % Norm of residual
   normr0 = normr;
   rt = r;                            % Shadow vector
   rho = 1;
   rho1=1;

   p = r;      
   pt = rt;
   q = A * p;
   qt = A' * pt;

   W = [pt];  % pt is the test vector.
   AV = [q];  % q = Ap, where p is the search vector.

   T = W'*AV;
   condn = [cond(T)];

   % loop over maxit iterations until convergence or failure.

   for i = 1 : maxit
      
      rho = r' * rt;     
      alpha = rho / (q'*pt);      
      
      x = x + alpha * p;
      
      if (norm(b-A*x)/norm(b)<tol)
         break;
      end
      
      r = r - alpha*q; 
      normr = [normr,norm(r)];
      rt = rt - alpha*qt;
      
      rho1 = r' * rt;
      
      beta = rho1/rho;
      
      p = r + beta * p; 
      q = A * p;
      
      pt = rt + beta * pt;
      qt = A' * pt;
      
      
      W = [W,pt];       
      AV = [AV,q];
      
      T=W'*AV; % It may be expensive for large-sized problems!
               % There are better approaches.
      condn = [condn; cond(T)];
      
   end

   iter = i;
   fprintf('\niter(mybicg) = %d\n',iter)

   res = norm(b-A*x)/norm(b);
   fprintf('relative residual norm(mybicg) = %d\n',res)

   figure
   semilogy(1:iter,normr/normr0,'-o')
   xlabel('Iteration step')
   ylabel('Relative residual norm')

   figure
   semilogy(1:iter,condn,'-o')
   xlabel('Iteration step')
   ylabel('Condition number')

   