% Plot the figure of the relative residual vs. the condition number of projected
% matrix T. The figure shows how the condition number influences the convergence
% behaviour.
% We find that the BiCG solver is less stable than GMRES. The condition number
% of T is increasing during iterations, consequently the relative residual may
% also increase at certain iteration steps.

A = gallery('toeppen', 30000, 2 ,3, 8, 3.5, 4.5);

fprintf('\ncondest(A) = %f\n',condest(A))
n = size(A,2);
b = ones(n,1);

%You can accurately solve A*x = b 

x = A \ b;
norm(b-A*x) / norm(b);

maxit=300;
droptol=1e-8;

%Now try to solve A*x = b with different unsymmetric solvers.

[x,flag,relres,iter,resvec] = bicg(A,b,1e-6, maxit);
%[x,flag,relres,iter,resvec] = qmr(A,b,1e-6, maxit);
%[x,flag,relres,iter,resvec] = bicgstab(A,b,1e-6, maxit);
%[x,flag,relres,iter,resvec] = gmres(A,b,6,1e-6, maxit);

fprintf('flag(bicg) = %d\n',flag)

close all
figure
semilogy(0:size(resvec,1)-1,resvec/norm(b),'-o')
xlabel('Iteration step')
ylabel('Relative residual')

x = mybicg(A,b,1e-6, maxit);
