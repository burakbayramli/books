% Plot the figure of the relative residual vs. the condition number of
% projected matrix T. 

% The figure shows how the condition number affects the convergence
% behaviour. We find that the BiCG solver is less stable than GMRES. The
% condition number of T is increasing during iterations, consequently the
% relative residual may also increase at certain iteration steps.

[A,b] = HeatFlowSolver2D;

condest(A)
n = size(A,2);
b = ones(n,1);

%You can accurately solve A*x = b 

x = A \ b;
norm(b-A*x) / norm(b);

maxit=1000;
droptol=.3;
setup.type='ilutp';
setup.droptol=droptol

[L,U] = ilu(A,setup);
%Now try to solve A*x = b with different unsymmetric solvers.

tic
[x,flag,relres,iter,resvec] = bicg(A,b,1e-6, maxit, L,U);
elapsed = toc;
disp(['BiCG: flag = ',num2str(flag),', iter = ',num2str(iter), ...
      ', exec time = ',num2str(elapsed)])

close all
figure
subplot(2,2,1)
semilogy(0:size(resvec,1)-1,resvec/norm(b),'-o')
title('BiCG')
xlabel('Iteration step')
ylabel('Relative residual')

tic
[x,flag,relres,iter,resvec] = qmr(A,b,1e-6, maxit,L,U);
elapsed = toc;
disp(['QMR: flag = ',num2str(flag),', iter = ',num2str(iter), ...
      ', exec time = ',num2str(elapsed)])

subplot(2,2,2)
semilogy(0:size(resvec,1)-1,resvec/norm(b),'-o')
title('QMR')
xlabel('Iteration step')
ylabel('Relative residual')

tic
[x,flag,relres,iter,resvec] = bicgstab(A,b,1e-6, maxit, L,U);
elapsed = toc;
disp(['BiCGstab: flag = ',num2str(flag),', iter = ',num2str(iter), ...
      ', exec time = ',num2str(elapsed)])

subplot(2,2,3)
semilogy(0:size(resvec,1)-1,resvec/norm(b),'-o')
title('BiCGstab')
xlabel('Iteration step')
ylabel('Relative residual')

tic
restart=20;
[x,flag,relres,iter,resvec] = gmres(A,b,restart,1e-6,maxit,L,U);
elapsed = toc;
disp(['GMRES: flag = ',num2str(flag), ...
      ', iter = ',num2str((iter(1)-1)*restart+iter(2)), ...
      ', exec time = ',num2str(elapsed)])

subplot(2,2,4)
semilogy(0:size(resvec,1)-1,resvec/norm(b),'-o')
title('GMRES(20)')
xlabel('Iteration step')
ylabel('Relative residual')
