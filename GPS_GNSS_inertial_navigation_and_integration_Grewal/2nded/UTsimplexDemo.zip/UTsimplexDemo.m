%
% Simplex unscented transform with four alternative Cholesky factors
%
close all;
clear all;
%
% Initial covariance
%
T               = 1/2*[1,1,1,1;1,1,-1,-1;1,-1,1,-1;1,-1,-1,1]; % orthogonal
P               = T*[4,0,0,0;0,36,0,0;0,0,100,0;0,0,0,196]*T';
%
% Eigenvector Choleksy factor
%
[U,Lambda,V]    = svd(P);
CEV             = U*sqrt(Lambda);
%
% Symmetric Choleksy factor
%
Csym            = U*sqrt(Lambda)*U';
%
% Upper triangular Choleksy factor
%
CUT             = utchol(P);
%
% Lower triangular Choleksy factor
%
CLT             = chol(P)';
%
% Initial mean
%
xhat = [0;0;0;0];
%
% Theoretical mean from NonLin transformation of (xhat(1:3),P(1:3,1:3))
%
Tzhat    = zeros(3,1);
Tzhat(1) = P(2,3)*(1 - P(2,3)^2 / P(2,2) / P(3,3))^(-3/2);
Tzhat(2) = P(3,1)*(1 - P(3,1)^2 / P(3,3) / P(1,1))^(-3/2);
Tzhat(3) = P(1,2)*(1 - P(1,2)^2 / P(1,1) / P(2,2))^(-3/2);
Tzhat,
%
% Extendeded Kalman filter transformation of mean and variance
%
Lzhat = NonLin(xhat(1:3)),
H     = [0,xhat(3),xhat(2),0;xhat(3),0,xhat(1),0;xhat(2),xhat(1),0,0];
LPzz  = H*P*H',
%
% simplex unscented transform solutions
%
[sUTzhatEV,sUTPzzEV]    = UTsimplex(xhat(1:3),CEV(1:3,1:3),@NonLin,.5,1),
[sUTzhatUT,sUTPzzUT]    = UTsimplex(xhat(1:3),CUT(1:3,1:3),@NonLin,.5,1),
[sUTzhatLT,sUTPzzLT]    = UTsimplex(xhat(1:3),CLT(1:3,1:3),@NonLin,.5,1),
[sUTzhatsy,sUTPzzsy]    = UTsimplex(xhat(1:3),Csym(1:3,1:3),@NonLin,.5,1),
