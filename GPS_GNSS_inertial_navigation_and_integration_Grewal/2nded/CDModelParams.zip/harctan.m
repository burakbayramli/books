function zhat = harctan(xhat,d)
%
% Arctangent measurement function
%
zhat = atan2(xhat,d);