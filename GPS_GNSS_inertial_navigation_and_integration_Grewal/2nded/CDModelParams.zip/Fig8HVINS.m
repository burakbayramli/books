% Fig8HVINS.m
%
% Figure-8 track using host vehicle model to bound INS errors
%
% Grewal and Andrews, Kalman Filtering: Theory and Practice Using MATLAB,
% Wiley, 2008, updated 15 Feb 09
%
% STATE VARIABLES
%
%  The ad hoc attitude model (state variables 10-12) is for performance
%  analysis only.
%
%  1. P[N], northing from center of track 
%  2. V[N], north velocity 
%  3. A[N], north acceleration 
%  4. P[E], easting from center of track 
%  5. V[E], east velocity 
%  6. A[E], east acceleration 
%  7. P[D], downward displacement from center of track 
%  8. V[D], downward velocity 
%  9. A[D], downward acceleration
% 10. theta[N],  tilt about north axis
% 11. theta-dot[N],  rotation rate about north axis
% 12. theta[E],  tilt about east axis
% 13. theta-dot[E],  rotation rate about east axis
% 14. theta[D],  heading angle
% 15. theta-dot[D],  heading angle rate
% 16. epsilon[N], INS northing error
% 17. epsilon[E], INS easting error
% 18. epsilon[D], INS downward error
% 19. epsilon-dot[N], INS north velocity error
% 20. epsilon-dot[E], INS east velocity error
% 21. epsilon-dot[D], INS downward velocity error
% 22. epsilon[theta N], INS north tilt error
% 23. epsilon[theta E], INS east tilt error
% 24. epsilon[theta D], INS heading error
% 25. epsilon[abR], INS roll accelerometer bias error
% 26. epsilon[abP], INS pitch accelerometer bias error
% 27. epsilon[abY], INS yaw accelerometer bias error
% 28. epsilon[asR], INS roll accelerometer scale factor error
% 29. epsilon[asP], INS pitch accelerometer scale factor error
% 30. epsilon[asY], INS yaw accelerometer scale factor error
% 31. epsilon[gbR], INS roll gyroscope bias error
% 32. epsilon[gbP], INS pitch gyroscope bias error
% 33. epsilon[gbY], INS yaw gyroscope bias error
% 34. epsilon[gsR], INS roll gyroscope scale factor error
% 35. epsilon[gsP], INS pitch gyroscope scale factor error
% 36. epsilon[gsY], INS yaw gyroscope scale factor error
%
%
% INS MEASUREMENT VARIABLES
%
%    1. P[N], northing from center of track
%    2. P[E], easting from center of track
%    3. P[D], negative altitude from center of track
%    4. V[N], north velocity
%    5. V[E], east velocity
%    6. V[D], downward velocity
%    7. A[N], north acceleration
%    8. A[E], east acceleration
%    9. A[D], downward acceleration
%   10. Rotation about north axis
%   11. Rotation about east axis
%   12. Yaw (heading) angle of vehicle
%   13. North axis rotation rate
%   14. East axis rotation rate
%   15. Heading rate
%
close all;
clear all;
%
% Initial simulation conditions
%
deglat  = 40;               % degrees latitude
Lat     = deglat*pi/180;
Lon     = 0;
Alt     = 100;
%
% Track parameters
%
TrackLength     = 1500; % meter
Speed           = 25;   % meter/sec (90 kph)
CrossOverHeight = 10;   % meter
%
% Figure-8 test track dynamic statistics
%
dt      = 1;         % discrete time step
RMSPosN = 212.9304;  % meter
RMSPosE = 70.9768;   % meter
RMSPosD = 3.5361;    % meter
RMSVelN = 22.3017;   % m/s
RMSVelE = 14.8678;   % m/s
RMSVelD = 0.37024;   % m/s
RMSAccN = 2.335;     % m/s/s
RMSAccE = 3.1134;    % m/s/s
RMSAccD = 0.038778;  % m/s/s
TauPosN = 13.4097;   % sec
TauPosE = 7.6696;    % sec
TauPosD = 9.6786;    % sec
TauVelN = 9.6786;    % sec
TauVelE = 21.4921;   % sec
TauVelD = 13.4097;   % sec
TauAccN = 13.4097;   % sec
TauAccE = 7.6696;    % sec
TauAccD = 9.6786;    % sec
MSdVN   = 0.02335^2*(dt/.01);    % mean squared delta velocity north
MSdVE   = 0.031134^2*(dt/.01);   % mean squared delta velocity east
MSdVD   = 0.00038771^2*(dt/.01); % mean squared delta velocity down
%
% CD dynamic model parameter for vehicle rotation angles and rates
%
RMSthetaN = 0.16902; % rad
RMSthetaE = 0.17555; % rad
RMSthetaD = 1.5357 ; % rad
RMSomegaN = 0.011171; % rad/s
RMSomegaE = 0.011713; % rad/s
RMSomegaD = 0.16474; % rad/s
tauthetaN = 25.4394; % sec
tauthetaE = 6.0592; % sec
tauthetaD = 21.7796; % sec
tauomegaN = 10; % sec
tauomegaE = 16.9927; % sec
tauomegaD = 13.5854; % sec
tauCDN    = 2/(1/tauthetaN+1/tauomegaN);
tauCDE    = 2/(1/tauthetaE+1/tauomegaE);
tauCDD    = 2/(1/tauthetaD+1/tauomegaD);
%
% Dynamic model parameters for vehicle attitude state variables
%
[PhiCDN,QCDN] = CDModelParams(RMSthetaN,RMSomegaN,tauCDN,dt);
[PhiCDE,QCDE] = CDModelParams(RMSthetaE,RMSomegaE,tauCDE,dt);
[PhiCDD,QCDD] = CDModelParams(RMSthetaD,RMSomegaD,tauCDD,dt);
PhiCD = [PhiCDN,zeros(2,4);zeros(2),PhiCDE,zeros(2);zeros(2,4),PhiCDD];
QCD = [QCDN,zeros(2,4);zeros(2),QCDE,zeros(2);zeros(2,4),QCDD];
PCD = zeros(6);
PCD(1,1) = .01*RMSthetaN^2;
PCD(2,2) = .01*RMSomegaN^2;
PCD(3,3) = .01*RMSthetaE^2;
PCD(4,4) = .01*RMSomegaE^2;
PCD(5,5) = .01*RMSthetaD^2;
PCD(6,6) = .01*RMSomegaD^2;
%
% Host vehicle tracking model parameters (46 state variables)
%
[PhiHVN,QHVN,PHVN] = MODL6Params(RMSAccN,RMSVelN,RMSPosN,TauAccN,dt);
[PhiHVE,QHVE,PHVE] = MODL6Params(RMSAccE,RMSVelE,RMSPosE,TauAccE,dt);
[PhiHVD,QHVD,PHVD] = MODL6Params(RMSAccD,RMSVelD,RMSPosD,TauAccD,dt);
PhiHV    = [PhiHVN,zeros(3,12);
           zeros(3),PhiHVE,zeros(3,9);
           zeros(3,6),PhiHVD,zeros(3,6);
           zeros(6,9),PhiCD];
QHV      = [QHVN,zeros(3,12);
           zeros(3),QHVE,zeros(3,9);
           zeros(3,6),QHVD,zeros(3,6);
           zeros(6,9),QCD];
PHV      = [.01*PHVN,zeros(3,12);
           zeros(3),.01*PHVE,zeros(3,9);
           zeros(3,6),.01*PHVD,zeros(3,6);
           zeros(6,9),.01*PCD];
%
% INS model parameters
%
Derating = 1;  % INS derating factor
g        = 9.8; % gravitational acceleration [m/s/s]
deglat   = 40;  % latitude [deg]
dph      = pi/180/3600; % degrees per hour to radians per second
NSE      = 12;  % number of sensor error state variables
tauSE    = 20*60*ones(NSE,1); % sensor error correlation times = 20 minutes
three1s  = ones(3,1);
sigmaSE  = Derating*[40*1e-6*g*three1s;% 40 micro-g RMS accelerometer bias stability
            100*1e-6*three1s; % 100 ppm RMS scale factor accelerometer stab.
            .01*dph*three1s;  % .01 deg/hr RMS gyro bias stability
            100*1e-6*three1s];% 100 ppm RMS gyro scale factor stability
[FSS,QS] = FSSQSmat(tauSE,sigmaSE);% sensor error dynamic coeff. matrix
QINS     = [zeros(9,21);zeros(12,9),QS];
PINS     = [zeros(9,21);zeros(12,9),DiagMat(sigmaSE.^2)];
PINS(1,1)   = 1;
PINS(2,2)   = 1;    % 1 meter RMS position uncertainty
PINS(3,3)   = 1;
PINS(4,4)   = 1e-4;
PINS(5,5)   = 1e-4; % 1 cm/sec RMS velocity uncertainty
PINS(6,6)   = 1e-4;
PINS(7,7)   = 1e-8;
PINS(8,8)   = 1e-8; % 100 micro-radian RMS attitude uncertainty
PINS(9,9)   = 1e-8;
%
% Measurement model submatrices
%
sigmaINS = Derating*[1*three1s;    % 1 m RMS position quantization noise
            1e-2*three1s;   % 1 cm/s RMS velocity quantization noise
            1e-6*three1s;   % 1 microradian RMS attitude quantization
            1e-6*g*three1s; % 1 micro-g RMS accelerometer quantization
            1e-3*dph*three1s];% .001 deg/hr RMS gyro noise
RINS     = DiagMat(sigmaINS.^2);
%
% Full system model parameters
%
Q  = [QHV,zeros(15,21);zeros(21,15),QINS];
P  = [PHV,zeros(15,21);zeros(21,15),PINS];
%
% Simulated vehicle on figure-8 track and 9--11 satellites in view
%
k         = 0;
hours     = 10;   % hours of simulated time
Time      = [];
RMShe     = [];
RMSve     = [];
RMSINShe  = [];
RMSINSve  = [];
RMSab     = [];
RMSas     = [];
RMSgb     = [];
RMSgs     = [];
CondNo    = []; % Condition number of innovations covariance
t         = 0;
for hour = 1:hours,
    disp(['Hour #',num2str(hour),'/',num2str(hours)]);
    for minute = 1:60,
        for second = 1:dt:60,
            t     = t + dt;
            %
            % Simulated vehicle state (Pos, Vel, Acc)
            %
            [VehState,CRPY2NED] = Fig8TrackSim2(t,TrackLength,Speed,CrossOverHeight);
            %
            % Vehicle State vector elements:
            %
            %    1  PosN        Northing from crossover [meters]
            %    2  PosE        Easting from crossover [meters]
            %    3  PosD        Downward position wrt median crossover [meters]
            %    4  VelN        North velocity [m/s]
            %    5  VelE        East velocity [m/s]
            %    6  VelD        Downward velocity [m/s]
            %    7  AccN        North acceleration [m/s/s]
            %    8  AccE        East acceleration [m/s/s]
            %    9  AccD        Downward acceleration [m/s/s] (not including gravity)
            %   10  Roll        Vehicle roll angle [rad]
            %   11  Pitch       Vehicle pitch angle, up from horizontal [rad]
            %   12  Heading     Vehicle heading measured clockwise from north [rad]
            %   13  RollRate    Vehicle rotation rate about its roll axis [rad/s]
            %   14  PitchRate   Vehicle rotation rate about its pitch axis [rad/s]
            %   15  YawRate     Vehicle rotation rate about its yaw axis [rad/s]
            %   16  AccR        Acceleration along vehicle roll axis [m/s/s]
            %   17  AccP        Acceleration along vehicle pitch axis [m/s/s]
            %   18  AccY        Acceleration along vehicle yaw axis [m/s/s]
            %                   (not including gravity)
            %
            aRPY     = VehState(16:18);
            omegaRPY = VehState(13:15);
            Roll     = VehState(10);
            Pitch    = VehState(11);
            Heading  = VehState(12);
            FNS      = FNSmat12(CRPY2NED,aRPY,omegaRPY);
            FNN      = FNNmat(aRPY,deglat);
            FN       = [FNN,FNS;zeros(NSE,9),FSS];
            PhiINS   = expm(dt*FN);
            Phi      = [PhiHV,zeros(15,21);zeros(21,15),PhiINS];
            %
            % Measurement sensitivity matrices for integration filter
            %
            HINS = HINS67(aRPY,omegaRPY,CRPY2NED);
            H    = [HINS(1:15,1:15),HINS(1:15,47:67)];
            [Nmeas,Nstates] = size(H);
            for n=1:Nmeas,
                h  = H(n,:);
                r  = RINS(n,n);
                hP = h*P;
                K  = hP'/(hP*h'+r);
                P  = P - K*hP;
                P  = (P+P')/2;
            end;
            Time  = [Time,t];
            RMShe = [RMShe,sqrt((P(1,1)+P(4,4))/2)];
            RMSve = [RMSve,sqrt((P(2,2)+P(5,5))/2)];
            RMSINShe = [RMSINShe,sqrt((P(16,16)+P(17,17))/2)];
            RMSINSve = [RMSINSve,sqrt((P(19,19)+P(20,20))/2)];
            RMSab = [RMSab,sqrt((P(25,25)+P(26,26)+P(27,27))/3)];
            RMSas = [RMSas,sqrt((P(28,28)+P(29,29)+P(30,30))/3)];
            RMSgb = [RMSgb,sqrt((P(31,31)+P(32,32)+P(33,33))/3)];
            RMSgs = [RMSgs,sqrt((P(34,34)+P(35,35)+P(36,36))/3)];
            %
            % Temporal update
            %
            P  = Phi*P*Phi' + Q;
            P  = (P+P')/2;
        end;
    end;
end;
%
%figure;
%semilogy(Time/3600,CondNo,'k-',0,10^ceil(log10(max(CondNo))),'w.',0,10^floor(log10(min(CondNo))),'w.');
%xlabel('Time [hr]');
%ylabel('Condition Number');
%title('CONDITION NUMBER OF INNOVATIONS COVARIANCE MATRIX');
%
figure;
subplot(2,1,1),
semilogy(Time/3600,RMShe,'k-',Time/3600,RMSINShe,'k--');
xlabel('Time [hr]');
ylabel('RMS Horiz. Error / Axis [m]');
title('GNSS/INS NAVIGATION ON FIGURE-8 TRACK');
subplot(2,1,2),
semilogy(Time/3600,RMSve,'k-',Time/3600,RMSINSve,'k--');
xlabel('Time [hr]');
ylabel('RMS Vel. Error / Axis [m/s]');
figure;
subplot(2,1,1)
semilogy(Time/3600,RMSab/g,'k-',0,10^ceil(log10(max(RMSab/g))),'w.',0,10^floor(log10(min(RMSab/g))),'w.');
title('Accelerometer Calibration Uncertainties');
ylabel('Bias [g]');
subplot(2,1,2)
semilogy(Time/3600,RMSas,'k-',0,10^ceil(log10(max(RMSas))),'w.',0,10^floor(log10(min(RMSas))),'w.');
xlabel('Time [hr]');
ylabel('Scale Factor');
figure;
subplot(2,1,1)
semilogy(Time/3600,RMSgb/dph,'k-',0,10^ceil(log10(max(RMSgb)/dph)),'w.',0,10^floor(log10(min(RMSgb)/dph)),'w.');
title('Gyroscope Calibration Uncertainties');
ylabel('Bias [deg/hr]');
subplot(2,1,2)
semilogy(Time/3600,RMSgs,'k-',0,10^ceil(log10(max(RMSgs))),'w.',0,10^floor(log10(min(RMSgs))),'w.');
xlabel('Time [hr]');
ylabel('Scale Factor');%
figure;
plot(Time(600:36000)/3600,RMShe(600:36000),'k-');
xlabel('TIME [HR]');
ylabel('RMS HORIZONTAL POSITION ERROR [M]');
title('FIGURE-8 TRACK SIMULATION OF STRAPDOWN INS');
%
% Save curve for comparison with INS-only and GNSS-only
%
tHVINS=Time; RMSHVINS=RMShe;save 'HVINS' tHVINS RMSHVINS
