function [Phi,Q] = CDModelParams(StDev1,StDev2,tau,DeltaT)
%
% function [Phi,Q] = CDModelParams(StDev1,StDev2,tau,DeltaT);
%
% Calculates the dynamic model parameters for a critically damped system
%
% INPUTS
%   StDev1 standard deviation of first variable x
%   StDev2 standard deviation of second variable x-dot
%   tau    correlation time-constant of variables
%   Dt     discrete time-step
% OUTPUTS
%   Phi    2x2 state transition matrix
%   Q      2x2 covariance matrix of dynamic disturbance noise
%
t1       = 0.1e1 / tau;
t3       = exp(-DeltaT * t1);
t8       = tau^2;
Phi(1,1) = t3 * (tau + DeltaT) * t1;
Phi(1,2) = DeltaT * t3;
Phi(2,1) = -DeltaT / t8 * t3;
Phi(2,2) = t3 * (tau - DeltaT) * t1;
%
Q        = zeros(2);
Q(2,2)   = 2*(StDev2^2 + (StDev1/tau)^2)/tau;
