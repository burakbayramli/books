function FNS = FNSmat(CXYZ2NED,a,omega)
%
% Computes the dynamic cross-coupling matrix FNS between INS navigation
% errors and INS sensor errors shown in Equation 9.92 on page 463
%
Fa = [a(1) 0 0 0 a(3) a(2);
    0 a(2) 0 a(3) 0 a(1);
    0 0 a(3) a(2) a(1) 0];
Fg = [omega(1) 0 0 0 omega(3) omega(2) 0 omega(3) -omega(2);
    0 omega(2) 0 omega(3) 0 omega(1) -omega(3) 0 omega(1);
    0 0 omega(3) omega(2) omega(1) 0 omega(2) -omega(1) 0;];
FNS = [zeros(3,21);
    CXYZ2NED,CXYZ2NED*Fa,zeros(3,12);
    zeros(3,9),CXYZ2NED,CXYZ2NED*Fg];
return;
