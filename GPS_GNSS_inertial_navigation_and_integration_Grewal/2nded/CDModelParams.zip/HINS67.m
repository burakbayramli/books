function HINS = HINS67(accRPY,omegaRPY,CRPY2NED)
%
% Computes the 15x67 measurement sensitivity submatrix for the inertial
% navigation system (as a sensor) in the 67-state model for GNSS/INS
% integration.  The 15 measured variables are
%
%    1 Northing
%    2 Easting
%    3 Negative altitude
%    4 North velocity
%    5 East velocity
%    6 Downward velocity
%    7 North acceleration
%    8 East acceleration
%    9 Downward acceleration
%   10 Roll angle
%   11 Pitch Angle
%   12 Heading angle
%   13 Roll rate
%   14 Pitch rate
%   15 Yaw rate
%
H1          = zeros(15,46);
H1(1,1)     = 1;
H1(2,4)     = 1;
H1(3,7)     = 1;
H1(4,2)     = 1;
H1(5,5)     = 1;
H1(6,8)     = 1;
H1(7,3)     = 1;
H1(8,6)     = 1;
H1(9,9)     = 1;
H1(10,10)   = 1;
H1(11,12)   = 1;
H1(12,14)   = 1;
H1(13,11)   = 1;
H1(14,13)   = 1;
H1(15,15)   = 1;
H2          = [eye(6),zeros(6,15);
               zeros(3,9),CRPY2NED,CRPY2NED*DiagMat(accRPY),zeros(3,6);
               zeros(3,6),eye(3),zeros(3,12);
               zeros(3,15),CRPY2NED,CRPY2NED*DiagMat(omegaRPY)];
HINS        = [H1,H2];

