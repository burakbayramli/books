function FNS = FNSmat12(CXYZ2NED,a,omega)
%
% Dynamic coupling matrix from 12-state sensor error model into 9-state
% vehicle dynamic model (3D pos., 3D vel., 3D att.)
%
FNS = [zeros(3,12);
    CXYZ2NED,CXYZ2NED*DiagMat(a),zeros(3,6);
    zeros(3,6),CXYZ2NED,CXYZ2NED*DiagMat(omega)];
return;